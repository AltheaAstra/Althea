ALTHEABOOK APP STORE + RAM UPGRADE (STARTER V1)

WHAT THIS PACKAGE ADDS
- App Store is the first pinned Dock app.
- Apps are not shown in Dock until the player's profile says they are installed.
- Install/uninstall app packages from App Store. The Server validates prices and storage capacity.
- RAM upgrades: 4 GB -> 8 GB -> 16 GB -> 32 GB, purchased with in-game Credits.
- Open windows consume simulated RAM. Trying to open an app above the current capacity is blocked with a toast.
- Installed apps, RAM level, and Credits persist per player using DataStore.
- Starting balance is 1,200 Credits for testing; change STARTING_CREDITS in AltheaBookServer.lua when connecting your economy.
- Virtual storage is 32 GB. App installation uses storage; RAM is allocated to open app windows.

INSTALLATION
1. Stop the Roblox Studio test session.
2. Import AltheaBookOS_AppStore.rbxmx using Workspace > Insert from File.
3. Move the imported folder named AltheaBookOS to StarterPlayer > StarterPlayerScripts.
   It contains AltheaOSWindowManager (ModuleScript) and RocketSciencePeriodicTable (LocalScript).
4. Import AltheaBookServer.rbxmx and move the Script AltheaBookServer to ServerScriptService.
5. Keep your existing AltheaBook Tool in StarterPack. Do not duplicate the Tool.
6. Disable/delete the older AltheaBook OS LocalScripts and old manager so only one OS boots.
7. For saved profiles, publish the experience and enable Game Settings > Security > Enable Studio Access to API Services for Studio testing.
8. Stop and Play again. Equip AltheaBook; open App Store from the Dock. Use RAM & Hardware to upgrade memory.

IMPORTANT NOTES
- DataStore calls are server-side. If API access is disabled, installs and upgrades still work for the current server session, but won't persist after leaving.
- This uses game Credits (not Robux). Costs are example balance values and are validated by the Server. Replace them when your economy system is ready.
- RAM is a gameplay simulation; it does not change actual Roblox/client memory use.
- Spectrum Lab and Material Workbench are app shells/placeholders ready for their real features.
- The Server owns profile, money, ownership, RAM tier and storage checks. Do not move purchase logic to a LocalScript.
