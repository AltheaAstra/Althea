-- AltheaBook Server Service
-- Place this Script in ServerScriptService. It owns credits, app installs, RAM upgrades,
-- storage validation, and persistent player profiles. Client UI never sets prices/capacity.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DataStoreService = game:GetService("DataStoreService")

local DATASTORE_NAME = "AltheaBookProfile_v1"
local STORAGE_CAPACITY_MB = 32768 -- 32 GB virtual SSD capacity for the game
local STARTING_CREDITS = 1200 -- replace with your game's economy later
local REQUEST_COOLDOWN = 0.12

local APP_CATALOG = {
    PeriodicTable = { Price = 0, SizeMB = 220, Protected = true },
    SpaceHub = { Price = 0, SizeMB = 180, Protected = false },
    ResearchLab = { Price = 250, SizeMB = 450, Protected = false },
    ResourceDatabase = { Price = 150, SizeMB = 360, Protected = false },
    Blueprints = { Price = 200, SizeMB = 320, Protected = false },
    MyFiles = { Price = 0, SizeMB = 100, Protected = false },
    Settings = { Price = 0, SizeMB = 80, Protected = true },
    SpectrumLab = { Price = 350, SizeMB = 480, Protected = false },
    MaterialWorkbench = { Price = 200, SizeMB = 400, Protected = false },
}

local RAM_TIERS = {
    [1] = { CapacityMB = 4096, Price = 0, Name = "4 GB" },
    [2] = { CapacityMB = 8192, Price = 350, Name = "8 GB" },
    [3] = { CapacityMB = 16384, Price = 800, Name = "16 GB" },
    [4] = { CapacityMB = 32768, Price = 1800, Name = "32 GB" },
}

local store = DataStoreService:GetDataStore(DATASTORE_NAME)
local profiles = {}
local lastRequestAt = {}
local savingAvailable = true

local remotes = ReplicatedStorage:FindFirstChild("AltheaBookRemotes")
if not remotes then
    remotes = Instance.new("Folder")
    remotes.Name = "AltheaBookRemotes"
    remotes.Parent = ReplicatedStorage
end
local requestRemote = remotes:FindFirstChild("Request")
if not requestRemote then
    requestRemote = Instance.new("RemoteFunction")
    requestRemote.Name = "Request"
    requestRemote.Parent = remotes
end

local function defaultProfile()
    return {
        Version = 1,
        Credits = STARTING_CREDITS,
        InstalledApps = {
            AppStore = true,
            PeriodicTable = true,
            Settings = true,
        },
        RAMLevel = 1,
    }
end

local function cloneDict(source)
    local result = {}
    if type(source) == "table" then
        for key, value in pairs(source) do
            if type(key) == "string" and value == true then
                result[key] = true
            end
        end
    end
    return result
end

local function normalizeProfile(raw)
    local profile = defaultProfile()
    if type(raw) == "table" then
        if type(raw.Credits) == "number" and raw.Credits >= 0 then
            profile.Credits = math.floor(raw.Credits)
        end
        if type(raw.RAMLevel) == "number" then
            profile.RAMLevel = math.clamp(math.floor(raw.RAMLevel), 1, #RAM_TIERS)
        end
        profile.InstalledApps = cloneDict(raw.InstalledApps)
        -- The store and system apps cannot be deleted by client-supplied save data.
        profile.InstalledApps.AppStore = true
        profile.InstalledApps.PeriodicTable = true
        profile.InstalledApps.Settings = true
        for appId in pairs(profile.InstalledApps) do
            if appId ~= "AppStore" and not APP_CATALOG[appId] then
                profile.InstalledApps[appId] = nil
            end
        end
    end
    return profile
end

local function getStorageUsed(profile)
    local used = 150 -- App Store system package
    for appId, installed in pairs(profile.InstalledApps) do
        if installed and appId ~= "AppStore" then
            local item = APP_CATALOG[appId]
            if item then
                used += item.SizeMB
            end
        end
    end
    return used
end

local function publicProfile(profile)
    local ram = RAM_TIERS[profile.RAMLevel] or RAM_TIERS[1]
    return {
        Version = profile.Version or 1,
        Credits = profile.Credits,
        InstalledApps = cloneDict(profile.InstalledApps),
        RAMLevel = profile.RAMLevel,
        RamCapacityMB = ram.CapacityMB,
        RamName = ram.Name,
        StorageCapacityMB = STORAGE_CAPACITY_MB,
        StorageUsedMB = getStorageUsed(profile),
    }
end

local function loadProfile(player)
    if profiles[player] then
        return profiles[player]
    end
    local loaded
    local ok, result = pcall(function()
        return store:GetAsync("u_" .. tostring(player.UserId))
    end)
    if ok then
        loaded = result
    else
        savingAvailable = false
        warn("AltheaBook: DataStore load failed; using session profile. Enable API Services for persistent saves.", result)
    end
    local profile = normalizeProfile(loaded)
    profiles[player] = profile
    return profile
end

local function saveProfile(player)
    local profile = profiles[player]
    if not profile then return false end
    if not savingAvailable then
        return false
    end
    local ok, err = pcall(function()
        store:SetAsync("u_" .. tostring(player.UserId), profile)
    end)
    if not ok then
        savingAvailable = false
        warn("AltheaBook: DataStore save failed. Changes remain for this server session only:", err)
    end
    return ok
end

local function responseFor(player, ok, message, profile)
    return {
        ok = ok,
        message = message,
        profile = publicProfile(profile),
        persistent = savingAvailable,
    }
end

local function fail(player, message, profile)
    return responseFor(player, false, message, profile)
end

requestRemote.OnServerInvoke = function(player, payload)
    if type(payload) ~= "table" or type(payload.action) ~= "string" then
        return { ok = false, message = "Invalid request." }
    end
    local profile = loadProfile(player)
    local action = payload.action

    if action == "GetProfile" then
        local message = "Profile loaded. Installs, Credits, and RAM upgrades are controlled by the Server."
        if not savingAvailable then
            message ..= " DataStore is unavailable, so changes may last only for this session."
        end
        return responseFor(player, true, message, profile)
    end

    local now = os.clock()
    if lastRequestAt[player] and now - lastRequestAt[player] < REQUEST_COOLDOWN then
        return fail(player, "Please wait a moment before the next request.", profile)
    end
    lastRequestAt[player] = now

    if action == "InstallApp" then
        local appId = payload.appId
        local item = type(appId) == "string" and APP_CATALOG[appId] or nil
        if not item then
            return fail(player, "This app is not available in the store.", profile)
        end
        if profile.InstalledApps[appId] then
            return responseFor(player, true, "" .. appId .. " is already installed.", profile)
        end
        if profile.Credits < item.Price then
            return fail(player, "Not enough Credits to install " .. appId .. ".", profile)
        end
        if getStorageUsed(profile) + item.SizeMB > STORAGE_CAPACITY_MB then
            return fail(player, "Not enough device storage. Remove an app before installing this one.", profile)
        end
        profile.Credits -= item.Price
        profile.InstalledApps[appId] = true
        local saved = saveProfile(player)
        local message = string.format("%s installed • %d MB storage used.", appId, getStorageUsed(profile))
        if not saved then message ..= " (Session only: DataStore saving is unavailable.)" end
        return responseFor(player, true, message, profile)

    elseif action == "UninstallApp" then
        local appId = payload.appId
        local item = type(appId) == "string" and APP_CATALOG[appId] or nil
        if not item then
            return fail(player, "This app cannot be removed.", profile)
        end
        if item.Protected then
            return fail(player, "System apps cannot be uninstalled.", profile)
        end
        if not profile.InstalledApps[appId] then
            return fail(player, "This app is not installed.", profile)
        end
        profile.InstalledApps[appId] = nil
        local saved = saveProfile(player)
        local message = appId .. " removed from this device."
        if not saved then message ..= " (Session only: DataStore saving is unavailable.)" end
        return responseFor(player, true, message, profile)

    elseif action == "UpgradeRAM" then
        local targetLevel = tonumber(payload.targetLevel)
        if not targetLevel or targetLevel % 1 ~= 0 then
            return fail(player, "Invalid RAM upgrade level.", profile)
        end
        targetLevel = math.floor(targetLevel)
        local target = RAM_TIERS[targetLevel]
        if not target then
            return fail(player, "That RAM tier is not available.", profile)
        end
        if targetLevel <= profile.RAMLevel then
            return fail(player, "This RAM tier is already owned.", profile)
        end
        if targetLevel ~= profile.RAMLevel + 1 then
            return fail(player, "Install the next RAM tier before upgrading further.", profile)
        end
        if profile.Credits < target.Price then
            return fail(player, "Not enough Credits for this RAM upgrade.", profile)
        end
        profile.Credits -= target.Price
        profile.RAMLevel = targetLevel
        local saved = saveProfile(player)
        local message = "AltheaBook upgraded to " .. target.Name .. " RAM."
        if not saved then message ..= " (Session only: DataStore saving is unavailable.)" end
        return responseFor(player, true, message, profile)
    end

    return fail(player, "Unknown AltheaBook request.", profile)
end

Players.PlayerAdded:Connect(function(player)
    loadProfile(player)
end)
for _, player in ipairs(Players:GetPlayers()) do
    task.spawn(loadProfile, player)
end
Players.PlayerRemoving:Connect(function(player)
    saveProfile(player)
    profiles[player] = nil
    lastRequestAt[player] = nil
end)

game:BindToClose(function()
    for _, player in ipairs(Players:GetPlayers()) do
        saveProfile(player)
    end
end)
