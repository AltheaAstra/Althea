# AltheaOS / AltheaBook V5 — Glass Desktop, Tabs, Swipe, Split View

## Project files
- `AltheaBook_RocketScience_V5.rbxlx`: full editable Studio place (XML place format). Open in Roblox Studio; then use File > Save to File if you want a binary `.rbxl` copy.
- `AltheaOS_V5_InstallKit.rbxmx`: importable folder containing the OS client/module, registry, server script, and AltheaBook Tool.
- Individual `.rbxmx` files are also included.
- `.lua` files are editable source copies.

## What's new in V5
- Top application tabs below the menu bar; only opened apps appear in the tabs.
- The Dock remains at the bottom and launches installed apps.
- Red close, yellow minimize, green maximize/restore controls.
- Drag and resize windows, with drag bounds leaving room for the menu and dock.
- Split View: click `▣ Split` in the menu bar or press F7. The manager opens a second installed app if one is not already open (subject to available simulated RAM), then displays two windows side by side.
- Swipe left/right on unused desktop wallpaper to switch open app tabs on touch devices; on keyboard, use Ctrl+Tab and Ctrl+Shift+Tab.
- When in Split View, a swipe switches focus between left and right panes. Selecting another app tab replaces the currently focused pane.
- Split View restores window bounds after exit; closing a pane or maximizing/minimizing exits Split View first.
- Reuses V4 client/server/App Registry logic for app catalog, Credits, RAM, battery, settings, My Files, AirDrop, App Requests, Supply, Map, AltheaTag, Jobs and market prototype.
- Glassmorphism uses UIGradient, UIStroke, UICorner and transparency. Roblox UI-to-UI background blur is not natively supported; BlurEffect only blurs the 3D scene.

## Open the full project
1. Download `AltheaBook_RocketScience_V5.rbxlx`.
2. In Roblox Studio, use File > Open from File and choose the `.rbxlx`.
3. Press Play. Equip AltheaBook in the hotbar (key 1) to open the desktop.
4. Open two apps from the bottom Dock; use the top tabs to switch between them.
5. Click Split or press F7 for two side-by-side apps. Click Split again to exit.
6. Swipe horizontally on a free area of the desktop wallpaper to change active app; on PC use Ctrl+Tab or Ctrl+Shift+Tab.
7. Test maximize/restore, minimize, close, dock auto-hide, Battery and AirDrop.

## Install into an existing Rocket Science place
1. Back up the existing place and stop Play Test.
2. Import `AltheaOS_V5_InstallKit.rbxmx` into Workspace as a temporary model.
3. Move `AltheaBookOS` to `StarterPlayer > StarterPlayerScripts`.
4. Move `AltheaAppRegistry` to `ReplicatedStorage`.
5. Move `AltheaBookServer` to `ServerScriptService`, then select it and set `Disabled = false` in Properties (it is disabled in the import kit to prevent accidental execution while the kit is in Workspace).
6. Move `AltheaBook` Tool to `StarterPack`.
7. Delete the temporary `AltheaOS_V5_InstallKit` wrapper folder after moving its children.
8. Disable/remove old AltheaBook OS client and server scripts so there is exactly one active copy. Both `AltheaBookClient` and `AltheaOSWindowManager` must be siblings inside `AltheaBookOS` because the client uses `script.Parent:WaitForChild("AltheaOSWindowManager")`.
9. If the experience uses an older profile/DataStore schema, test in a separate published test experience first and enable API Services only there.
10. Press Stop then Play. Inspect View > Output for any remaining errors.

## Explorer hierarchy
ReplicatedStorage
  - ModuleScript `AltheaAppRegistry`
ServerScriptService
  - Script `AltheaBookServer`
  - Script `AltheaV5DemoSetup` (only in the full demo place; creates demo map markers/rocket; remove or replace in a real game)
StarterPlayer
  - StarterPlayerScripts
    - Folder `AltheaBookOS`
      - LocalScript `AltheaBookClient`
      - ModuleScript `AltheaOSWindowManager`
StarterPack
  - Tool `AltheaBook`
    - Part `Handle`
    - LocalScript `AltheaBookToolClient`
Workspace
  - Baseplate
  - SpawnLocation
  - AltheaCharger
  - launch/refinery map markers

## Notes and limitations
- `.rbxlx` is a valid text-based Roblox place format; this tool cannot produce Roblox Studio's proprietary binary `.rbxl` directly. Studio can save the opened place as `.rbxl`.
- Split View means two app windows side by side in one Roblox game viewport, not actual multi-monitor output.
- Swipes start only on a free wallpaper area so lists, buttons, and window content keep normal touch behavior.
- All app code is packaged in the experience; the App Store does not download and execute arbitrary scripts.
- The existing Supply, Global Exchange, Jobs, Map, and AltheaTag remain V4 prototypes and depend on actual inventory, rocket and mission systems for full production behavior.
- Not tested in Roblox Studio in this environment; please run the smoke tests below before merging into the live game.

## Smoke test checklist
- [ ] Place opens in Studio and Play starts without Output errors.
- [ ] Desktop stays hidden at spawn and opens when AltheaBook is equipped.
- [ ] Top tabs appear only for opened apps and switch the active window.
- [ ] Dock icons continue to launch installed apps.
- [ ] Drag, resize, minimize, maximize, restore, close.
- [ ] Open two apps, split them side-by-side, switch focus, exit Split View.
- [ ] Ctrl+Tab / Ctrl+Shift+Tab switch apps; swipe on empty wallpaper changes apps on touch.
- [ ] Closing an app while split restores window bounds and does not leave stale split state.
- [ ] Closing AltheaBook restores Roblox Backpack/CoreGui state and clears blur.
- [ ] App Store / Credits / Battery / Settings / My Files / AirDrop basic flows.
- [ ] Check DataStore/API errors in Output with a test place.
