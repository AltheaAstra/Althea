-- AltheaBook / AltheaOS Window Manager V5
-- Place beside AltheaBookClient in StarterPlayerScripts > AltheaBookOS as ModuleScript AltheaOSWindowManager.
-- V5: macOS-inspired top app tabs, split view, desktop swipe navigation, glass UI.
-- The OS stays hidden until the player equips and activates AltheaBook.

local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")
local UserInputService = game:GetService("UserInputService")
local GuiService = game:GetService("GuiService")
local StarterGui = game:GetService("StarterGui")
local TweenService = game:GetService("TweenService")

local WindowManager = {}
WindowManager.__index = WindowManager
WindowManager.VERSION = "5.0.0"

local managerCache = setmetatable({}, { __mode = "k" })

local COLORS = {
    bar = Color3.fromRGB(13, 25, 40),
    barStroke = Color3.fromRGB(115, 158, 194),
    tab = Color3.fromRGB(24, 43, 61),
    tabActive = Color3.fromRGB(39, 70, 96),
    text = Color3.fromRGB(242, 247, 253),
    muted = Color3.fromRGB(169, 190, 209),
    accent = Color3.fromRGB(120, 191, 255),
    danger = Color3.fromRGB(232, 112, 119),
    button = Color3.fromRGB(31, 55, 77),
}

local function make(className, parent, props)
    local object = Instance.new(className)
    for key, value in pairs(props or {}) do
        object[key] = value
    end
    object.Parent = parent
    return object
end

local function addCorner(parent, radius)
    return make("UICorner", parent, { CornerRadius = UDim.new(0, radius or 8) })
end

local function addStroke(parent, color, thickness, transparency)
    return make("UIStroke", parent, {
        Color = color or COLORS.barStroke,
        Thickness = thickness or 1,
        Transparency = transparency or 0,
    })
end


-- Shared AltheaOS Glassmorphism style. Roblox UI does not blur other GuiObjects
-- underneath; this creates a frosted-glass look using translucency, gradient and edge light.
local GLASS = {
    surface = Color3.fromRGB(17, 31, 47),
    header = Color3.fromRGB(26, 49, 70),
    top = Color3.fromRGB(57, 91, 121),
    mid = Color3.fromRGB(23, 43, 63),
    bottom = Color3.fromRGB(11, 21, 34),
    edge = Color3.fromRGB(182, 221, 255),
}

local function styleGlass(guiObject, kind)
    if not guiObject or not guiObject:IsA("GuiObject") then return end
    kind = kind or "panel"
    guiObject.BorderSizePixel = 0
    guiObject.BackgroundColor3 = kind == "header" and GLASS.header or GLASS.surface
    guiObject.BackgroundTransparency = kind == "header" and 0.12 or 0.16

    if not guiObject:FindFirstChildOfClass("UICorner") then
        addCorner(guiObject, kind == "dock" and 18 or (kind == "header" and 12 or 14))
    end

    local gradient = guiObject:FindFirstChild("AltheaGlassGradient")
    if not gradient then
        gradient = guiObject:FindFirstChildOfClass("UIGradient")
        if gradient then
            gradient.Name = "AltheaGlassGradient"
        else
            gradient = Instance.new("UIGradient")
            gradient.Name = "AltheaGlassGradient"
            gradient.Parent = guiObject
        end
    end
    gradient.Rotation = kind == "header" and 0 or 28
    gradient.Color = ColorSequence.new({
        ColorSequenceKeypoint.new(0, GLASS.top),
        ColorSequenceKeypoint.new(0.46, GLASS.mid),
        ColorSequenceKeypoint.new(1, GLASS.bottom),
    })
    gradient.Transparency = NumberSequence.new({
        NumberSequenceKeypoint.new(0, kind == "header" and 0.10 or 0.16),
        NumberSequenceKeypoint.new(0.55, 0.04),
        NumberSequenceKeypoint.new(1, 0.14),
    })

    local stroke = guiObject:FindFirstChild("AltheaGlassStroke")
    if not stroke then
        stroke = Instance.new("UIStroke")
        stroke.Name = "AltheaGlassStroke"
        stroke.Parent = guiObject
    end
    stroke.Color = GLASS.edge
    stroke.Thickness = 1
    stroke.Transparency = kind == "header" and 0.70 or 0.78
end

local function setZTree(guiObject, zIndex, depth)
    depth = depth or 0
    guiObject.ZIndex = zIndex + depth
    for _, child in ipairs(guiObject:GetChildren()) do
        if child:IsA("GuiObject") then
            setZTree(child, zIndex, depth + 1)
        end
    end
end

local function getViewportSize()
    local camera = workspace.CurrentCamera
    if camera then
        return camera.ViewportSize
    end
    return Vector2.new(1280, 720)
end

local function getTopLeftInset()
    -- AltheaBook_Shell uses IgnoreGuiInset = true, so drag coordinates use the full-screen canvas.
    -- Do not subtract Roblox's CoreUI inset or windows will jump upward/sideways while dragging.
    return Vector2.new(0, 0)
end

local function isPointerBegin(input)
    return input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch
end

function WindowManager.new(playerGui)
    playerGui = playerGui or Players.LocalPlayer:WaitForChild("PlayerGui")

    if managerCache[playerGui] then
        return managerCache[playerGui]
    end

    -- Remove stale shell/effect from earlier script versions so duplicated UI or blur cannot remain stuck.
    local staleShell = playerGui:FindFirstChild("AltheaOS_Shell")
    if staleShell then
        staleShell:Destroy()
    end
    local currentCamera = workspace.CurrentCamera
    if currentCamera then
        local staleBlur = currentCamera:FindFirstChild("AltheaOS_LocalBlur")
        if staleBlur and staleBlur:IsA("BlurEffect") then
            staleBlur:Destroy()
        end
    end
    local staleLightingBlur = Lighting:FindFirstChild("AltheaOS_LocalBlur")
    if staleLightingBlur and staleLightingBlur:IsA("BlurEffect") then
        staleLightingBlur:Destroy()
    end

    local self = setmetatable({}, WindowManager)
    self.playerGui = playerGui
    self.windows = {}
    self.openOrder = {}
    self.registeredOrder = {}
    self.activeName = nil
    self.minimized = {}
    self.splitMode = false
    self.splitWindows = { left = nil, right = nil }
    self.splitFocusSide = "left"
    self.splitSavedBounds = {}
    self.splitWasMaximized = {}
    self._swipeStart = nil
    self.dockVisible = false
    self.dockPinned = false
    self.desktopOpen = false
    self._previousBackpackEnabled = nil
    self._dockHideToken = 0
    self.dockAutoHideEnabled = true
    self.reducedMotion = false
    self.showBatteryPercent = true
    self.batteryPercent = 100
    -- System menu event is local-only: top-bar controls can launch system apps without globals.
    local localPlayer = Players.LocalPlayer
    self.playerScripts = localPlayer and localPlayer:WaitForChild("PlayerScripts") or nil
    if self.playerScripts then
        local oldEvent = self.playerScripts:FindFirstChild("AltheaOSSystemMenuEvent")
        if oldEvent and not oldEvent:IsA("BindableEvent") then
            oldEvent:Destroy()
            oldEvent = nil
        end
        if not oldEvent then
            oldEvent = Instance.new("BindableEvent")
            oldEvent.Name = "AltheaOSSystemMenuEvent"
            oldEvent.Parent = self.playerScripts
        end
        self.systemMenuEvent = oldEvent
    end
    self._dockTween = nil
    self.maximized = {}
    self.interaction = nil
    -- Simulated hardware capacity. The Server profile replaces this after loading.
    self.ramCapacityMB = 4096
    self.toast = nil

    local screenGui = make("ScreenGui", playerGui, {
        Name = "AltheaOS_Shell",
        ResetOnSpawn = false,
        -- Full-screen macOS-inspired desktop canvas. Roblox CoreGui itself is not destroyed.
        IgnoreGuiInset = true,
        DisplayOrder = 10000,
        ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
        Enabled = false, -- IMPORTANT: no OS GUI appears until the laptop is activated.
    })
    self.screenGui = screenGui

    -- Cinematic, procedural space wallpaper. No uploaded image asset is required.
    self.wallpaper = make("Frame", screenGui, {
        Name = "AltheaOS_Wallpaper",
        Size = UDim2.fromScale(1, 1),
        Position = UDim2.fromScale(0, 0),
        BackgroundColor3 = Color3.fromRGB(11, 19, 38),
        BorderSizePixel = 0,
        ZIndex = 1,
        Active = true, -- receive swipes only when the pointer starts on the desktop background
    })
    make("UIGradient", self.wallpaper, {
        Rotation = 28,
        Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(18, 37, 67)),
            ColorSequenceKeypoint.new(0.48, Color3.fromRGB(22, 31, 56)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(8, 13, 25)),
        }),
    })
    local planet = make("Frame", self.wallpaper, {
        Name = "BluePlanetGlow",
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(0.79, 0, 0.34, 0),
        Size = UDim2.fromOffset(330, 330),
        BackgroundColor3 = Color3.fromRGB(42, 96, 158),
        BackgroundTransparency = 0.32,
        BorderSizePixel = 0,
        ZIndex = 1,
    })
    addCorner(planet, 200)
    self.planet = planet
    self.wallpaperGradient = self.wallpaper:FindFirstChildOfClass("UIGradient")
    make("UIGradient", planet, {
        Rotation = 35,
        Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(99, 158, 216)),
            ColorSequenceKeypoint.new(0.55, Color3.fromRGB(45, 90, 151)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(25, 35, 79)),
        }),
    })
    local horizon = make("Frame", self.wallpaper, {
        Name = "DistantHorizon",
        Position = UDim2.new(0, 0, 0.77, 0),
        Size = UDim2.new(1, 0, 0.23, 0),
        BackgroundColor3 = Color3.fromRGB(8, 14, 28),
        BackgroundTransparency = 0.14,
        BorderSizePixel = 0,
        ZIndex = 1,
    })
    self.horizon = horizon
    make("UIGradient", horizon, {
        Rotation = 90,
        Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(27, 44, 70)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(6, 10, 20)),
        }),
    })
    local stars = {
        {0.06,0.14,2},{0.12,0.33,1},{0.18,0.11,2},{0.24,0.24,1},{0.30,0.08,1},
        {0.37,0.18,2},{0.43,0.09,1},{0.51,0.27,1},{0.58,0.12,2},{0.64,0.22,1},
        {0.71,0.08,1},{0.84,0.12,1},{0.91,0.27,2},{0.96,0.09,1},{0.08,0.51,1},
        {0.17,0.62,1},{0.29,0.47,1},{0.40,0.54,1},{0.55,0.48,1},{0.69,0.57,1},
        {0.88,0.48,1},{0.94,0.63,1},{0.04,0.73,1},{0.31,0.72,1},{0.62,0.70,1},
    }
    for i, star in ipairs(stars) do
        local dot = make("Frame", self.wallpaper, {
            Name = "Star" .. tostring(i),
            Position = UDim2.new(star[1], 0, star[2], 0),
            Size = UDim2.fromOffset(star[3], star[3]),
            BackgroundColor3 = Color3.fromRGB(207, 224, 255),
            BackgroundTransparency = 0.28,
            BorderSizePixel = 0,
            ZIndex = 1,
        })
        addCorner(dot, 4)
    end
    make("TextLabel", self.wallpaper, {
        Name = "WallpaperTitle",
        Position = UDim2.new(0, 30, 0.64, 0),
        Size = UDim2.new(0, 360, 0, 56),
        BackgroundTransparency = 1,
        Text = "ROCKET SCIENCE",
        TextColor3 = Color3.fromRGB(205, 218, 238),
        TextTransparency = 0.38,
        TextSize = 27,
        Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
        ZIndex = 1,
    })
    make("TextLabel", self.wallpaper, {
        Name = "WallpaperSubtitle",
        Position = UDim2.new(0, 32, 0.64, 35),
        Size = UDim2.new(0, 380, 0, 24),
        BackgroundTransparency = 1,
        Text = "ALTHEA SPACE  /  EXPLORATION SYSTEMS",
        TextColor3 = Color3.fromRGB(159, 180, 210),
        TextTransparency = 0.30,
        TextSize = 10,
        Font = Enum.Font.GothamMedium,
        TextXAlignment = Enum.TextXAlignment.Left,
        ZIndex = 1,
    })

    -- macOS-inspired menu bar stays at the top of the game's safe area.
    self.menuBar = make("Frame", screenGui, {
        Name = "AltheaOS_MenuBar",
        Position = UDim2.fromOffset(0, 0),
        Size = UDim2.new(1, 0, 0, 32),
        BackgroundColor3 = Color3.fromRGB(13, 25, 40),
        BackgroundTransparency = 0.18,
        BorderSizePixel = 0,
        ZIndex = 350,
    })
    styleGlass(self.menuBar, "header")
    make("TextLabel", self.menuBar, {
        Name = "AltheaMark",
        Position = UDim2.fromOffset(12, 0),
        Size = UDim2.fromOffset(24, 32),
        BackgroundTransparency = 1,
        Text = "A",
        TextColor3 = Color3.fromRGB(236, 242, 251),
        TextSize = 20,
        Font = Enum.Font.GothamBold,
        ZIndex = 351,
    })
    make("TextLabel", self.menuBar, {
        Name = "SystemName",
        Position = UDim2.fromOffset(42, 0),
        Size = UDim2.fromOffset(124, 32),
        BackgroundTransparency = 1,
        Text = "AltheaBook",
        TextColor3 = Color3.fromRGB(243, 246, 251),
        TextSize = 13,
        Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
        ZIndex = 351,
    })
    local menuNames = {"File", "Edit", "View", "Window", "Help"}
    for i, label in ipairs(menuNames) do
        make("TextLabel", self.menuBar, {
            Name = "Menu_" .. label,
            Position = UDim2.fromOffset(170 + (i - 1) * 57, 0),
            Size = UDim2.fromOffset(55, 32),
            BackgroundTransparency = 1,
            Text = label,
            TextColor3 = Color3.fromRGB(212, 221, 236),
            TextSize = 12,
            Font = Enum.Font.Gotham,
            ZIndex = 351,
        })
    end
    self.systemStatusButton = make("TextButton", self.menuBar, {
        Name = "SystemStatus",
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.new(1, -48, 0, 0),
        Size = UDim2.fromOffset(195, 32),
        BackgroundTransparency = 1,
        Text = "Wi-Fi    ▰ 100%",
        TextColor3 = Color3.fromRGB(227, 234, 246),
        TextSize = 11,
        Font = Enum.Font.Gotham,
        TextXAlignment = Enum.TextXAlignment.Right,
        AutoButtonColor = false,
        ZIndex = 351,
    })
    self.systemStatusButton.Activated:Connect(function()
        if self.systemMenuEvent then
            self.systemMenuEvent:Fire("Battery")
        end
    end)
    self.clockLabel = make("TextLabel", self.menuBar, {
        Name = "ClockLabel",
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.new(1, -250, 0, 0),
        Size = UDim2.fromOffset(66, 32),
        BackgroundTransparency = 1,
        Text = os.date("%H:%M"),
        TextColor3 = Color3.fromRGB(227, 234, 246),
        TextSize = 11,
        Font = Enum.Font.Gotham,
        TextXAlignment = Enum.TextXAlignment.Right,
        ZIndex = 351,
    })
    self.splitButton = make("TextButton", self.menuBar, {
        Name = "SplitViewButton",
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -322, 0.5, 0),
        Size = UDim2.fromOffset(58, 24),
        BackgroundColor3 = Color3.fromRGB(36, 57, 78),
        BackgroundTransparency = 0.16,
        BorderSizePixel = 0,
        Text = "▣ Split",
        TextColor3 = Color3.fromRGB(225, 239, 252),
        TextSize = 10,
        Font = Enum.Font.GothamMedium,
        AutoButtonColor = true,
        ZIndex = 352,
    })
    addCorner(self.splitButton, 8)
    addStroke(self.splitButton, Color3.fromRGB(127, 184, 223), 1, 0.42)
    self.splitButton.Activated:Connect(function()
        self:ToggleSplitView()
    end)

    task.spawn(function()
        while self.screenGui and self.screenGui.Parent do
            if self.clockLabel and self.clockLabel.Parent then
                self.clockLabel.Text = os.date("%H:%M")
            else
                break
            end
            task.wait(15)
        end
    end)
    self.powerButton = make("TextButton", self.menuBar, {
        Name = "CloseDesktopButton",
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -12, 0.5, 0),
        Size = UDim2.fromOffset(25, 24),
        BackgroundColor3 = Color3.fromRGB(75, 39, 48),
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        Text = "⏻",
        TextColor3 = Color3.fromRGB(255, 202, 202),
        TextSize = 15,
        Font = Enum.Font.GothamBold,
        AutoButtonColor = true,
        ZIndex = 352,
    })
    addCorner(self.powerButton, 7)
    self.powerButton.Activated:Connect(function()
        self:CloseDesktop()
    end)

    -- V5 top application tab strip. Only open windows appear here; installed apps remain in Dock.
    self.topTabBar = make("Frame", screenGui, {
        Name = "AltheaOS_TopTabBar",
        Position = UDim2.fromOffset(0, 33),
        Size = UDim2.new(1, 0, 0, 34),
        BackgroundColor3 = Color3.fromRGB(18, 31, 46),
        BackgroundTransparency = 0.14,
        BorderSizePixel = 0,
        ZIndex = 350,
        Visible = true,
    })
    styleGlass(self.topTabBar, "header")
    self.topTabScroll = make("ScrollingFrame", self.topTabBar, {
        Name = "OpenApplicationTabs",
        Position = UDim2.fromOffset(10, 3),
        Size = UDim2.new(1, -20, 1, -6),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        CanvasSize = UDim2.new(0, 0, 0, 0),
        AutomaticCanvasSize = Enum.AutomaticSize.X,
        ScrollingDirection = Enum.ScrollingDirection.X,
        ScrollBarThickness = 0,
        ScrollBarImageTransparency = 1,
        ClipsDescendants = true,
        ZIndex = 351,
    })
    self.topTabLayout = make("UIListLayout", self.topTabScroll, {
        FillDirection = Enum.FillDirection.Horizontal,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0, 6),
        VerticalAlignment = Enum.VerticalAlignment.Center,
    })
    self.emptyTabsLabel = make("TextLabel", self.topTabBar, {
        Name = "EmptyTabsHint",
        Position = UDim2.fromOffset(18, 0),
        Size = UDim2.new(1, -36, 1, 0),
        BackgroundTransparency = 1,
        Text = "No open windows  ·  launch an app from Dock",
        TextColor3 = COLORS.muted,
        TextSize = 11,
        Font = Enum.Font.Gotham,
        TextXAlignment = Enum.TextXAlignment.Left,
        ZIndex = 352,
    })

    self.wallpaper.InputBegan:Connect(function(input)
        if not self.desktopOpen or not isPointerBegin(input) then return end
        self._swipeStart = {
            inputType = input.UserInputType,
            pointerStart = Vector2.new(input.Position.X, input.Position.Y),
            startedAt = os.clock(),
        }
    end)

    self.shade = make("TextButton", screenGui, {
        Name = "ModalShield",
        Size = UDim2.fromScale(1, 1),
        Position = UDim2.fromScale(0, 0),
        BackgroundColor3 = Color3.fromRGB(3, 7, 12),
        BackgroundTransparency = 0.42,
        BorderSizePixel = 0,
        Text = "",
        AutoButtonColor = false,
        Active = true,
        Modal = true,
        Visible = false,
        ZIndex = 2,
    })

    -- macOS-inspired Dock: hidden by default and shown only on hover / bottom-edge activation.
    -- All registered apps stay in the Dock; their windows remain closed until an icon is clicked.
    self.dock = make("Frame", screenGui, {
        Name = "AltheaOS_Dock",
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, 92),
        Size = UDim2.fromOffset(110, 70),
        BackgroundColor3 = Color3.fromRGB(31, 50, 69),
        BackgroundTransparency = 0.18,
        BorderSizePixel = 0,
        Visible = false,
        ZIndex = 400,
    })
    addCorner(self.dock, 19)
    addStroke(self.dock, Color3.fromRGB(190, 222, 248), 1, 0.38)
    make("UIGradient", self.dock, { Rotation = 90, Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(67, 100, 130)), ColorSequenceKeypoint.new(1, Color3.fromRGB(21, 34, 49)) }) })
    styleGlass(self.dock, "dock")

    self.dockScroll = make("ScrollingFrame", self.dock, {
        Name = "DockApps",
        Position = UDim2.fromOffset(8, 6),
        Size = UDim2.new(1, -16, 1, -12),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        CanvasSize = UDim2.new(0, 0, 0, 0),
        AutomaticCanvasSize = Enum.AutomaticSize.X,
        ScrollingDirection = Enum.ScrollingDirection.X,
        ScrollBarThickness = 0,
        ScrollBarImageTransparency = 1,
        ClipsDescendants = true,
        ZIndex = 401,
    })
    self.dockLayout = make("UIListLayout", self.dockScroll, {
        FillDirection = Enum.FillDirection.Horizontal,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0, 7),
        VerticalAlignment = Enum.VerticalAlignment.Center,
    })

    -- Tiny permanent handle for touch users and as a discoverable desktop hover target.
    self.dockHandle = make("TextButton", screenGui, {
        Name = "AltheaOS_DockHandle",
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, -1),
        Size = UDim2.fromOffset(120, 24),
        BackgroundColor3 = Color3.fromRGB(212, 219, 230),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        Text = "",
        AutoButtonColor = false,
        Visible = false, -- shown only while the desktop is open
        ZIndex = 390,
    })
    -- Larger transparent hit target with a small visible grabber, more forgiving on touch.
    make("Frame", self.dockHandle, {
        Name = "Grip",
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, -2),
        Size = UDim2.fromOffset(68, 4),
        BackgroundColor3 = Color3.fromRGB(212, 219, 230),
        BackgroundTransparency = 0.18,
        BorderSizePixel = 0,
        ZIndex = 391,
    })
    addCorner(self.dockHandle.Grip, 4)
    self.dockHandle.Activated:Connect(function()
        self:ShowDock()
        if not self.dockPinned then
            self:_scheduleDockHide(5, true)
        end
    end)

    -- Parent the post-effect to CurrentCamera so this remains a per-player UI effect.
    local blurParent = workspace.CurrentCamera or Lighting
    self.blur = blurParent:FindFirstChild("AltheaOS_LocalBlur")
    if not self.blur or not self.blur:IsA("BlurEffect") then
        self.blur = Instance.new("BlurEffect")
        self.blur.Name = "AltheaOS_LocalBlur"
    end
    self.blur.Size = 0
    self.blur.Parent = blurParent

    workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
        local currentCamera = workspace.CurrentCamera
        if currentCamera and self.blur then
            self.blur.Parent = currentCamera
            currentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(function()
                if self.splitMode then self:_applySplitLayout() end
            end)
        end
    end)
    if workspace.CurrentCamera then
        workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(function()
            if self.splitMode then self:_applySplitLayout() end
        end)
    end

    UserInputService.InputChanged:Connect(function(input)
        self:_handleInputChanged(input)
        self:_handleDockPointer(input)
    end)
    UserInputService.InputEnded:Connect(function(input)
        self:_handleInputEnded(input)
        self:_handleSwipeEnded(input)
    end)
    UserInputService.InputBegan:Connect(function(input, gameProcessed)
        if gameProcessed then
            return
        end
        if not self.desktopOpen then
            return
        end
        if input.KeyCode == Enum.KeyCode.F6 then
            -- F6 toggles the Dock auto-hide preference.
            self:SetDockAutoHide(not self.dockAutoHideEnabled)
            return
        elseif input.KeyCode == Enum.KeyCode.F7 then
            self:ToggleSplitView()
            return
        elseif input.KeyCode == Enum.KeyCode.Tab and (UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) or UserInputService:IsKeyDown(Enum.KeyCode.RightControl)) then
            local backwards = UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) or UserInputService:IsKeyDown(Enum.KeyCode.RightShift)
            self:SwipeTabs(backwards and -1 or 1)
            return
        end
        if input.KeyCode == Enum.KeyCode.Escape and self.activeName then
            local record = self.windows[self.activeName]
            if record and record.options.EscapeCloses ~= false then
                self:CloseWindow(self.activeName)
            end
        end
    end)

    self:SetBatteryPercent(100, false)
    managerCache[playerGui] = self
    return self
end

function WindowManager:SetBatteryPercent(percent, charging)
    self.batteryPercent = math.clamp(tonumber(percent) or 100, 0, 100)
    self.batteryCharging = charging == true
    if self.systemStatusButton then
        local batteryText = self.showBatteryPercent and (tostring(math.floor(self.batteryPercent + 0.5)) .. "%") or ""
        local chargingMark = self.batteryCharging and " ⚡" or ""
        local suffix = batteryText ~= "" and ("  ▰ " .. batteryText) or "  ▰"
        self.systemStatusButton.Text = "Wi-Fi" .. suffix .. chargingMark
        self.systemStatusButton.TextColor3 = self.batteryPercent <= 15
            and Color3.fromRGB(255, 158, 148)
            or Color3.fromRGB(227, 234, 246)
    end
end

function WindowManager:SetShowBatteryPercent(enabled)
    self.showBatteryPercent = enabled == true
    self:SetBatteryPercent(self.batteryPercent, self.batteryCharging)
end

function WindowManager:SetDockAutoHide(enabled)
    self.dockAutoHideEnabled = enabled == true
    self.dockPinned = not self.dockAutoHideEnabled
    if self.dockAutoHideEnabled then
        self:HideDock()
    else
        self:ShowDock()
    end
end

function WindowManager:SetReducedMotion(enabled)
    self.reducedMotion = enabled == true
end

function WindowManager:SetWallpaperStyle(style)
    style = tostring(style or "Orbit")
    self.wallpaperStyle = style
    local presets = {
        Orbit = {
            background = Color3.fromRGB(11, 19, 38),
            colors = {Color3.fromRGB(18, 37, 67), Color3.fromRGB(22, 31, 56), Color3.fromRGB(8, 13, 25)},
            planet = Color3.fromRGB(42, 96, 158), horizon = Color3.fromRGB(8, 14, 28),
        },
        Aurora = {
            background = Color3.fromRGB(10, 28, 42),
            colors = {Color3.fromRGB(22, 91, 104), Color3.fromRGB(32, 49, 91), Color3.fromRGB(8, 14, 28)},
            planet = Color3.fromRGB(58, 153, 150), horizon = Color3.fromRGB(6, 19, 28),
        },
        Midnight = {
            background = Color3.fromRGB(5, 8, 17),
            colors = {Color3.fromRGB(19, 25, 45), Color3.fromRGB(12, 17, 32), Color3.fromRGB(3, 5, 12)},
            planet = Color3.fromRGB(51, 67, 110), horizon = Color3.fromRGB(4, 6, 14),
        },
        Dawn = {
            background = Color3.fromRGB(41, 29, 43),
            colors = {Color3.fromRGB(105, 74, 103), Color3.fromRGB(65, 60, 105), Color3.fromRGB(11, 17, 36)},
            planet = Color3.fromRGB(176, 114, 147), horizon = Color3.fromRGB(22, 18, 39),
        },
    }
    local preset = presets[style] or presets.Orbit
    if self.wallpaper then
        self.wallpaper.BackgroundColor3 = preset.background
        local gradient = self.wallpaper:FindFirstChildOfClass("UIGradient")
        if gradient then
            gradient.Color = ColorSequence.new({
                ColorSequenceKeypoint.new(0, preset.colors[1]),
                ColorSequenceKeypoint.new(0.52, preset.colors[2]),
                ColorSequenceKeypoint.new(1, preset.colors[3]),
            })
        end
    end
    if self.planet then self.planet.BackgroundColor3 = preset.planet end
    if self.horizon then self.horizon.BackgroundColor3 = preset.horizon end
end

function WindowManager:ShowDock()
    if not self.dock or not self.desktopOpen then
        return
    end
    self._dockHideToken += 1
    if self.dockVisible then
        return
    end
    self.dockVisible = true
    self.dock.Visible = true
    if self._dockTween then
        self._dockTween:Cancel()
    end
    self._dockTween = TweenService:Create(
        self.dock,
        TweenInfo.new(self.reducedMotion and 0 or 0.20, Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
        { Position = UDim2.new(0.5, 0, 1, -10) }
    )
    self._dockTween:Play()
end

function WindowManager:HideDock()
    if not self.dock or not self.dockVisible or self.dockPinned then
        return
    end
    self._dockHideToken += 1
    self.dockVisible = false
    if self._dockTween then
        self._dockTween:Cancel()
    end
    local tween = TweenService:Create(
        self.dock,
        TweenInfo.new(self.reducedMotion and 0 or 0.18, Enum.EasingStyle.Quint, Enum.EasingDirection.In),
        { Position = UDim2.new(0.5, 0, 1, 92) }
    )
    self._dockTween = tween
    tween.Completed:Connect(function()
        if not self.dockVisible and not self.dockPinned and self.dock then
            self.dock.Visible = false
        end
    end)
    tween:Play()
end

function WindowManager:_pointerIsNearDock()
    local pointer = UserInputService:GetMouseLocation()
    local viewport = getViewportSize()
    if pointer.Y >= viewport.Y - 14 then
        return true
    end
    if self.dock and self.dock.Visible then
        local p = self.dock.AbsolutePosition
        local z = self.dock.AbsoluteSize
        if pointer.X >= p.X and pointer.X <= p.X + z.X
            and pointer.Y >= p.Y and pointer.Y <= p.Y + z.Y then
            return true
        end
    end
    return false
end

function WindowManager:_scheduleDockHide(delaySeconds, force)
    if self.dockPinned or not self.dockVisible then
        return
    end
    self._dockHideToken += 1
    local token = self._dockHideToken
    task.delay(delaySeconds or 0.85, function()
        if token ~= self._dockHideToken or self.dockPinned or not self.dockVisible then
            return
        end
        if force or not self:_pointerIsNearDock() then
            self:HideDock()
        end
    end)
end

function WindowManager:_handleDockPointer(input)
    if not self.desktopOpen or not self.dockAutoHideEnabled then
        return
    end
    if input.UserInputType ~= Enum.UserInputType.MouseMovement then
        return
    end
    if self.dockPinned then
        return
    end
    if self:_pointerIsNearDock() then
        self:ShowDock()
    elseif self.dockVisible then
        self:_scheduleDockHide(0.85, false)
    end
end

function WindowManager:_makeControlButton(header, name, text, xOffset, color)
    local button = make("TextButton", header, {
        Name = name,
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.new(0, xOffset, 0.5, 0),
        Size = UDim2.fromOffset(14, 14),
        BackgroundColor3 = color or COLORS.button,
        BorderSizePixel = 0,
        Text = "",
        TextColor3 = COLORS.text,
        TextSize = 1,
        Font = Enum.Font.GothamMedium,
        AutoButtonColor = true,
    })
    addCorner(button, 10)
    addStroke(button, color or COLORS.barStroke, 1, 0.45)
    button.ZIndex = header.ZIndex + 1
    return button
end

function WindowManager:_makeTab(record)
    local defaultIcons = {
        ["Periodic Table"] = "⚛",
        ["Research Lab"] = "⚗",
        ["Resource Database"] = "▤",
        ["Blueprints"] = "▧",
        ["Settings"] = "⚙",
    }
    local iconText = record.options.DockIcon or defaultIcons[record.name] or string.upper(string.sub(record.name, 1, 1))
    local tab = make("TextButton", self.dockScroll, {
        Name = "DockApp_" .. record.name:gsub("[^%w_]", ""),
        Size = UDim2.fromOffset(48, 48),
        BackgroundColor3 = COLORS.button,
        BackgroundTransparency = 0.38,
        BorderSizePixel = 0,
        Text = iconText,
        TextColor3 = COLORS.text,
        TextSize = #iconText > 2 and 20 or 24,
        Font = Enum.Font.GothamMedium,
        AutoButtonColor = true,
        LayoutOrder = record.launchOrder or 1,
        Visible = record.installed == true,
        ZIndex = 402,
    })
    addCorner(tab, 14)
    local stroke = addStroke(tab, COLORS.barStroke, 1, 0.48)

    local runningDot = make("Frame", tab, {
        Name = "RunningIndicator",
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, -2),
        Size = UDim2.fromOffset(5, 5),
        BackgroundColor3 = COLORS.accent,
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        Visible = false,
        ZIndex = 404,
    })
    addCorner(runningDot, 3)

    record.tabButton = tab
    record.tabStroke = stroke
    record.runningDot = runningDot
    tab.Activated:Connect(function()
        if table.find(self.openOrder, record.name) then
            self:ActivateWindow(record.name)
        else
            self:OpenWindow(record.name)
        end
        self:ShowDock()
        if not self.dockPinned then
            self:_scheduleDockHide(1.6, false)
        end
    end)
    tab.MouseEnter:Connect(function()
        self:ShowDock()
    end)
    tab.MouseLeave:Connect(function()
        if not self.dockPinned then
            self:_scheduleDockHide(0.85, false)
        end
    end)
    self:_updateDockSize()
end

function WindowManager:_makeTopTab(record)
    if not self.topTabScroll then return end
    local icons = {
        ["App Store"] = "▦", ["Periodic Table"] = "⚛", ["Space Hub"] = "🚀",
        ["Research Lab"] = "⚗", ["Resource Database"] = "▤", ["Blueprints"] = "▧",
        ["My Files"] = "▣", ["Settings"] = "⚙", ["Battery"] = "▰",
        ["AirDrop"] = "↗", ["Althea Supply"] = "🛒", ["AltheaMap"] = "⌖",
        ["AltheaTag"] = "◉", ["Mission & Jobs"] = "✦", ["Global Exchange"] = "⇄",
        ["Spectrum Lab"] = "🌈", ["Material Workbench"] = "🧪",
    }
    local label = (icons[record.name] or string.upper(string.sub(record.name, 1, 1))) .. "  " .. record.name
    local width = math.clamp(75 + #record.name * 7, 118, 200)
    local tab = make("TextButton", self.topTabScroll, {
        Name = "OpenTab_" .. record.name:gsub("[^%w_]", ""),
        Size = UDim2.fromOffset(width, 27),
        BackgroundColor3 = Color3.fromRGB(34, 51, 69),
        BackgroundTransparency = 0.36,
        BorderSizePixel = 0,
        Text = label,
        TextColor3 = COLORS.muted,
        TextSize = 11,
        Font = Enum.Font.GothamMedium,
        AutoButtonColor = true,
        LayoutOrder = table.find(self.openOrder, record.name) or 999,
        Visible = true,
        ZIndex = 352,
    })
    addCorner(tab, 9)
    local stroke = addStroke(tab, COLORS.barStroke, 1, 0.62)
    record.topTabButton = tab
    record.topTabStroke = stroke
    tab.Activated:Connect(function()
        self:ActivateWindow(record.name)
    end)
    tab.MouseEnter:Connect(function()
        tab.BackgroundTransparency = 0.12
    end)
    tab.MouseLeave:Connect(function()
        if self.activeName ~= record.name then tab.BackgroundTransparency = 0.36 end
    end)
end

function WindowManager:_ensureTopTab(record)
    if record.topTabButton and record.topTabButton.Parent then return end
    self:_makeTopTab(record)
end

function WindowManager:_reorderTopTabs()
    local order = 0
    for _, name in ipairs(self.openOrder) do
        local record = self.windows[name]
        if record and record.topTabButton then
            order += 1
            record.topTabButton.LayoutOrder = order
            record.topTabButton.Visible = true
        end
    end
    if self.emptyTabsLabel then self.emptyTabsLabel.Visible = #self.openOrder == 0 end
end

function WindowManager:_ensureTab(record)
    if record.tabButton and record.tabButton.Parent then
        return
    end
    self:_makeTab(record)
end

-- Install/uninstall an app without destroying its registered window template.
-- An uninstalled app has no Dock icon and cannot be launched.
function WindowManager:SetWindowInstalled(name, installed)
    local record = self.windows[name]
    if not record then
        return false
    end
    installed = installed == true
    if not installed and table.find(self.openOrder, name) then
        self:CloseWindow(name)
    end
    record.installed = installed
    record.options.Installed = installed
    if installed then
        self:_ensureTab(record)
    elseif record.tabButton then
        record.tabButton:Destroy()
        record.tabButton = nil
        record.tabStroke = nil
        record.runningDot = nil
    end
    self:_reorderTabs()
    self:_refresh()
    return true
end

function WindowManager:GetRAMCapacityMB()
    return self.ramCapacityMB or 4096
end

function WindowManager:SetRAMCapacityMB(capacityMB)
    self.ramCapacityMB = math.max(512, math.floor(tonumber(capacityMB) or 4096))
    return self.ramCapacityMB
end

function WindowManager:GetRAMUsageMB()
    local total = 0
    for _, name in ipairs(self.openOrder) do
        local record = self.windows[name]
        if record then
            total += math.max(0, tonumber(record.options.RamMB) or 256)
        end
    end
    return total
end

function WindowManager:_showToast(message)
    if self.toast and self.toast.Parent then
        self.toast:Destroy()
    end
    local toast = make("TextLabel", self.screenGui, {
        Name = "AltheaOS_Toast",
        AnchorPoint = Vector2.new(0.5, 0),
        Position = UDim2.new(0.5, 0, 0, 44),
        Size = UDim2.new(0.72, 0, 0, 42),
        BackgroundColor3 = Color3.fromRGB(27, 47, 66),
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        Text = tostring(message),
        TextColor3 = COLORS.text,
        TextSize = 13,
        Font = Enum.Font.GothamMedium,
        TextWrapped = true,
        ZIndex = 700,
    })
    addCorner(toast, 10)
    addStroke(toast, COLORS.accent, 1, 0.35)
    self.toast = toast
    task.delay(3.2, function()
        if self.toast == toast and toast.Parent then
            toast:Destroy()
            self.toast = nil
        end
    end)
end

function WindowManager:RegisterWindow(name, frame, options)
    assert(type(name) == "string" and name ~= "", "RegisterWindow needs a name")
    assert(frame and frame:IsA("GuiObject"), "RegisterWindow needs a GuiObject window frame")
    options = options or {}

    if self.windows[name] then
        self:CloseWindow(name)
        local old = self.windows[name]
        if old then
            if old.frame then
                old.frame.Visible = false
                if old.frame ~= frame then
                    old.frame:Destroy()
                end
            end
            if old.tabButton then
                old.tabButton:Destroy()
            end
        end
        local oldOrder = table.find(self.registeredOrder, name)
        if oldOrder then
            table.remove(self.registeredOrder, oldOrder)
        end
        self.windows[name] = nil
    end

    local header = options.Header or frame:FindFirstChild("Header")
    local closeButton = options.CloseButton or (header and header:FindFirstChild("CloseButton"))

    local record = {
        name = name,
        frame = frame,
        header = header,
        closeButton = closeButton,
        options = options,
        installed = options.Installed ~= false,
        tabButton = nil,
        tabStroke = nil,
        originalSize = frame.Size,
        originalPosition = frame.Position,
        originalAnchorPoint = frame.AnchorPoint,
    }
    self.windows[name] = record
    record.launchOrder = #self.registeredOrder + 1
    table.insert(self.registeredOrder, name)
    if record.installed then
        self:_ensureTab(record)
    end
    self:_reorderTabs()

    -- Put app windows into one shared ScreenGui. Registration never opens a window.
    frame.Parent = self.screenGui
    frame.Visible = false
    frame.Active = true
    styleGlass(frame, "panel")
    if header and header:IsA("GuiObject") then
        styleGlass(header, "header")
    end
    frame.AnchorPoint = Vector2.new(0.5, 0.5)
    frame.Position = options.DefaultPosition or UDim2.new(0.5, 0, 0.49, 0)
    frame.Size = options.DefaultSize or UDim2.new(0.84, 0, 0.78, 0)
    setZTree(frame, 10)
    -- Dynamic app content (file rows, settings cards, incoming AirDrop buttons) is added later.
    -- Keep it in the same visible ZIndex band as its parent app instead of letting it hide behind siblings.
    record.descendantConnection = frame.DescendantAdded:Connect(function(descendant)
        if descendant:IsA("GuiObject") and frame.Parent == self.screenGui then
            local parentZ = descendant.Parent and descendant.Parent:IsA("GuiObject") and descendant.Parent.ZIndex or 10
            setZTree(descendant, parentZ + 1)
        end
    end)

    if header and header:IsA("GuiObject") then
        header.Active = true
        -- macOS-style traffic lights on the left; title/subtitle begin after them.
        for _, child in ipairs(header:GetChildren()) do
            if child:IsA("TextLabel") then
                child.Position = UDim2.new(0, 82, child.Position.Y.Scale, child.Position.Y.Offset)
                child.Size = UDim2.new(1, -100, child.Size.Y.Scale, child.Size.Y.Offset)
            end
        end

        local minimizeButton = self:_makeControlButton(header, "OS_MinimizeButton", "", 36, Color3.fromRGB(255, 189, 46))
        local maximizeButton = self:_makeControlButton(header, "OS_MaximizeButton", "", 56, Color3.fromRGB(40, 200, 64))
        record.minimizeButton = minimizeButton
        record.maximizeButton = maximizeButton
        minimizeButton.Activated:Connect(function()
            self:MinimizeWindow(name)
        end)
        maximizeButton.Activated:Connect(function()
            self:ToggleMaximize(name)
        end)

        if not closeButton then
            closeButton = self:_makeControlButton(header, "OS_CloseButton", "", 16, Color3.fromRGB(255, 95, 86))
            record.closeButton = closeButton
        else
            closeButton.AnchorPoint = Vector2.new(0, 0.5)
            closeButton.Position = UDim2.new(0, 16, 0.5, 0)
            closeButton.Size = UDim2.fromOffset(14, 14)
            closeButton.BackgroundColor3 = Color3.fromRGB(255, 95, 86)
            closeButton.BackgroundTransparency = 0
            closeButton.Text = ""
            closeButton.TextSize = 1
            closeButton.AutoButtonColor = true
            closeButton.ZIndex = header.ZIndex + 1
            local corner = closeButton:FindFirstChildOfClass("UICorner")
            if corner then
                corner.CornerRadius = UDim.new(1, 0)
            else
                addCorner(closeButton, 10)
            end
            local stroke = closeButton:FindFirstChildOfClass("UIStroke")
            if stroke then
                stroke.Color = Color3.fromRGB(255, 95, 86)
                stroke.Transparency = 0.45
            end
        end
        closeButton.Activated:Connect(function()
            self:CloseWindow(name)
        end)

        header.InputBegan:Connect(function(input)
            if not isPointerBegin(input) or self.maximized[name] then
                return
            end
            self.interaction = {
                kind = "drag",
                record = record,
                inputType = input.UserInputType,
                inputObject = input,
                pointerStart = Vector2.new(input.Position.X, input.Position.Y),
                absolutePositionStart = frame.AbsolutePosition,
            }
        end)
    end

    local resizeHandle = make("TextButton", frame, {
        Name = "OS_ResizeHandle",
        AnchorPoint = Vector2.new(1, 1),
        Position = UDim2.new(1, -5, 1, -5),
        Size = UDim2.fromOffset(24, 24),
        BackgroundColor3 = COLORS.button,
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        Text = "◢",
        TextColor3 = COLORS.accent,
        TextSize = 13,
        Font = Enum.Font.GothamBold,
        AutoButtonColor = true,
    })
    addCorner(resizeHandle, 6)
    addStroke(resizeHandle, COLORS.barStroke, 1, 0.25)
    resizeHandle.ZIndex = 100
    record.resizeHandle = resizeHandle
    resizeHandle.InputBegan:Connect(function(input)
        if not isPointerBegin(input) or self.maximized[name] then
            return
        end
        self.interaction = {
            kind = "resize",
            record = record,
            inputType = input.UserInputType,
            inputObject = input,
            pointerStart = Vector2.new(input.Position.X, input.Position.Y),
            sizeStart = frame.AbsoluteSize,
            absolutePositionStart = frame.AbsolutePosition,
        }
    end)

    return record
end

function WindowManager:_updateDockSize()
    if not self.dock then
        return
    end
    local count = #self.registeredOrder
    count = 0
    for _, name in ipairs(self.registeredOrder) do
        local record = self.windows[name]
        if record and record.installed then
            count += 1
        end
    end
    local width = math.clamp(count * 55 + 28, 104, 660)
    self.dock.Size = UDim2.fromOffset(width, 70)
end

function WindowManager:_reorderTabs()
    local installedOrder = 0
    for _, name in ipairs(self.registeredOrder) do
        local record = self.windows[name]
        if record and record.installed then
            installedOrder += 1
            if record.tabButton then
                record.tabButton.LayoutOrder = installedOrder
                record.tabButton.Visible = true
            end
        elseif record and record.tabButton then
            record.tabButton:Destroy()
            record.tabButton = nil
            record.tabStroke = nil
            record.runningDot = nil
        end
    end
    self:_updateDockSize()
end

function WindowManager:_saveSplitBounds(name)
    if self.splitSavedBounds[name] then return end
    local record = self.windows[name]
    if not record then return end
    local frame = record.frame
    local wasMaximized = self.maximized[name] == true
    local bounds
    if wasMaximized and record.restoreBounds then
        bounds = {
            anchorPoint = record.restoreBounds.anchorPoint,
            position = record.restoreBounds.position,
            size = record.restoreBounds.size,
        }
        frame.AnchorPoint = bounds.anchorPoint
        frame.Position = bounds.position
        frame.Size = bounds.size
        self.maximized[name] = false
        record.restoreBounds = nil
    else
        bounds = { anchorPoint = frame.AnchorPoint, position = frame.Position, size = frame.Size }
    end
    self.splitSavedBounds[name] = bounds
    self.splitWasMaximized[name] = wasMaximized
end

function WindowManager:_applySplitLayout()
    if not self.splitMode then return end
    local viewport = getViewportSize()
    local top = 72
    local bottom = 92
    local usableWidth = math.max(320, viewport.X - 24)
    local gap = 8
    local paneWidth = math.max(150, (usableWidth - gap) / 2)
    local paneHeight = math.max(180, viewport.Y - top - bottom)
    local paneNames = { left = self.splitWindows.left, right = self.splitWindows.right }
    for side, name in pairs(paneNames) do
        local record = name and self.windows[name] or nil
        if record and table.find(self.openOrder, name) then
            local frame = record.frame
            frame.AnchorPoint = Vector2.new(0, 0)
            frame.Position = UDim2.fromOffset(side == "left" and 8 or (16 + paneWidth), top)
            frame.Size = UDim2.fromOffset(paneWidth, paneHeight)
        end
    end
end

function WindowManager:SetSplitView(enabled, leftName, rightName)
    enabled = enabled == true
    if not enabled then
        if not self.splitMode then return false end
        self.splitMode = false
        self.splitWindows.left = nil
        self.splitWindows.right = nil
        local restoreNames = {}
        for name in pairs(self.splitSavedBounds) do table.insert(restoreNames, name) end
        for _, name in ipairs(restoreNames) do
            local record = self.windows[name]
            local bounds = self.splitSavedBounds[name]
            if record and bounds then
                record.frame.AnchorPoint = bounds.anchorPoint
                record.frame.Position = bounds.position
                record.frame.Size = bounds.size
                self.maximized[name] = false
                record.restoreBounds = nil
            end
        end
        local restoreMax = {}
        for name, wasMax in pairs(self.splitWasMaximized) do
            if wasMax then table.insert(restoreMax, name) end
        end
        self.splitSavedBounds = {}
        self.splitWasMaximized = {}
        self:_refresh()
        for _, name in ipairs(restoreMax) do
            if self.windows[name] and table.find(self.openOrder, name) then self:ToggleMaximize(name) end
        end
        self:_refresh()
        if self.splitButton then
            self.splitButton.Text = "▣ Split"
            self.splitButton.BackgroundColor3 = Color3.fromRGB(36, 57, 78)
        end
        return true
    end

    if self.splitMode then return true end
    local left = leftName or self.activeName
    if not left or not self.windows[left] or not table.find(self.openOrder, left) then
        self:_showToast("Open an application first, then enable Split View.")
        return false
    end
    local right = rightName
    if not right or right == left or not self.windows[right] or not table.find(self.openOrder, right) then
        right = nil
        for i = #self.openOrder, 1, -1 do
            local candidate = self.openOrder[i]
            if candidate ~= left and not self.minimized[candidate] then right = candidate break end
        end
    end
    if not right then
        for _, candidate in ipairs(self.registeredOrder) do
            local other = self.windows[candidate]
            if candidate ~= left and other and other.installed then
                if self:OpenWindow(candidate) then right = candidate end
                break
            end
        end
    end
    if not right or not self.windows[right] or not table.find(self.openOrder, right) then
        self:_showToast("Install and open a second application to use Split View.")
        return false
    end

    self.splitMode = true
    self.splitWindows.left = left
    self.splitWindows.right = right
    self.splitFocusSide = "left"
    self.activeName = left
    self:_saveSplitBounds(left)
    self:_saveSplitBounds(right)
    self:_applySplitLayout()
    if self.splitButton then
        self.splitButton.Text = "▣ Split ✓"
        self.splitButton.BackgroundColor3 = Color3.fromRGB(39, 87, 78)
    end
    self:_refresh()
    return true
end

function WindowManager:ToggleSplitView()
    if self.splitMode then return self:SetSplitView(false) end
    return self:SetSplitView(true)
end

function WindowManager:SwipeTabs(direction)
    direction = direction >= 0 and 1 or -1
    if self.splitMode then
        self.splitFocusSide = direction > 0 and "right" or "left"
        self.activeName = self.splitWindows[self.splitFocusSide]
        self:_refresh()
        return true
    end
    local candidates = {}
    for _, name in ipairs(self.openOrder) do
        if not self.minimized[name] and self.windows[name] then table.insert(candidates, name) end
    end
    if #candidates < 2 then return false end
    local index = table.find(candidates, self.activeName) or 1
    index = ((index - 1 + direction) % #candidates) + 1
    return self:ActivateWindow(candidates[index])
end

function WindowManager:_handleSwipeEnded(input)
    local state = self._swipeStart
    if not state then return end
    if state.inputType ~= input.UserInputType then return end
    self._swipeStart = nil
    local finish = Vector2.new(input.Position.X, input.Position.Y)
    local delta = finish - state.pointerStart
    if os.clock() - state.startedAt > 1.35 then return end
    if math.abs(delta.X) >= 90 and math.abs(delta.X) > math.abs(delta.Y) * 1.25 then
        self:SwipeTabs(delta.X < 0 and 1 or -1)
    end
end

function WindowManager:_refresh()
    if self.splitMode then self:_applySplitLayout() end
    local activeRecord = self.activeName and self.windows[self.activeName] or nil
    local hasActiveWindow = activeRecord ~= nil and not self.minimized[self.activeName]

    for name, record in pairs(self.windows) do
        local isOpen = table.find(self.openOrder, name) ~= nil
        local isActive = hasActiveWindow and name == self.activeName and isOpen
        local isSplitPane = self.splitMode and (name == self.splitWindows.left or name == self.splitWindows.right) and isOpen and not self.minimized[name]
        record.frame.Visible = self.splitMode and isSplitPane or (not self.splitMode and isActive)
        if record.topTabButton then
            record.topTabButton.Visible = isOpen
            local topActive = isActive
            record.topTabButton.BackgroundColor3 = topActive and Color3.fromRGB(48, 77, 101) or Color3.fromRGB(34, 51, 69)
            record.topTabButton.BackgroundTransparency = topActive and 0.08 or 0.36
            record.topTabButton.TextColor3 = topActive and COLORS.text or COLORS.muted
            if record.topTabStroke then
                record.topTabStroke.Color = topActive and COLORS.accent or COLORS.barStroke
                record.topTabStroke.Transparency = topActive and 0.20 or 0.62
            end
        end
        if record.tabButton then
            record.tabButton.Visible = record.installed == true
            record.tabButton.BackgroundColor3 = isActive and COLORS.tabActive or COLORS.button
            record.tabButton.BackgroundTransparency = isActive and 0.04 or 0.34
            record.tabButton.TextColor3 = isActive and COLORS.text or COLORS.muted
            if record.tabStroke then
                record.tabStroke.Color = isActive and COLORS.accent or COLORS.barStroke
                record.tabStroke.Transparency = isActive and 0.05 or 0.50
            end
            if record.runningDot then
                record.runningDot.Visible = isOpen
            end
        end
    end

    if self.emptyTabsLabel then self.emptyTabsLabel.Visible = #self.openOrder == 0 end
    if self.splitButton then
        self.splitButton.Text = self.splitMode and "▣ Split ✓" or "▣ Split"
        self.splitButton.BackgroundColor3 = self.splitMode and Color3.fromRGB(39, 87, 78) or Color3.fromRGB(36, 57, 78)
    end
    local modal = hasActiveWindow and activeRecord.options.Modal == true
    self.shade.Visible = modal
    if self.blur then
        self.blur.Size = modal and (tonumber(activeRecord.options.BlurSize) or 16) or 0
    end
end

function WindowManager:OpenWindow(name)
    local previousActive = self.activeName
    local record = self.windows[name]
    if not record then
        warn("AltheaOS: window is not registered: " .. tostring(name))
        return false
    end
    if not record.installed then
        self:_showToast("This app is not installed. Open App Store to get it.")
        return false
    end

    if not table.find(self.openOrder, name) then
        local requiredMB = self:GetRAMUsageMB() + math.max(0, tonumber(record.options.RamMB) or 256)
        if requiredMB > self:GetRAMCapacityMB() then
            self:_showToast(string.format("Not enough RAM: %d MB needed, %d MB available. Close apps or upgrade RAM.", requiredMB, self:GetRAMCapacityMB()))
            return false
        end
        table.insert(self.openOrder, name)
        self:_ensureTab(record)
        self:_reorderTabs()
    end

    self.minimized[name] = false
    self.activeName = name
    self:_ensureTopTab(record)
    self:_reorderTopTabs()
    if self.splitMode and name ~= self.splitWindows.left and name ~= self.splitWindows.right then
        local side = self.splitFocusSide or "left"
        self:_saveSplitBounds(name)
        self.splitWindows[side] = name
        self.splitFocusSide = side
    elseif self.splitMode then
        self.splitFocusSide = (self.splitWindows.right == name) and "right" or "left"
    end
    self:_refresh()

    -- Lazily refresh data-backed apps after their windows become active.
    if self.playerScripts then
        local refreshEvent = self.playerScripts:FindFirstChild("AltheaOSFeatureRefresh")
        if refreshEvent and refreshEvent:IsA("BindableEvent") then
            task.defer(function()
                if refreshEvent.Parent then refreshEvent:Fire(name) end
            end)
        end
    end

    task.defer(function()
        if record.tabButton and self.dockScroll then
            local tabX = record.tabButton.AbsolutePosition.X - self.dockScroll.AbsolutePosition.X
            local tabRight = tabX + record.tabButton.AbsoluteSize.X
            local scrollX = self.dockScroll.CanvasPosition.X
            local viewportWidth = self.dockScroll.AbsoluteSize.X
            if tabRight > scrollX + viewportWidth then
                self.dockScroll.CanvasPosition = Vector2.new(math.max(0, tabRight - viewportWidth + 8), 0)
            elseif tabX < scrollX then
                self.dockScroll.CanvasPosition = Vector2.new(math.max(0, tabX), 0)
            end
        end
    end)
    return true
end

function WindowManager:ActivateWindow(name)
    if not table.find(self.openOrder, name) then
        return self:OpenWindow(name)
    end
    self.minimized[name] = false
    self.activeName = name
    if self.splitMode then
        if name ~= self.splitWindows.left and name ~= self.splitWindows.right then
            local side = self.splitFocusSide or "left"
            self:_saveSplitBounds(name)
            self.splitWindows[side] = name
        else
            self.splitFocusSide = (self.splitWindows.right == name) and "right" or "left"
        end
    end
    self:_refresh()
    return true
end

function WindowManager:CloseWindow(name)
    local record = self.windows[name]
    if not record then
        return false
    end
    if self.splitMode and (self.splitWindows.left == name or self.splitWindows.right == name) then
        self:SetSplitView(false)
    end

    local index = table.find(self.openOrder, name)
    if index then
        table.remove(self.openOrder, index)
    end
    self.minimized[name] = nil
    if self.maximized[name] then
        local bounds = record.restoreBounds
        if bounds then
            record.frame.AnchorPoint = bounds.anchorPoint
            record.frame.Position = bounds.position
            record.frame.Size = bounds.size
        end
        self.maximized[name] = false
        record.restoreBounds = nil
    end
    -- Keep the app icon pinned in the Dock even when its window is closed.
    record.frame.Visible = false
    if record.topTabButton then
        record.topTabButton:Destroy()
        record.topTabButton = nil
        record.topTabStroke = nil
    end

    if self.activeName == name then
        self.activeName = nil
        for i = #self.openOrder, 1, -1 do
            local candidate = self.openOrder[i]
            if not self.minimized[candidate] then
                self.activeName = candidate
                break
            end
        end
    end
    self:_reorderTabs()
    self:_reorderTopTabs()
    self:_refresh()
    return true
end

function WindowManager:MinimizeWindow(name)
    if not table.find(self.openOrder, name) then
        return false
    end
    if self.splitMode then self:SetSplitView(false) end
    self.minimized[name] = true
    if self.activeName == name then
        self.activeName = nil
        for i = #self.openOrder, 1, -1 do
            local candidate = self.openOrder[i]
            if candidate ~= name and not self.minimized[candidate] then
                self.activeName = candidate
                break
            end
        end
    end
    self:_refresh()
    return true
end

function WindowManager:ToggleMaximize(name)
    local record = self.windows[name]
    if not record or not table.find(self.openOrder, name) then
        return false
    end
    if self.splitMode and (self.splitWindows.left == name or self.splitWindows.right == name) then
        self:SetSplitView(false)
    end

    local frame = record.frame
    if self.maximized[name] then
        local bounds = record.restoreBounds
        if bounds then
            frame.AnchorPoint = bounds.anchorPoint
            frame.Position = bounds.position
            frame.Size = bounds.size
        else
            frame.AnchorPoint = record.originalAnchorPoint
            frame.Position = record.originalPosition
            frame.Size = record.originalSize
        end
        self.maximized[name] = false
    else
        record.restoreBounds = {
            anchorPoint = frame.AnchorPoint,
            position = frame.Position,
            size = frame.Size,
        }
        local viewport = getViewportSize()
        frame.AnchorPoint = Vector2.new(0, 0)
        frame.Position = UDim2.fromOffset(8, 72)
        frame.Size = UDim2.fromOffset(math.max(280, viewport.X - 16), math.max(220, viewport.Y - 164))
        self.maximized[name] = true
    end
    self:_refresh()
    return true
end

function WindowManager:_handleInputChanged(input)
    local state = self.interaction
    if not state then
        return
    end

    local isMove = state.inputType == Enum.UserInputType.MouseButton1
        and input.UserInputType == Enum.UserInputType.MouseMovement
    local isTouchMove = state.inputType == Enum.UserInputType.Touch
        and input.UserInputType == Enum.UserInputType.Touch
        and input == state.inputObject
    if not isMove and not isTouchMove then
        return
    end

    local currentPointer = Vector2.new(input.Position.X, input.Position.Y)
    local delta = currentPointer - state.pointerStart
    local frame = state.record.frame
    local viewport = getViewportSize()
    local topLeftInset = getTopLeftInset()

    if state.kind == "drag" then
        if self.maximized[state.record.name] then
            return
        end
        -- Normalize to top-left positioning so dragging still works after resizing.
        local leftX = state.absolutePositionStart.X + delta.X - topLeftInset.X
        local topY = state.absolutePositionStart.Y + delta.Y - topLeftInset.Y
        leftX = math.clamp(leftX, 0, math.max(0, viewport.X - frame.AbsoluteSize.X))
        local bottomReserved = 86 -- leave room for the floating Dock
        local maxTop = math.max(72, viewport.Y - topLeftInset.Y - frame.AbsoluteSize.Y - bottomReserved)
        topY = math.clamp(topY, 72, maxTop)
        frame.AnchorPoint = Vector2.new(0, 0)
        frame.Position = UDim2.fromOffset(leftX, topY)
    elseif state.kind == "resize" then
        if self.maximized[state.record.name] then
            return
        end
        local minWidth = math.min(540, math.max(280, viewport.X - 24))
        local minHeight = math.min(300, math.max(220, viewport.Y - 96))
        local maxHeight = math.max(minHeight, viewport.Y - 96)
        local newWidth = math.clamp(state.sizeStart.X + delta.X, minWidth, math.max(minWidth, viewport.X - 24))
        local newHeight = math.clamp(state.sizeStart.Y + delta.Y, minHeight, maxHeight)
        frame.AnchorPoint = Vector2.new(0, 0)
        frame.Position = UDim2.fromOffset(
            math.max(0, state.absolutePositionStart.X - topLeftInset.X),
            math.max(8, state.absolutePositionStart.Y - topLeftInset.Y)
        )
        frame.Size = UDim2.fromOffset(newWidth, newHeight)
    end
end

function WindowManager:_handleInputEnded(input)
    local state = self.interaction
    if not state then
        return
    end
    if (state.inputType == Enum.UserInputType.MouseButton1 and input.UserInputType == Enum.UserInputType.MouseButton1)
        or (state.inputType == Enum.UserInputType.Touch and input.UserInputType == Enum.UserInputType.Touch) then
        self.interaction = nil
    end
end

function WindowManager:OpenDesktop()
    if self.desktopOpen then
        return false
    end
    self.desktopOpen = true

    -- Hide the default Roblox hotbar while the desktop's own Dock is visible.
    -- Preserve the player's previous setting and restore it when the desktop closes.
    local gotBackpackState, backpackWasEnabled = pcall(function()
        return StarterGui:GetCoreGuiEnabled(Enum.CoreGuiType.Backpack)
    end)
    if gotBackpackState then
        self._previousBackpackEnabled = backpackWasEnabled
    else
        self._previousBackpackEnabled = true
    end
    pcall(function()
        StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
    end)

    self.screenGui.Enabled = true
    if self.topTabBar then self.topTabBar.Visible = true end
    if self.dockHandle then
        self.dockHandle.Visible = true
    end
    self:ShowDock()
    if not self.dockPinned then
        self:_scheduleDockHide(3.5, true)
    end
    return true
end

function WindowManager:CloseDesktop()
    if not self.desktopOpen then
        return false
    end
    if self.splitMode then self:SetSplitView(false) end
    -- Close all app windows so no modal blur is left behind when the laptop is put away.
    local names = {}
    for _, name in ipairs(self.openOrder) do
        table.insert(names, name)
    end
    for _, name in ipairs(names) do
        self:CloseWindow(name)
    end
    self.desktopOpen = false
    self.dockPinned = false
    self.dockVisible = false
    self._dockHideToken += 1
    if self._dockTween then
        self._dockTween:Cancel()
        self._dockTween = nil
    end
    if self.dock then
        self.dock.Visible = false
        self.dock.Position = UDim2.new(0.5, 0, 1, 92)
    end
    if self.dockHandle then
        self.dockHandle.Visible = false
    end
    if self.shade then
        self.shade.Visible = false
    end
    if self.blur then
        self.blur.Size = 0
    end
    self.screenGui.Enabled = false
    local restoreBackpack = self._previousBackpackEnabled
    self._previousBackpackEnabled = nil
    if restoreBackpack ~= nil then
        pcall(function()
            StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, restoreBackpack)
        end)
    end
    return true
end

function WindowManager:ToggleDesktop()
    if self.desktopOpen then
        return self:CloseDesktop()
    end
    return self:OpenDesktop()
end

function WindowManager:SetDesktopVisible(visible)
    if visible then
        return self:OpenDesktop()
    end
    return self:CloseDesktop()
end

return WindowManager
