-- AltheaBook Tool Client V5
-- Put this LocalScript inside the AltheaBook Tool in StarterPack.
-- Equipping the device opens AltheaOS. The physical model is hidden locally while in use.

local Players = game:GetService("Players")
local player = Players.LocalPlayer
local tool = script.Parent
local playerScripts = player:WaitForChild("PlayerScripts")

-- Create/reuse the local control event safely so script startup order does not matter.
local control = playerScripts:FindFirstChild("AltheaBookControl")
if control and not control:IsA("BindableEvent") then
    control:Destroy()
    control = nil
end
if not control then
    control = Instance.new("BindableEvent")
    control.Name = "AltheaBookControl"
    control.Parent = playerScripts
end

local equipped = false
local originalPartTransparency = {}
local originalGuiEnabled = {}

local function setDeviceVisualHidden(hidden)
    for _, object in ipairs(tool:GetDescendants()) do
        if object:IsA("BasePart") then
            if originalPartTransparency[object] == nil then
                originalPartTransparency[object] = object.LocalTransparencyModifier
            end
            object.LocalTransparencyModifier = hidden and 1 or originalPartTransparency[object]
        elseif object:IsA("SurfaceGui") or object:IsA("BillboardGui") then
            if originalGuiEnabled[object] == nil then
                originalGuiEnabled[object] = object.Enabled
            end
            object.Enabled = not hidden and originalGuiEnabled[object]
        end
    end
end

tool.Equipped:Connect(function()
    equipped = true
    setDeviceVisualHidden(true)
    control:Fire("open")
end)

tool.Activated:Connect(function()
    if equipped then
        control:Fire("open")
    end
end)

tool.Unequipped:Connect(function()
    equipped = false
    control:Fire("close")
    setDeviceVisualHidden(false)
end)
