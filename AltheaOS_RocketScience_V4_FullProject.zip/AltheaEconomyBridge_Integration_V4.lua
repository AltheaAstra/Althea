-- AltheaOS V4: trusted reward bridge integration examples.
-- Keep these calls in ServerScriptService inside the actual Rocket/Mining/Utility system.
-- Never accept the rewardId or receiptId from a client RemoteEvent.
local ServerStorage = game:GetService("ServerStorage")
local EconomyBridge = ServerStorage:WaitForChild("AltheaEconomyBridge")

local function onRocketLaunchVerified(player, serverGeneratedMissionRunId)
    return EconomyBridge:Invoke(player, "AwardReward", {
        rewardId = "RocketLaunchOrbit",
        receiptId = "rocket-orbit:" .. tostring(serverGeneratedMissionRunId),
    })
end

local function onPayloadDeliveryVerified(player, serverGeneratedMissionRunId)
    return EconomyBridge:Invoke(player, "AwardReward", {
        rewardId = "RocketPayloadDelivered",
        receiptId = "rocket-payload:" .. tostring(serverGeneratedMissionRunId),
    })
end

local function onMiningContractVerified(player, serverGeneratedContractId, rareOre)
    return EconomyBridge:Invoke(player, "AwardReward", {
        rewardId = rareOre and "MiningContractRareOre" or "MiningContractSmall",
        receiptId = "mining-contract:" .. tostring(serverGeneratedContractId),
    })
end

local function onWaterTreatmentVerified(player, serverGeneratedBatchId)
    return EconomyBridge:Invoke(player, "AwardReward", {
        rewardId = "WaterTreatmentBatch",
        receiptId = "water-treatment:" .. tostring(serverGeneratedBatchId),
    })
end

local function onWaterProductionVerified(player, serverGeneratedBatchId)
    return EconomyBridge:Invoke(player, "AwardReward", {
        rewardId = "WaterProductionBatch",
        receiptId = "water-production:" .. tostring(serverGeneratedBatchId),
    })
end

local function onPowerProductionVerified(player, serverGeneratedBatchId)
    return EconomyBridge:Invoke(player, "AwardReward", {
        rewardId = "PowerProductionBatch",
        receiptId = "power-production:" .. tostring(serverGeneratedBatchId),
    })
end
