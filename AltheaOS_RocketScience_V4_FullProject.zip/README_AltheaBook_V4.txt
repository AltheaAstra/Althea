# AltheaBook / AltheaOS V4 — Glassmorphism & Economy Prototype

## What is included
- Full glassmorphism AltheaBook OS desktop (based on the supplied V3 Glass Window Manager).
- Existing apps: App Store, 118-element Periodic Table, Settings, Battery/Charging, My Files, AirDrop, App Requests, Althea Supply, AltheaMap, AltheaTag, plus Mission & Jobs and Global Exchange.
- Central `AltheaAppRegistry` ModuleScript shared by Client and Server.
- Server-authoritative Credits wallet stored separately from profile data so same-Experience servers can read/write a shared wallet.
- Material delivery contracts that consume inventory and pay server-validated Credits.
- Global Exchange prototype: persistent shared order book with listing escrow, buy/cancel flows, idempotent wallet receipts, 3% fee, and 7-day listing expiry.
- Sample world with a baseplate, spawn, charging station, and public map markers.
- AltheaBook Tool in StarterPack.

## Project files
- `AltheaBook_RocketScience_V4.rbxlx`: complete Studio place file. Open it in Studio, test, then File > Save to File if you need binary `.rbxl` format.
- `AltheaOS_V4_InstallKit.rbxmx`: importable folder containing Client + Window Manager for StarterPlayerScripts; move its contents to the correct service as detailed below.
- `AltheaAppRegistry_V4.rbxmx`: ModuleScript for ReplicatedStorage.
- `AltheaBookServer_V4.rbxmx`: Script for ServerScriptService.
- `AltheaBook_Tool_V4.rbxmx`: AltheaBook Tool for StarterPack.
- `.lua` source files are editable copies.

## Explorer hierarchy (required)
ReplicatedStorage
  - ModuleScript `AltheaAppRegistry`
ServerScriptService
  - Script `AltheaBookServer`
StarterPlayer
  - StarterPlayerScripts
    - Folder `AltheaBookOS`
      - LocalScript `AltheaBookClient`
      - ModuleScript `AltheaOSWindowManager`
StarterPack
  - Tool `AltheaBook` (contains Handle + LocalScript)
Workspace
  - Baseplate, SpawnLocation, AltheaCharger, map markers

The Client uses `script.Parent:WaitForChild("AltheaOSWindowManager")`, so both client scripts MUST be siblings in the same `AltheaBookOS` folder. The Server requires `ReplicatedStorage.AltheaAppRegistry`.

## Install into an existing Rocket Science place
1. Make a backup and click Stop in Studio.
2. Import `AltheaOS_V4_InstallKit.rbxmx` into Workspace as a temporary model. Move the child `AltheaBookOS` folder to `StarterPlayer > StarterPlayerScripts`.
3. Import `AltheaAppRegistry_V4.rbxmx` and move ModuleScript `AltheaAppRegistry` to `ReplicatedStorage`.
4. Import `AltheaBookServer_V4.rbxmx` and move Script `AltheaBookServer` to `ServerScriptService`.
5. Import `AltheaBook_Tool_V4.rbxmx` and move Tool `AltheaBook` to `StarterPack`. Remove or disable older AltheaBook Tools and AltheaBook Server scripts to avoid duplicates.
6. Ensure there is only one active LocalScript named `AltheaBookClient` and one Window Manager ModuleScript in the `AltheaBookOS` folder.
7. For persistent saving, publish a TEST experience and enable Game Settings > Security > Enable Studio Access to API Services for that test place. Do not use production player data during experiments.
8. Stop and Play. Equip AltheaBook (hotbar key 1); test App Store, Battery, App Requests, Althea Supply, AltheaMap, AltheaTag, Mission & Jobs, and Global Exchange.

## Global Exchange mechanics
- Only items present in the player's AltheaBook inventory and in the `SUPPLY_CATALOG` inventory mapping may be listed.
- Listing an item deducts it into an escrow-like market record. Cancelling returns it once using a receipt.
- Buying atomically reserves an offer in a single global DataStore OrderBook, debits the buyer wallet with a unique receipt, credits the seller wallet with a unique receipt, delivers the item once, and marks the listing sold. If DataStore requests fail mid-transaction, the listing may remain Reserved; the same buyer can retry to reconcile the transaction. Do not wipe the relevant DataStores during live use.
- The single-key OrderBook is suitable for a small prototype and can become a contention bottleneck at scale. A high-traffic production market should split listings into per-listing DataStore entries and use a MemoryStore sorted-map index, plus a formal transaction journal/recovery worker.
- Profile inventory still uses the existing per-player profile pattern. Do not run multiple simultaneous sessions for one user during economy testing; add profile session locks before a high-stakes production launch.

## Job Board mechanics
- Contracts are server-defined in `JOB_CATALOG` in `AltheaBookServer_V4.lua`.
- A contract consumes its required item quantity from profile Inventory, and pays Credits through the wallet receipt ledger.
- To prevent buying materials from becoming a profitable infinite-credit loop, the sample payouts are intentionally below the current Supply Store replacement cost. The intended profit route is mining/production rewards from trusted server systems.
- Rocket launch, payload, exploration, mining, water and power production rewards remain available via `ServerStorage.AltheaEconomyBridge:Invoke(player, "AwardReward", { rewardId=..., receiptId=... })`. Call only after a server gameplay system validates the event.

## Important limitations
- This is a V4 starter implementation. It has not been run inside Roblox Studio in this environment; validate using the Output window.
- The online Supply stock remains per live server. Global Exchange offers are shared through DataStore. A global supply stock needs a separate transaction-backed stock service.
- UIGradient creates gradient lighting but not true blur of other GUI elements. `BlurEffect` affects the 3D scene, not arbitrary GUI behind a panel.
- AltheaMap uses X/Z world coordinates as a simple 2D projection. Add custom map bounds for individual planets.
- AltheaTag only tracks Models/BaseParts tagged `AltheaRocket` or `AltheaTrackable` and requires `RocketId` and `OwnerUserId` (or valid `OwnerTeam`) attributes. The Rocket System must publish fuel/stage attributes for those telemetry fields.
- Job Board currently contains material-delivery contracts; rocket mission jobs need to call the trusted reward bridge from the actual rocket server logic.
- The binary `.rbxl` container is not emitted by this tool. The provided `.rbxlx` opens in Roblox Studio and can be saved as `.rbxl` using Studio's Save to File command.

## Suggested smoke tests
1. Confirm no desktop appears automatically at spawn; equip the Tool to open it.
2. Unequip the Tool; desktop closes and Backpack state restores.
3. Open/close several apps; confirm no duplicate windows or stuck blur.
4. Install a paid app; verify Credits and installed app state across a rejoin in a published test place.
5. Place a Part named `AltheaCharger`; stand near it and verify BatteryCharging becomes true.
6. Submit an App Request twice rapidly; server cooldown should reject one.
7. Buy a Power Cell / material through Althea Supply and verify Credits + Inventory.
8. List a small inventory quantity on Global Exchange using two test accounts; buy on another server if possible; verify both wallets and inventory.
9. Attempt to buy your own listing; it should be rejected.
10. Accept a job; attempt completion without the required material; it should fail. Add resource on server for test then complete and verify payout.
11. Tag a test rocket with `AltheaRocket`; set `RocketId` and `OwnerUserId` to the test player's UserId; buy AltheaTagDevice and test install/remove.
12. Check Output for DataStore/API errors; do not test persistent flows with Studio API disabled.
