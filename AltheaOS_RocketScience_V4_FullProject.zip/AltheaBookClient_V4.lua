-- Rocket Science Periodic Table GUI
-- Place this LocalScript in StarterPlayer > StarterPlayerScripts.
-- Boots AltheaBook hidden; its GUI is shown only when the AltheaBook Tool is activated.

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local WindowManager = require(script.Parent:WaitForChild("AltheaOSWindowManager"))

-- Server-authoritative downloads, credits, RAM upgrades, and saved ownership.
local function requestServer(action, arguments)
    local remotes = ReplicatedStorage:WaitForChild("AltheaBookRemotes", 12)
    if not remotes then
        return { ok = false, message = "AltheaBook server service is missing. Add AltheaBookServer.lua to ServerScriptService." }
    end
    local requestRemote = remotes:WaitForChild("Request", 8)
    if not requestRemote or not requestRemote:IsA("RemoteFunction") then
        return { ok = false, message = "AltheaBook server RemoteFunction is missing." }
    end
    local payload = table.clone(arguments or {})
    payload.action = action
    local ok, response = pcall(function()
        return requestRemote:InvokeServer(payload)
    end)
    if not ok then
        warn("AltheaBook server request failed:", response)
        return { ok = false, message = "Server request failed. Check View > Output." }
    end
    if type(response) ~= "table" then
        return { ok = false, message = "Invalid response from AltheaBook server." }
    end
    return response
end

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local osManager = WindowManager.new(playerGui)
local currentProfile -- assigned after catalog and store UI declarations

-- A local-only control channel connects the physical laptop Tool to the desktop.
local playerScripts = player:WaitForChild("PlayerScripts")
local bookControl = playerScripts:FindFirstChild("AltheaBookControl")
if not bookControl then
    bookControl = Instance.new("BindableEvent")
    bookControl.Name = "AltheaBookControl"
    bookControl.Parent = playerScripts
end
bookControl.Event:Connect(function(action)
    if action == "open" then
        local response = requestServer("SetDevicePower", { enabled = true })
        if response.profile then
            currentProfile = response.profile
            osManager:SetBatteryPercent(currentProfile.BatteryPercent or 100, currentProfile.BatteryCharging == true)
        end
        if response.ok then
            osManager:OpenDesktop()
        else
            osManager:_showToast(response.message or "AltheaBook could not start.")
        end
    elseif action == "close" then
        requestServer("SetDevicePower", { enabled = false })
        osManager:CloseDesktop()
    elseif action == "toggle" then
        if osManager.desktopOpen then
            requestServer("SetDevicePower", { enabled = false })
            osManager:CloseDesktop()
        else
            local response = requestServer("SetDevicePower", { enabled = true })
            if response.profile then
                currentProfile = response.profile
                osManager:SetBatteryPercent(currentProfile.BatteryPercent or 100, currentProfile.BatteryCharging == true)
            end
            if response.ok then osManager:OpenDesktop() else osManager:_showToast(response.message or "Charge the battery first.") end
        end
    end
end)

local oldGui = playerGui:FindFirstChild("RocketPeriodicTableGUI")
if oldGui then
    oldGui:Destroy()
end

-- Data format: atomic number | symbol | name | atomic mass (u) | category | group | period | series
-- M = main table, L = lanthanides, A = actinides
local rawData = [[
1|H|Hydrogen|1.008|Reactive Nonmetal|1|1|M
2|He|Helium|4.0026|Noble Gas|18|1|M
3|Li|Lithium|6.94|Alkali Metal|1|2|M
4|Be|Beryllium|9.0122|Alkaline Earth Metal|2|2|M
5|B|Boron|10.81|Metalloid|13|2|M
6|C|Carbon|12.011|Reactive Nonmetal|14|2|M
7|N|Nitrogen|14.007|Reactive Nonmetal|15|2|M
8|O|Oxygen|15.999|Reactive Nonmetal|16|2|M
9|F|Fluorine|18.998|Halogen|17|2|M
10|Ne|Neon|20.180|Noble Gas|18|2|M
11|Na|Sodium|22.990|Alkali Metal|1|3|M
12|Mg|Magnesium|24.305|Alkaline Earth Metal|2|3|M
13|Al|Aluminum|26.982|Post-transition Metal|13|3|M
14|Si|Silicon|28.085|Metalloid|14|3|M
15|P|Phosphorus|30.974|Reactive Nonmetal|15|3|M
16|S|Sulfur|32.06|Reactive Nonmetal|16|3|M
17|Cl|Chlorine|35.45|Halogen|17|3|M
18|Ar|Argon|39.948|Noble Gas|18|3|M
19|K|Potassium|39.098|Alkali Metal|1|4|M
20|Ca|Calcium|40.078|Alkaline Earth Metal|2|4|M
21|Sc|Scandium|44.956|Transition Metal|3|4|M
22|Ti|Titanium|47.867|Transition Metal|4|4|M
23|V|Vanadium|50.942|Transition Metal|5|4|M
24|Cr|Chromium|51.996|Transition Metal|6|4|M
25|Mn|Manganese|54.938|Transition Metal|7|4|M
26|Fe|Iron|55.845|Transition Metal|8|4|M
27|Co|Cobalt|58.933|Transition Metal|9|4|M
28|Ni|Nickel|58.693|Transition Metal|10|4|M
29|Cu|Copper|63.546|Transition Metal|11|4|M
30|Zn|Zinc|65.38|Transition Metal|12|4|M
31|Ga|Gallium|69.723|Post-transition Metal|13|4|M
32|Ge|Germanium|72.630|Metalloid|14|4|M
33|As|Arsenic|74.922|Metalloid|15|4|M
34|Se|Selenium|78.971|Reactive Nonmetal|16|4|M
35|Br|Bromine|79.904|Halogen|17|4|M
36|Kr|Krypton|83.798|Noble Gas|18|4|M
37|Rb|Rubidium|85.468|Alkali Metal|1|5|M
38|Sr|Strontium|87.62|Alkaline Earth Metal|2|5|M
39|Y|Yttrium|88.906|Transition Metal|3|5|M
40|Zr|Zirconium|91.222|Transition Metal|4|5|M
41|Nb|Niobium|92.906|Transition Metal|5|5|M
42|Mo|Molybdenum|95.95|Transition Metal|6|5|M
43|Tc|Technetium|[98]|Transition Metal|7|5|M
44|Ru|Ruthenium|101.07|Transition Metal|8|5|M
45|Rh|Rhodium|102.91|Transition Metal|9|5|M
46|Pd|Palladium|106.42|Transition Metal|10|5|M
47|Ag|Silver|107.87|Transition Metal|11|5|M
48|Cd|Cadmium|112.41|Transition Metal|12|5|M
49|In|Indium|114.82|Post-transition Metal|13|5|M
50|Sn|Tin|118.71|Post-transition Metal|14|5|M
51|Sb|Antimony|121.76|Metalloid|15|5|M
52|Te|Tellurium|127.60|Metalloid|16|5|M
53|I|Iodine|126.90|Halogen|17|5|M
54|Xe|Xenon|131.29|Noble Gas|18|5|M
55|Cs|Cesium|132.91|Alkali Metal|1|6|M
56|Ba|Barium|137.33|Alkaline Earth Metal|2|6|M
57|La|Lanthanum|138.91|Lanthanide|1|8|L
58|Ce|Cerium|140.12|Lanthanide|2|8|L
59|Pr|Praseodymium|140.91|Lanthanide|3|8|L
60|Nd|Neodymium|144.24|Lanthanide|4|8|L
61|Pm|Promethium|[145]|Lanthanide|5|8|L
62|Sm|Samarium|150.36|Lanthanide|6|8|L
63|Eu|Europium|151.96|Lanthanide|7|8|L
64|Gd|Gadolinium|157.25|Lanthanide|8|8|L
65|Tb|Terbium|158.93|Lanthanide|9|8|L
66|Dy|Dysprosium|162.50|Lanthanide|10|8|L
67|Ho|Holmium|164.93|Lanthanide|11|8|L
68|Er|Erbium|167.26|Lanthanide|12|8|L
69|Tm|Thulium|168.93|Lanthanide|13|8|L
70|Yb|Ytterbium|173.05|Lanthanide|14|8|L
71|Lu|Lutetium|174.97|Lanthanide|15|8|L
72|Hf|Hafnium|178.49|Transition Metal|4|6|M
73|Ta|Tantalum|180.95|Transition Metal|5|6|M
74|W|Tungsten|183.84|Transition Metal|6|6|M
75|Re|Rhenium|186.21|Transition Metal|7|6|M
76|Os|Osmium|190.23|Transition Metal|8|6|M
77|Ir|Iridium|192.22|Transition Metal|9|6|M
78|Pt|Platinum|195.08|Transition Metal|10|6|M
79|Au|Gold|196.97|Transition Metal|11|6|M
80|Hg|Mercury|200.59|Transition Metal|12|6|M
81|Tl|Thallium|204.38|Post-transition Metal|13|6|M
82|Pb|Lead|207.2|Post-transition Metal|14|6|M
83|Bi|Bismuth|208.98|Post-transition Metal|15|6|M
84|Po|Polonium|[209]|Post-transition Metal|16|6|M
85|At|Astatine|[210]|Halogen|17|6|M
86|Rn|Radon|[222]|Noble Gas|18|6|M
87|Fr|Francium|[223]|Alkali Metal|1|7|M
88|Ra|Radium|[226]|Alkaline Earth Metal|2|7|M
89|Ac|Actinium|[227]|Actinide|1|9|A
90|Th|Thorium|232.04|Actinide|2|9|A
91|Pa|Protactinium|231.04|Actinide|3|9|A
92|U|Uranium|238.03|Actinide|4|9|A
93|Np|Neptunium|[237]|Actinide|5|9|A
94|Pu|Plutonium|[244]|Actinide|6|9|A
95|Am|Americium|[243]|Actinide|7|9|A
96|Cm|Curium|[247]|Actinide|8|9|A
97|Bk|Berkelium|[247]|Actinide|9|9|A
98|Cf|Californium|[251]|Actinide|10|9|A
99|Es|Einsteinium|[252]|Actinide|11|9|A
100|Fm|Fermium|[257]|Actinide|12|9|A
101|Md|Mendelevium|[258]|Actinide|13|9|A
102|No|Nobelium|[259]|Actinide|14|9|A
103|Lr|Lawrencium|[266]|Actinide|15|9|A
104|Rf|Rutherfordium|[267]|Transition Metal|4|7|M
105|Db|Dubnium|[268]|Transition Metal|5|7|M
106|Sg|Seaborgium|[269]|Transition Metal|6|7|M
107|Bh|Bohrium|[270]|Transition Metal|7|7|M
108|Hs|Hassium|[277]|Transition Metal|8|7|M
109|Mt|Meitnerium|[278]|Transition Metal|9|7|M
110|Ds|Darmstadtium|[281]|Transition Metal|10|7|M
111|Rg|Roentgenium|[282]|Transition Metal|11|7|M
112|Cn|Copernicium|[285]|Transition Metal|12|7|M
113|Nh|Nihonium|[286]|Post-transition Metal|13|7|M
114|Fl|Flerovium|[289]|Post-transition Metal|14|7|M
115|Mc|Moscovium|[290]|Post-transition Metal|15|7|M
116|Lv|Livermorium|[293]|Post-transition Metal|16|7|M
117|Ts|Tennessine|[294]|Halogen|17|7|M
118|Og|Oganesson|[294]|Noble Gas|18|7|M
]]

local elements = {}
local elementByNumber = {}
local elementAt = {}
for line in string.gmatch(rawData, "[^\r\n]+") do
    local fields = {}
    for field in string.gmatch(line, "[^|]+") do
        table.insert(fields, field)
    end
    if #fields == 8 then
        local e = {
            number = tonumber(fields[1]),
            symbol = fields[2],
            name = fields[3],
            mass = fields[4],
            category = fields[5],
            group = tonumber(fields[6]),
            period = tonumber(fields[7]),
            series = fields[8],
        }
        table.insert(elements, e)
        elementByNumber[e.number] = e
        if e.series == "M" then
            elementAt[tostring(e.period) .. ":" .. tostring(e.group)] = e
        end
    end
end

-- Short educational notes. Elements not listed below receive a safe, general note.
local rocketNotes = {
    H = "Hydrogen can be used as a rocket fuel. Liquid hydrogen (LH2) is commonly paired with liquid oxygen (LOX) in cryogenic rocket engines.",
    He = "Helium is an inert gas used in some launch systems for tank pressurization, purging, and ground-support operations. It is not a usual chemical rocket fuel.",
    Li = "Lithium is important in lightweight batteries and aerospace energy-storage research. Its high reactivity means it requires controlled handling.",
    B = "Boron-containing materials are researched for energetic applications and high-temperature materials, but they are not a routine main-stage rocket fuel.",
    C = "Carbon fibers and carbon-based composites can provide high stiffness at low mass for aerospace structures. The real material is usually a composite, not pure carbon alone.",
    N = "Nitrogen is used in ground systems for purging and testing. Liquid nitrogen is useful as a coolant, but it is not the same substance as liquid oxygen used as an oxidizer.",
    O = "Oxygen is a powerful oxidizer. Liquid oxygen (LOX) supports combustion with a fuel such as hydrogen or methane; oxygen itself is not the fuel in that pairing.",
    Ne = "Neon is mainly useful in specialized lighting, indicators, and research instruments rather than as a practical rocket propellant.",
    Na = "Sodium is chemically reactive and is more relevant to chemistry research and specialized materials than to ordinary rocket structures.",
    Mg = "Magnesium is a lightweight metal and appears in some pyrotechnic and materials applications. Its flammability must be considered in engineering designs.",
    Al = "Aluminum alloys offer a useful strength-to-weight balance for aerospace structures and tanks. Aluminum powder is also used in some solid propellant formulations.",
    Si = "Silicon is important in sensors, electronics, solar cells, and some ceramic materials used across aerospace systems.",
    Ar = "Argon is an inert gas used for some welding, purging, and laboratory processes. It is generally a support gas, not a conventional chemical rocket fuel.",
    Ti = "Titanium alloys combine high strength with relatively low mass and are used in selected aerospace structures and high-performance components.",
    V = "Vanadium is used in some high-strength alloys and materials research. Its value depends on the exact alloy and operating conditions.",
    Cr = "Chromium contributes corrosion resistance and high-temperature performance in many alloys and coatings.",
    Fe = "Iron is the base of steel, which can be used for ground equipment, structures, and some motor cases. It is usually heavier than aluminum or titanium for a comparable design goal.",
    Ni = "Nickel-based superalloys are valuable in hot sections of engines and turbomachinery because some retain strength at elevated temperatures.",
    Cu = "Copper's high thermal conductivity makes copper alloys useful in some regeneratively cooled rocket-engine combustion chambers and cooling channels.",
    Zn = "Zinc is used in coatings and materials chemistry; it is usually a supporting material rather than a primary rocket structure material.",
    Zr = "Zirconium compounds and alloys have specialized high-temperature and ceramic applications. The exact material formulation determines its performance.",
    Nb = "Niobium is used in selected high-temperature alloys and aerospace materials research.",
    Mo = "Molybdenum can contribute high-temperature strength in specialized components, but oxidation and operating environment matter.",
    Ag = "Silver is highly conductive and can appear in electrical contacts and specialized thermal or electronic components, but cost limits broad structural use.",
    Sn = "Tin is used in solder and coatings for electronics and electrical assemblies found in aerospace systems.",
    Xe = "Xenon is used as a propellant in some electric-propulsion systems, including ion and Hall-effect thrusters. Electric propulsion accelerates ions rather than burning fuel like a chemical engine.",
    Cs = "Cesium has specialized applications in atomic devices and research; it is not a routine rocket propellant and is highly reactive.",
    La = "Lanthanum and related rare-earth elements are used in specialized optical, electronic, catalytic, and material applications.",
    Nd = "Neodymium is used in strong permanent magnets that can be useful in motors, actuators, and other aerospace equipment.",
    Hf = "Hafnium compounds are studied for very high-temperature ceramics and thermal protection. The exact compound, not just the element, determines performance.",
    Ta = "Tantalum has corrosion-resistant and high-temperature applications in specialized components and electronics.",
    W = "Tungsten has an exceptionally high melting point and is used in some specialized high-temperature or dense components; its high density can be a disadvantage for flight mass.",
    Pt = "Platinum is used in specialized catalysts, sensors, and laboratory equipment. It is expensive and generally not used as a large structural material.",
    Au = "Gold is useful for corrosion-resistant electrical contacts and selected coatings in aerospace electronics, not as a main structural material.",
    Pb = "Lead is dense and toxic; it is generally unsuitable for many aerospace applications and requires strict controls wherever used.",
    U = "Uranium is radioactive and is not a normal chemical rocket fuel. Nuclear space-power or propulsion concepts require specialized engineering, regulation, and radiation protection.",
    Pu = "Some plutonium isotopes have been used as heat sources in radioisotope power systems for deep-space missions. This is not ordinary chemical propulsion and requires strict radiation controls.",
}

local safetyNotes = {
    H = "Highly flammable gas; liquid hydrogen is cryogenic and can cause severe cold burns. Keep away from ignition sources in any real-world context.",
    Be = "Beryllium dust and fumes are highly hazardous. This is a game encyclopedia, not a handling guide.",
    F = "Fluorine is extremely reactive and toxic.",
    Cl = "Chlorine gas is toxic and corrosive.",
    Na = "Sodium reacts strongly with water and can ignite. Do not treat the element as a casual crafting material in real life.",
    K = "Potassium reacts strongly with water and can ignite.",
    Mg = "Fine magnesium powder can burn intensely.",
    Br = "Bromine is toxic and corrosive.",
    Hg = "Mercury is toxic; exposure and environmental contamination must be avoided.",
    Pb = "Lead is toxic and can accumulate in the body.",
    Rn = "Radon is a radioactive gas and a health hazard when it accumulates indoors.",
    U = "Uranium is radioactive and chemically toxic. Real handling requires appropriate specialist controls.",
    Pu = "Plutonium is radioactive and highly controlled. Real handling requires specialist facilities and legal authorization.",
}

local categoryColors = {
    ["Alkali Metal"] = Color3.fromRGB(235, 145, 105),
    ["Alkaline Earth Metal"] = Color3.fromRGB(229, 190, 112),
    ["Transition Metal"] = Color3.fromRGB(104, 174, 220),
    ["Post-transition Metal"] = Color3.fromRGB(130, 194, 169),
    ["Metalloid"] = Color3.fromRGB(190, 159, 224),
    ["Reactive Nonmetal"] = Color3.fromRGB(112, 207, 188),
    ["Halogen"] = Color3.fromRGB(204, 151, 213),
    ["Noble Gas"] = Color3.fromRGB(127, 158, 238),
    ["Lanthanide"] = Color3.fromRGB(225, 157, 117),
    ["Actinide"] = Color3.fromRGB(211, 127, 147),
}

local function categoryColor(category)
    return categoryColors[category] or Color3.fromRGB(157, 168, 181)
end

local C = {
    bg = Color3.fromRGB(12, 23, 38),
    panel = Color3.fromRGB(23, 41, 60),
    panel2 = Color3.fromRGB(31, 55, 77),
    cell = Color3.fromRGB(24, 43, 61),
    line = Color3.fromRGB(119, 163, 198),
    text = Color3.fromRGB(242, 247, 253),
    muted = Color3.fromRGB(169, 190, 209),
    gold = Color3.fromRGB(222, 202, 158),
    cyan = Color3.fromRGB(120, 191, 255),
    warning = Color3.fromRGB(255, 171, 143),
}

local function make(className, parent, props)
    local obj = Instance.new(className)
    for key, value in pairs(props or {}) do
        obj[key] = value
    end
    obj.Parent = parent
    return obj
end

local function addCorner(parent, radius)
    make("UICorner", parent, { CornerRadius = UDim.new(0, radius or 8) })
end

local function addStroke(parent, color, thickness, transparency)
    return make("UIStroke", parent, {
        Color = color or C.line,
        Thickness = thickness or 1,
        Transparency = transparency or 0,
    })
end

local gui = make("ScreenGui", playerGui, {
    Name = "RocketPeriodicTableGUI",
    ResetOnSpawn = false,
    DisplayOrder = 20,
    IgnoreGuiInset = true,
    ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
})

local overlay = make("Frame", gui, {
    Name = "Overlay",
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.fromRGB(4, 7, 12),
    BackgroundTransparency = 0.25,
    BorderSizePixel = 0,
    Visible = false,
})

local window = make("Frame", overlay, {
    Name = "MainWindow",
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.new(0.96, 0, 0.86, 0),
    BackgroundColor3 = C.bg,
    BackgroundTransparency = 0.12,
    BorderSizePixel = 0,
    ClipsDescendants = true,
})
addCorner(window, 16)
addStroke(window, C.line, 1.4, 0.18)
make("UIGradient", window, {Rotation = 30, Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(35, 66, 93)), ColorSequenceKeypoint.new(1, C.bg)})})

local header = make("Frame", window, {
    Name = "Header",
    Position = UDim2.fromOffset(0, 0),
    Size = UDim2.new(1, 0, 0, 62),
    BackgroundColor3 = C.panel,
    BackgroundTransparency = 0.18,
    BorderSizePixel = 0,
})
make("UIGradient", header, {Rotation = 0, Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(47, 78, 105)), ColorSequenceKeypoint.new(1, C.panel)})})

make("TextLabel", header, {
    BackgroundTransparency = 1,
    Position = UDim2.fromOffset(20, 8),
    Size = UDim2.new(1, -100, 0, 27),
    Text = "PERIODIC TABLE  /  ROCKET SCIENCE",
    TextColor3 = C.text,
    TextSize = 20,
    Font = Enum.Font.GothamBold,
    TextXAlignment = Enum.TextXAlignment.Left,
})
make("TextLabel", header, {
    BackgroundTransparency = 1,
    Position = UDim2.fromOffset(21, 35),
    Size = UDim2.new(1, -110, 0, 17),
    Text = "118 ELEMENTS  •  MATERIALS DATABASE  •  SELECT ANY ELEMENT TO EXPLORE",
    TextColor3 = C.muted,
    TextSize = 10,
    Font = Enum.Font.GothamMedium,
    TextXAlignment = Enum.TextXAlignment.Left,
})

local closeButton = make("TextButton", header, {
    Name = "CloseButton",
    AnchorPoint = Vector2.new(1, 0.5),
    Position = UDim2.new(1, -14, 0.5, 0),
    Size = UDim2.fromOffset(38, 36),
    BackgroundColor3 = C.panel2,
    BorderSizePixel = 0,
    Text = "X",
    TextColor3 = C.text,
    TextSize = 15,
    Font = Enum.Font.GothamBold,
    AutoButtonColor = true,
})
addCorner(closeButton, 9)
addStroke(closeButton, C.line, 1)

local searchBox = make("TextBox", window, {
    Name = "SearchBox",
    Position = UDim2.fromOffset(18, 76),
    Size = UDim2.new(0.47, -8, 0, 36),
    BackgroundColor3 = C.panel2,
    BorderSizePixel = 0,
    ClearTextOnFocus = false,
    PlaceholderText = "Search name, symbol, or atomic number...",
    PlaceholderColor3 = C.muted,
    Text = "",
    TextColor3 = C.text,
    TextSize = 13,
    Font = Enum.Font.Gotham,
    TextXAlignment = Enum.TextXAlignment.Left,
})
addCorner(searchBox, 8)
addStroke(searchBox, C.line, 1)
make("UIPadding", searchBox, {
    PaddingLeft = UDim.new(0, 12),
    PaddingRight = UDim.new(0, 8),
})

local categoryNames = {
    "All", "Alkali Metal", "Alkaline Earth Metal", "Transition Metal",
    "Post-transition Metal", "Metalloid", "Reactive Nonmetal", "Halogen",
    "Noble Gas", "Lanthanide", "Actinide",
}
local selectedCategoryIndex = 1
local categoryButton = make("TextButton", window, {
    Name = "CategoryFilterButton",
    Position = UDim2.new(0.47, 4, 0, 76),
    Size = UDim2.new(0.25, -8, 0, 36),
    BackgroundColor3 = C.panel2,
    BorderSizePixel = 0,
    Text = "TYPE: ALL  v",
    TextColor3 = C.gold,
    TextSize = 12,
    Font = Enum.Font.GothamBold,
    AutoButtonColor = true,
})
addCorner(categoryButton, 8)
addStroke(categoryButton, C.line, 1)

local hintLabel = make("TextLabel", window, {
    Name = "CountLabel",
    Position = UDim2.new(0.73, 0, 0, 76),
    Size = UDim2.new(0.27, -18, 0, 36),
    BackgroundTransparency = 1,
    Text = "118 ELEMENTS",
    TextColor3 = C.muted,
    TextSize = 11,
    Font = Enum.Font.GothamMedium,
    TextXAlignment = Enum.TextXAlignment.Right,
})

local body = make("Frame", window, {
    Name = "Body",
    Position = UDim2.fromOffset(18, 123),
    Size = UDim2.new(1, -36, 1, -140),
    BackgroundTransparency = 1,
})

local tableZone = make("Frame", body, {
    Name = "PeriodicTableZone",
    Size = UDim2.new(0.745, -8, 1, 0),
    BackgroundTransparency = 1,
})

make("TextLabel", tableZone, {
    BackgroundTransparency = 1,
    Position = UDim2.fromOffset(2, 0),
    Size = UDim2.new(1, -4, 0, 22),
    Text = "ELEMENT GRID  /  GROUPS 1–18",
    TextColor3 = C.muted,
    TextSize = 10,
    Font = Enum.Font.GothamBold,
    TextXAlignment = Enum.TextXAlignment.Left,
})

local tableScroll = make("ScrollingFrame", tableZone, {
    Name = "TableScroll",
    Position = UDim2.fromOffset(0, 25),
    Size = UDim2.new(1, 0, 1, -25),
    BackgroundColor3 = C.panel,
    BorderSizePixel = 0,
    ScrollBarThickness = 6,
    ScrollBarImageColor3 = C.cyan,
    CanvasSize = UDim2.fromOffset(940, 474),
    ScrollingDirection = Enum.ScrollingDirection.XY,
    Active = true,
})
addCorner(tableScroll, 10)
addStroke(tableScroll, C.line, 1)

local mainGrid = make("Frame", tableScroll, {
    Name = "MainElementsGrid",
    Position = UDim2.fromOffset(10, 8),
    Size = UDim2.fromOffset(940, 320),
    BackgroundTransparency = 1,
})
make("UIGridLayout", mainGrid, {
    SortOrder = Enum.SortOrder.LayoutOrder,
    FillDirection = Enum.FillDirection.Horizontal,
    FillDirectionMaxCells = 18,
    CellSize = UDim2.fromOffset(47, 42),
    CellPadding = UDim2.fromOffset(4, 4),
})

make("TextLabel", tableScroll, {
    BackgroundTransparency = 1,
    Position = UDim2.fromOffset(112, 330),
    Size = UDim2.fromOffset(400, 17),
    Text = "LANTHANIDES  /  57–71",
    TextColor3 = C.muted,
    TextSize = 10,
    Font = Enum.Font.GothamBold,
    TextXAlignment = Enum.TextXAlignment.Left,
})
local lanthGrid = make("Frame", tableScroll, {
    Name = "LanthanidesGrid",
    Position = UDim2.fromOffset(112, 349),
    Size = UDim2.fromOffset(800, 44),
    BackgroundTransparency = 1,
})
make("UIGridLayout", lanthGrid, {
    SortOrder = Enum.SortOrder.LayoutOrder,
    FillDirection = Enum.FillDirection.Horizontal,
    FillDirectionMaxCells = 15,
    CellSize = UDim2.fromOffset(47, 42),
    CellPadding = UDim2.fromOffset(4, 4),
})

make("TextLabel", tableScroll, {
    BackgroundTransparency = 1,
    Position = UDim2.fromOffset(112, 397),
    Size = UDim2.fromOffset(400, 17),
    Text = "ACTINIDES  /  89–103",
    TextColor3 = C.muted,
    TextSize = 10,
    Font = Enum.Font.GothamBold,
    TextXAlignment = Enum.TextXAlignment.Left,
})
local actinGrid = make("Frame", tableScroll, {
    Name = "ActinidesGrid",
    Position = UDim2.fromOffset(112, 416),
    Size = UDim2.fromOffset(800, 44),
    BackgroundTransparency = 1,
})
make("UIGridLayout", actinGrid, {
    SortOrder = Enum.SortOrder.LayoutOrder,
    FillDirection = Enum.FillDirection.Horizontal,
    FillDirectionMaxCells = 15,
    CellSize = UDim2.fromOffset(47, 42),
    CellPadding = UDim2.fromOffset(4, 4),
})

local detailPanel = make("Frame", body, {
    Name = "ElementDetailsPanel",
    Position = UDim2.new(0.755, 0, 0, 0),
    Size = UDim2.new(0.245, 0, 1, 0),
    BackgroundColor3 = C.panel,
    BorderSizePixel = 0,
    ClipsDescendants = true,
})
addCorner(detailPanel, 10)
addStroke(detailPanel, C.line, 1)
make("TextLabel", detailPanel, {
    Position = UDim2.fromOffset(14, 11),
    Size = UDim2.new(1, -28, 0, 22),
    BackgroundTransparency = 1,
    Text = "ELEMENT DETAILS",
    TextColor3 = C.gold,
    TextSize = 11,
    Font = Enum.Font.GothamBold,
    TextXAlignment = Enum.TextXAlignment.Left,
})

local detailScroll = make("ScrollingFrame", detailPanel, {
    Name = "DetailsScroll",
    Position = UDim2.fromOffset(8, 38),
    Size = UDim2.new(1, -16, 1, -46),
    BackgroundTransparency = 1,
    BorderSizePixel = 0,
    ScrollBarThickness = 4,
    ScrollBarImageColor3 = C.cyan,
    CanvasSize = UDim2.new(0, 0, 0, 0),
    ScrollingDirection = Enum.ScrollingDirection.Y,
    Active = true,
})
local infoContent = make("Frame", detailScroll, {
    Name = "InfoContent",
    Position = UDim2.fromOffset(0, 0),
    Size = UDim2.new(1, 0, 0, 0),
    AutomaticSize = Enum.AutomaticSize.Y,
    BackgroundTransparency = 1,
})
local infoLayout = make("UIListLayout", infoContent, {
    SortOrder = Enum.SortOrder.LayoutOrder,
    Padding = UDim.new(0, 8),
})
make("UIPadding", infoContent, {
    PaddingLeft = UDim.new(0, 8),
    PaddingRight = UDim.new(0, 8),
    PaddingTop = UDim.new(0, 3),
    PaddingBottom = UDim.new(0, 12),
})

infoLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
    detailScroll.CanvasSize = UDim2.new(0, 0, 0, infoLayout.AbsoluteContentSize.Y + 24)
end)

local elementButtons = {}
local selectedElement = nil
local currentSearch = ""
local showElement -- forward declaration used by element-button click handlers

local function makeElementButton(parent, element, order)
    local tint = categoryColor(element.category)
    local button = make("TextButton", parent, {
        Name = "Element_" .. element.symbol,
        LayoutOrder = order or element.number,
        BackgroundColor3 = C.cell,
        BorderSizePixel = 0,
        Text = "",
        AutoButtonColor = false,
        ClipsDescendants = true,
    })
    addCorner(button, 6)
    local stroke = addStroke(button, tint, 1, 0.08)

    local numberLabel = make("TextLabel", button, {
        Name = "AtomicNumber",
        Position = UDim2.fromOffset(3, 1),
        Size = UDim2.new(1, -6, 0, 10),
        BackgroundTransparency = 1,
        Text = tostring(element.number),
        TextColor3 = C.muted,
        TextSize = 8,
        Font = Enum.Font.Gotham,
        TextXAlignment = Enum.TextXAlignment.Left,
    })
    local symbolLabel = make("TextLabel", button, {
        Name = "Symbol",
        Position = UDim2.fromOffset(1, 10),
        Size = UDim2.new(1, -2, 0, 21),
        BackgroundTransparency = 1,
        Text = element.symbol,
        TextColor3 = tint,
        TextSize = 17,
        Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Center,
    })
    local massLabel = make("TextLabel", button, {
        Name = "AtomicMass",
        Position = UDim2.new(0, 1, 1, -11),
        Size = UDim2.new(1, -2, 0, 10),
        BackgroundTransparency = 1,
        Text = element.mass,
        TextColor3 = C.muted,
        TextSize = 7,
        Font = Enum.Font.Gotham,
        TextXAlignment = Enum.TextXAlignment.Center,
    })

    elementButtons[element.number] = {
        button = button,
        stroke = stroke,
        numberLabel = numberLabel,
        symbolLabel = symbolLabel,
        massLabel = massLabel,
    }
    button.Activated:Connect(function()
        if button:GetAttribute("MatchesFilter") == false then
            return
        end
        selectedElement = element
        -- Update the selected border and rebuild the details panel.
        for _, other in pairs(elementButtons) do
            other.stroke.Color = categoryColor(other.button:GetAttribute("ElementCategory") or "")
            other.stroke.Thickness = 1
        end
        stroke.Color = C.gold
        stroke.Thickness = 2
        -- showElement is assigned before the GUI becomes interactive.
        if showElement then
            showElement(element)
        end
    end)
    button:SetAttribute("ElementCategory", element.category)
    button:SetAttribute("MatchesFilter", true)
    return button
end

-- Construct all 126 positions in the main 7 x 18 block, including inert spacer cells.
for period = 1, 7 do
    for group = 1, 18 do
        local element = elementAt[tostring(period) .. ":" .. tostring(group)]
        local order = (period - 1) * 18 + group
        if element then
            makeElementButton(mainGrid, element, order)
        elseif (period == 6 or period == 7) and group == 3 then
            local placeholder = make("Frame", mainGrid, {
                Name = "SeriesPlaceholder_" .. tostring(period),
                LayoutOrder = order,
                BackgroundColor3 = C.panel2,
                BackgroundTransparency = 0.12,
                BorderSizePixel = 0,
            })
            addCorner(placeholder, 6)
            addStroke(placeholder, C.line, 1, 0.4)
            make("TextLabel", placeholder, {
                Size = UDim2.fromScale(1, 1),
                BackgroundTransparency = 1,
                Text = period == 6 and "57–71" or "89–103",
                TextColor3 = C.gold,
                TextSize = 10,
                Font = Enum.Font.GothamBold,
            })
        else
            make("Frame", mainGrid, {
                Name = "Empty_" .. tostring(period) .. "_" .. tostring(group),
                LayoutOrder = order,
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
            })
        end
    end
end

for _, element in ipairs(elements) do
    if element.series == "L" then
        makeElementButton(lanthGrid, element, element.number)
    elseif element.series == "A" then
        makeElementButton(actinGrid, element, element.number)
    end
end

local function addInfoText(text, size, color, bold)
    return make("TextLabel", infoContent, {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, -4, 0, 0),
        AutomaticSize = Enum.AutomaticSize.Y,
        Text = text,
        TextColor3 = color or C.text,
        TextSize = size or 13,
        Font = bold and Enum.Font.GothamBold or Enum.Font.Gotham,
        TextWrapped = true,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top,
    })
end

local function addDivider()
    make("Frame", infoContent, {
        Size = UDim2.new(1, -4, 0, 1),
        BackgroundColor3 = C.line,
        BackgroundTransparency = 0.15,
        BorderSizePixel = 0,
    })
end

local function addTag(text, color)
    local tag = make("TextLabel", infoContent, {
        Size = UDim2.new(1, -4, 0, 26),
        BackgroundColor3 = C.panel2,
        BorderSizePixel = 0,
        Text = text,
        TextColor3 = color or C.gold,
        TextSize = 10,
        Font = Enum.Font.GothamBold,
        TextWrapped = true,
    })
    addCorner(tag, 7)
    addStroke(tag, color or C.line, 1, 0.4)
    return tag
end

showElement = function(element)
    for _, child in ipairs(infoContent:GetChildren()) do
        if not child:IsA("UIListLayout") and not child:IsA("UIPadding") then
            child:Destroy()
        end
    end

    local tint = categoryColor(element.category)
    addInfoText(string.format("ELEMENT %03d  /  %s", element.number, string.upper(element.symbol)), 11, C.muted, true)
    addInfoText(element.name, 26, C.text, true)
    addInfoText(element.symbol, 38, tint, true)
    addTag(element.category, tint)
    addDivider()
    addInfoText("ATOMIC NUMBER", 10, C.muted, true)
    addInfoText(tostring(element.number) .. " protons", 16, C.text, true)
    addInfoText("For a neutral atom, the electron count equals the atomic number.", 11, C.muted, false)
    addDivider()
    addInfoText("STANDARD ATOMIC MASS", 10, C.muted, true)
    addInfoText(element.mass .. " u", 22, C.gold, true)
    addInfoText("u = unified atomic mass unit. Values for radioactive or short-lived elements may be shown as bracketed mass numbers.", 11, C.muted, false)
    addDivider()
    addInfoText("ROCKET SCIENCE APPLICATION", 10, C.cyan, true)
    addInfoText(rocketNotes[element.symbol] or "This element may be relevant to specialized materials science, electronics, sensors, chemistry, or research. Its practical use depends on the exact compound, alloy, physical state, and operating conditions; it is not necessarily a rocket propellant.", 12, C.text, false)

    local warning = safetyNotes[element.symbol]
    if warning then
        addDivider()
        addInfoText("SAFETY NOTE", 10, C.warning, true)
        addInfoText(warning, 12, C.warning, false)
    end
    addDivider()
    addInfoText("GAME DATABASE TIP", 10, C.muted, true)
    addInfoText("You can use the atomic number as a stable Resource ID in your game's inventory, crafting recipes, research tree, and global exchange market.", 11, C.muted, false)
end


local function doesMatch(element)
    local search = string.lower(currentSearch)
    local searchMatch = search == ""
        or string.find(string.lower(element.name), search, 1, true) ~= nil
        or string.find(string.lower(element.symbol), search, 1, true) ~= nil
        or string.find(tostring(element.number), search, 1, true) ~= nil
        or string.find(string.lower(element.category), search, 1, true) ~= nil
    local activeCategory = categoryNames[selectedCategoryIndex]
    local categoryMatch = activeCategory == "All" or element.category == activeCategory
    return searchMatch and categoryMatch
end

local function updateFilters()
    local matches = 0
    for _, element in ipairs(elements) do
        local refs = elementButtons[element.number]
        local matched = doesMatch(element)
        if matched then
            matches += 1
        end
        refs.button:SetAttribute("MatchesFilter", matched)
        refs.button.BackgroundTransparency = matched and 0 or 0.76
        refs.stroke.Transparency = matched and 0.08 or 0.85
        refs.numberLabel.TextColor3 = matched and C.muted or Color3.fromRGB(76, 84, 96)
        refs.symbolLabel.TextColor3 = matched and categoryColor(element.category) or Color3.fromRGB(76, 84, 96)
        refs.massLabel.TextColor3 = matched and C.muted or Color3.fromRGB(76, 84, 96)
        if element == selectedElement then
            refs.stroke.Color = C.gold
            refs.stroke.Thickness = 2
            refs.stroke.Transparency = 0
        else
            refs.stroke.Color = categoryColor(element.category)
            refs.stroke.Thickness = 1
        end
    end
    hintLabel.Text = string.format("%d / 118 ELEMENTS", matches)
    local category = categoryNames[selectedCategoryIndex]
    categoryButton.Text = category == "All" and "TYPE: ALL  v" or ("TYPE: " .. string.upper(category) .. "  v")
end

searchBox:GetPropertyChangedSignal("Text"):Connect(function()
    currentSearch = searchBox.Text
    updateFilters()
end)

categoryButton.Activated:Connect(function()
    selectedCategoryIndex += 1
    if selectedCategoryIndex > #categoryNames then
        selectedCategoryIndex = 1
    end
    updateFilters()
end)

-- APP STORE + HARDWARE PAGE
-- App Store is the first pinned application. Apps are registered as hidden templates;
-- the loaded player profile decides which Dock icons actually appear.
local AppRegistry = require(ReplicatedStorage:WaitForChild("AltheaAppRegistry"))
local APP_CATALOG = AppRegistry.GetStoreCatalog()

local RAM_TIERS = {
    { Level = 1, CapacityMB = 4096, Name = "4 GB", Price = 0, Description = "Standard unified memory" },
    { Level = 2, CapacityMB = 8192, Name = "8 GB", Price = 350, Description = "More room for running apps" },
    { Level = 3, CapacityMB = 16384, Name = "16 GB", Price = 800, Description = "For research and engineering apps" },
    { Level = 4, CapacityMB = 32768, Name = "32 GB", Price = 1800, Description = "High-capacity workstation memory" },
}

local WINDOW_BY_APP_ID = {}
for _, app in ipairs(AppRegistry.Apps) do
    WINDOW_BY_APP_ID[app.Id] = app.WindowName
end

currentProfile = {
    Credits = 1200,
    InstalledApps = { AppStore = true, PeriodicTable = true, Settings = true, Battery = true, AirDrop = true, MyFiles = true, AppRequests = true, AltheaSupply = true, AltheaMap = true, AltheaTag = true, JobBoard = true, GlobalExchange = true },
    RAMLevel = 1,
    RamCapacityMB = 4096,
    StorageCapacityMB = 32768,
    StorageUsedMB = 680,
    BatteryPercent = 100,
    BatteryCharging = false,
    Settings = { Wallpaper = "Orbit", DockAutoHide = true, ReducedMotion = false, ShowBatteryPercent = true, AirDropMode = "Everyone", DeviceName = "AltheaBook" },
    FileCount = 2,
    Inventory = {},
    Orders = {},
    Trackers = {},
    ActiveJobs = {},
}
local storePage = "Apps"
local storeStatusLabel
local storeContent
local storeSummaryLabel
local appStoreWindow

local function formatSize(mb)
    if mb >= 1024 then
        return string.format("%.1f GB", mb / 1024)
    end
    return string.format("%d MB", mb)
end

local function getCatalogApp(appId)
    for _, app in ipairs(APP_CATALOG) do
        if app.Id == appId then
            return app
        end
    end
    return nil
end

local function appInstalled(appId)
    return currentProfile.InstalledApps and currentProfile.InstalledApps[appId] == true
end

local function clearStoreContent()
    for _, child in ipairs(storeContent:GetChildren()) do
        if not child:IsA("UIListLayout") and not child:IsA("UIPadding") then
            child:Destroy()
        end
    end
end

local function setStoreStatus(message, success)
    if not storeStatusLabel then return end
    storeStatusLabel.Text = tostring(message or "")
    storeStatusLabel.TextColor3 = success == false and C.warning or C.cyan
end

local function refreshProfileAndStatus(response)
    if type(response) ~= "table" then
        setStoreStatus("No response from AltheaBook service.", false)
        return false
    end
    if response.profile then
        currentProfile = response.profile
        currentProfile.InstalledApps = currentProfile.InstalledApps or {}
        osManager:SetRAMCapacityMB(currentProfile.RamCapacityMB or 4096)
        currentProfile.Settings = currentProfile.Settings or { Wallpaper = "Orbit", DockAutoHide = true, ReducedMotion = false, ShowBatteryPercent = true, AirDropMode = "Everyone", DeviceName = "AltheaBook" }
        osManager:SetWallpaperStyle(currentProfile.Settings.Wallpaper or "Orbit")
        osManager:SetDockAutoHide(currentProfile.Settings.DockAutoHide ~= false)
        osManager:SetReducedMotion(currentProfile.Settings.ReducedMotion == true)
        osManager:SetShowBatteryPercent(currentProfile.Settings.ShowBatteryPercent ~= false)
        osManager:SetBatteryPercent(currentProfile.BatteryPercent or 100, currentProfile.BatteryCharging == true)
        for appId, windowName in pairs(WINDOW_BY_APP_ID) do
            if osManager.windows[windowName] then
                osManager:SetWindowInstalled(windowName, currentProfile.InstalledApps[appId] == true)
            end
        end
    end
    setStoreStatus(response.message or (response.ok and "Ready." or "Request failed."), response.ok)
    return response.ok == true
end

local function performStoreAction(action, arguments)
    setStoreStatus("Contacting AltheaBook service…", true)
    local response = requestServer(action, arguments)
    refreshProfileAndStatus(response)
    return response
end

local function makeStoreButton(parent, name, text, position, size, accent)
    local button = make("TextButton", parent, {
        Name = name,
        Position = position,
        Size = size,
        BackgroundColor3 = accent or C.panel2,
        BorderSizePixel = 0,
        Text = text,
        TextColor3 = C.text,
        TextSize = 12,
        Font = Enum.Font.GothamBold,
        AutoButtonColor = true,
    })
    addCorner(button, 8)
    addStroke(button, accent or C.line, 1, 0.4)
    return button
end

appStoreWindow = make("Frame", gui, {
    Name = "AppWindow_AppStore",
    Size = UDim2.new(0.82, 0, 0.78, 0),
    Position = UDim2.new(0.5, 0, 0.49, 0),
    AnchorPoint = Vector2.new(0.5, 0.5),
    BackgroundColor3 = C.bg,
    BorderSizePixel = 0,
    Visible = false,
    ClipsDescendants = true,
})
addCorner(appStoreWindow, 14)
addStroke(appStoreWindow, C.line, 1.2, 0.05)
local appStoreHeader = make("Frame", appStoreWindow, {
    Name = "Header", Size = UDim2.new(1, 0, 0, 52),
    BackgroundColor3 = C.panel, BorderSizePixel = 0,
})
make("TextLabel", appStoreHeader, {
    Name = "Title", Position = UDim2.fromOffset(82, 0), Size = UDim2.new(1, -110, 1, 0),
    BackgroundTransparency = 1, Text = "App Store", TextColor3 = C.text,
    TextSize = 17, Font = Enum.Font.GothamBold, TextXAlignment = Enum.TextXAlignment.Left,
})
local appStoreClose = make("TextButton", appStoreHeader, {
    Name = "CloseButton", Position = UDim2.fromOffset(16, 19), Size = UDim2.fromOffset(14, 14),
    BackgroundColor3 = Color3.fromRGB(255, 95, 86), BorderSizePixel = 0,
    Text = "", AutoButtonColor = true,
})
addCorner(appStoreClose, 8)

storeSummaryLabel = make("TextLabel", appStoreWindow, {
    Name = "SystemSummary", Position = UDim2.fromOffset(18, 62), Size = UDim2.new(1, -36, 0, 42),
    BackgroundColor3 = C.panel2, BorderSizePixel = 0,
    Text = "CREDITS  1,200     RAM  4 GB     STORAGE  0 / 32 GB",
    TextColor3 = C.gold, TextSize = 12, Font = Enum.Font.GothamBold,
    TextXAlignment = Enum.TextXAlignment.Left,
})
addCorner(storeSummaryLabel, 8)
make("UIPadding", storeSummaryLabel, { PaddingLeft = UDim.new(0, 14), PaddingRight = UDim.new(0, 10) })

local nav = make("Frame", appStoreWindow, {
    Name = "StoreNavigation", Position = UDim2.fromOffset(18, 116), Size = UDim2.new(0, 150, 1, -134),
    BackgroundColor3 = C.panel, BorderSizePixel = 0,
})
addCorner(nav, 10)
local appsNavButton = makeStoreButton(nav, "AppsButton", "▦   DISCOVER APPS", UDim2.fromOffset(8, 10), UDim2.new(1, -16, 0, 40), C.panel2)
local hardwareNavButton = makeStoreButton(nav, "HardwareButton", "▤   RAM & HARDWARE", UDim2.fromOffset(8, 58), UDim2.new(1, -16, 0, 40), C.panel2)
storeStatusLabel = make("TextLabel", nav, {
    Name = "StoreStatus", Position = UDim2.new(0, 10, 1, -112), Size = UDim2.new(1, -20, 0, 102),
    BackgroundTransparency = 1, Text = "Loading profile…", TextColor3 = C.cyan,
    TextSize = 11, Font = Enum.Font.Gotham, TextWrapped = true,
    TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Bottom,
})

storeContent = make("ScrollingFrame", appStoreWindow, {
    Name = "StoreContent", Position = UDim2.new(0, 180, 0, 116), Size = UDim2.new(1, -198, 1, -134),
    BackgroundTransparency = 1, BorderSizePixel = 0, CanvasSize = UDim2.new(0, 0, 0, 0),
    AutomaticCanvasSize = Enum.AutomaticSize.Y, ScrollingDirection = Enum.ScrollingDirection.Y,
    ScrollBarThickness = 5, ScrollBarImageColor3 = C.line, ClipsDescendants = true,
})
make("UIPadding", storeContent, {
    PaddingTop = UDim.new(0, 2), PaddingBottom = UDim.new(0, 8),
    PaddingLeft = UDim.new(0, 2), PaddingRight = UDim.new(0, 8),
})
make("UIListLayout", storeContent, {
    FillDirection = Enum.FillDirection.Vertical, SortOrder = Enum.SortOrder.LayoutOrder,
    Padding = UDim.new(0, 9),
})

local function updateStoreSummary()
    if not storeSummaryLabel then return end
    local cap = tonumber(currentProfile.StorageCapacityMB) or 32768
    local used = tonumber(currentProfile.StorageUsedMB) or 0
    local ramCap = tonumber(currentProfile.RamCapacityMB) or osManager:GetRAMCapacityMB()
    local ramUsage = osManager:GetRAMUsageMB()
    storeSummaryLabel.Text = string.format(
        "CREDITS  %s     RAM  %s (%s in use)     STORAGE  %s / %s",
        tostring(currentProfile.Credits or 0),
        formatSize(ramCap), formatSize(ramUsage), formatSize(used), formatSize(cap)
    )
end

local function renderAppsPage()
    clearStoreContent()
    for index, app in ipairs(APP_CATALOG) do
        local installed = appInstalled(app.Id)
        local card = make("Frame", storeContent, {
            Name = "AppCard_" .. app.Id,
            Size = UDim2.new(1, -6, 0, 94),
            BackgroundColor3 = C.panel,
            BorderSizePixel = 0,
            LayoutOrder = index,
        })
        addCorner(card, 10)
        addStroke(card, C.line, 1, 0.35)
        local icon = make("TextLabel", card, {
            Name = "Icon", Position = UDim2.fromOffset(12, 18), Size = UDim2.fromOffset(56, 56),
            BackgroundColor3 = C.panel2, BorderSizePixel = 0, Text = app.Icon,
            TextColor3 = C.gold, TextSize = 25, Font = Enum.Font.GothamBold,
        })
        addCorner(icon, 10)
        make("TextLabel", card, {
            Name = "AppName", Position = UDim2.fromOffset(80, 12), Size = UDim2.new(1, -278, 0, 23),
            BackgroundTransparency = 1, Text = app.Name, TextColor3 = C.text,
            TextSize = 14, Font = Enum.Font.GothamBold, TextXAlignment = Enum.TextXAlignment.Left,
        })
        make("TextLabel", card, {
            Name = "Description", Position = UDim2.fromOffset(80, 37), Size = UDim2.new(1, -278, 0, 42),
            BackgroundTransparency = 1, Text = string.format("%s\n%s • %s RAM", app.Description, formatSize(app.SizeMB), formatSize(app.RamMB)),
            TextColor3 = C.muted, TextSize = 10, Font = Enum.Font.Gotham,
            TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Top,
        })
        local actionText
        local available = app.Status == nil or app.Status == "Available"
        if not available then
            actionText = string.upper(tostring(app.Status))
        elseif installed then
            actionText = "OPEN"
        elseif app.Price == 0 then
            actionText = "GET FREE"
        else
            actionText = tostring(app.Price) .. " CR"
        end
        local action = makeStoreButton(card, "Action", actionText, UDim2.new(1, -104, 0.5, -15), UDim2.fromOffset(92, 30), installed and Color3.fromRGB(39, 73, 65) or C.panel2)
        action.Active = available
        action.AutoButtonColor = available
        action.BackgroundTransparency = available and 0 or 0.35
        action.Activated:Connect(function()
            if not available then
                setStoreStatus(app.Name .. " is not available yet.", false)
                return
            end
            if installed then
                local opened = osManager:OpenWindow(app.WindowName)
                if opened then
                    setStoreStatus("Opened " .. app.Name .. ".", true)
                end
                updateStoreSummary()
                return
            end
            local response = performStoreAction("InstallApp", { appId = app.Id })
            if response.profile then
                currentProfile = response.profile
                if response.ok then
                    setStoreStatus(response.message or ("Installed " .. app.Name .. "."), true)
                end
                updateStoreSummary()
                renderAppsPage()
            end
        end)
        if installed and not app.Protected then
            local remove = makeStoreButton(card, "Remove", "REMOVE", UDim2.new(1, -104, 0.5, 20), UDim2.fromOffset(92, 23), Color3.fromRGB(73, 42, 48))
            remove.TextSize = 10
            remove.Activated:Connect(function()
                local response = performStoreAction("UninstallApp", { appId = app.Id })
                if response.profile then
                    currentProfile = response.profile
                    updateStoreSummary()
                    renderAppsPage()
                end
            end)
        end
    end
    updateStoreSummary()
end

local function renderHardwarePage()
    clearStoreContent()
    local currentLevel = tonumber(currentProfile.RAMLevel) or 1
    local currentTier = RAM_TIERS[currentLevel] or RAM_TIERS[1]
    local usage = osManager:GetRAMUsageMB()
    local info = make("Frame", storeContent, {
        Name = "RAMOverview", Size = UDim2.new(1, -6, 0, 118),
        BackgroundColor3 = C.panel, BorderSizePixel = 0, LayoutOrder = 1,
    })
    addCorner(info, 10)
    addStroke(info, C.line, 1, 0.35)
    make("TextLabel", info, {
        Position = UDim2.fromOffset(16, 12), Size = UDim2.new(1, -32, 0, 30),
        BackgroundTransparency = 1, Text = "UNIFIED MEMORY / RAM",
        TextColor3 = C.gold, TextSize = 11, Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
    })
    make("TextLabel", info, {
        Name = "CurrentRamUsage",
        Position = UDim2.fromOffset(16, 39), Size = UDim2.new(1, -32, 0, 34),
        BackgroundTransparency = 1, Text = string.format("%s installed  ·  %s currently allocated", currentTier.Name, formatSize(usage)),
        TextColor3 = C.text, TextSize = 19, Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
    })
    make("TextLabel", info, {
        Position = UDim2.fromOffset(16, 77), Size = UDim2.new(1, -32, 0, 28),
        BackgroundTransparency = 1, Text = "Open apps consume simulated RAM. Installed app files use storage, not RAM.",
        TextColor3 = C.muted, TextSize = 10, Font = Enum.Font.Gotham,
        TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Left,
    })

    for index, tier in ipairs(RAM_TIERS) do
        local card = make("Frame", storeContent, {
            Name = "RAMTier_" .. tostring(tier.Level), Size = UDim2.new(1, -6, 0, 78),
            BackgroundColor3 = C.panel, BorderSizePixel = 0, LayoutOrder = index + 1,
        })
        addCorner(card, 10)
        addStroke(card, C.line, 1, 0.35)
        make("TextLabel", card, {
            Position = UDim2.fromOffset(14, 10), Size = UDim2.new(0.55, -10, 0, 26),
            BackgroundTransparency = 1, Text = tier.Name .. " RAM", TextColor3 = C.text,
            TextSize = 15, Font = Enum.Font.GothamBold, TextXAlignment = Enum.TextXAlignment.Left,
        })
        make("TextLabel", card, {
            Position = UDim2.fromOffset(14, 39), Size = UDim2.new(0.68, -10, 0, 22),
            BackgroundTransparency = 1, Text = tier.Description, TextColor3 = C.muted,
            TextSize = 10, Font = Enum.Font.Gotham, TextXAlignment = Enum.TextXAlignment.Left,
        })
        local buttonText, buttonColor, canUpgrade
        if tier.Level == currentLevel then
            buttonText, buttonColor, canUpgrade = "CURRENT", Color3.fromRGB(39, 73, 65), false
        elseif tier.Level < currentLevel then
            buttonText, buttonColor, canUpgrade = "OWNED", C.panel2, false
        elseif tier.Level == currentLevel + 1 then
            buttonText, buttonColor, canUpgrade = tostring(tier.Price) .. " CR", C.panel2, true
        else
            buttonText, buttonColor, canUpgrade = "LOCKED", C.panel2, false
        end
        local upgrade = makeStoreButton(card, "Upgrade", buttonText, UDim2.new(1, -118, 0.5, -15), UDim2.fromOffset(104, 30), buttonColor)
        upgrade.Active = canUpgrade
        upgrade.AutoButtonColor = canUpgrade
        upgrade.TextColor3 = canUpgrade and C.gold or C.muted
        upgrade.Activated:Connect(function()
            if not canUpgrade then return end
            local response = performStoreAction("UpgradeRAM", { targetLevel = tier.Level })
            if response.profile then
                currentProfile = response.profile
                updateStoreSummary()
                renderHardwarePage()
            end
        end)
    end
    updateStoreSummary()
end

local function renderStore()
    if storePage == "Hardware" then
        renderHardwarePage()
    else
        renderAppsPage()
    end
end

appsNavButton.Activated:Connect(function()
    storePage = "Apps"
    appsNavButton.BackgroundColor3 = C.panel2
    hardwareNavButton.BackgroundColor3 = C.panel
    renderStore()
end)
hardwareNavButton.Activated:Connect(function()
    storePage = "Hardware"
    appsNavButton.BackgroundColor3 = C.panel
    hardwareNavButton.BackgroundColor3 = C.panel2
    renderStore()
end)

osManager:RegisterWindow("App Store", appStoreWindow, {
    Header = appStoreHeader,
    CloseButton = appStoreClose,
    DockIcon = "🛍",
    DefaultSize = UDim2.new(0.82, 0, 0.78, 0),
    DefaultPosition = UDim2.new(0.5, 0, 0.49, 0),
    Modal = true,
    BlurSize = 10,
    EscapeCloses = true,
    Installed = true,
    RamMB = 300,
})
renderStore()

-- Register Periodic Table in the shared AltheaOS window manager.
-- The manager reparents this window into its shared shell and owns close/minimize/maximize,
-- tab switching, drag/resize, modal dimming, and background blur.
osManager:RegisterWindow("Periodic Table", window, {
    Header = header,
    CloseButton = closeButton,
    DockIcon = "⚛",
    DefaultSize = UDim2.new(0.96, 0, 0.86, 0),
    DefaultPosition = UDim2.new(0.5, 0, 0.49, 0),
    Modal = true,
    BlurSize = 12,
    EscapeCloses = true,
    Installed = true,
    RamMB = 460,
})

-- Register lightweight app shells as templates. The server profile decides what is installed.
-- These are deliberate placeholders; their simulation/data functionality can be added later.
local function registerPlaceholder(name, icon, subtitle, description, accent, ramMB)
    local frame = make("Frame", gui, {
        Name = "AppWindow_" .. name:gsub("[^%w]", ""),
        Size = UDim2.new(0.72, 0, 0.66, 0),
        Position = UDim2.new(0.5, 0, 0.49, 0),
        AnchorPoint = Vector2.new(0.5, 0.5),
        BackgroundColor3 = C.bg,
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        Visible = false,
        ClipsDescendants = true,
    })
    addCorner(frame, 14)
    addStroke(frame, C.line, 1, 0.18)
    make("UIGradient", frame, {Rotation = 28, Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(35, 66, 93)), ColorSequenceKeypoint.new(1, C.bg)})})
    local head = make("Frame", frame, {
        Name = "Header",
        Size = UDim2.new(1, 0, 0, 46),
        BackgroundColor3 = C.panel,
        BackgroundTransparency = 0.20,
        BorderSizePixel = 0,
    })
    make("UIGradient", head, {Rotation = 0, Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(48, 79, 107)), ColorSequenceKeypoint.new(1, C.panel)})})
    local close = make("TextButton", head, {
        Name = "CloseButton",
        Position = UDim2.fromOffset(16, 16),
        Size = UDim2.fromOffset(14, 14),
        BackgroundColor3 = Color3.fromRGB(255, 95, 86),
        BorderSizePixel = 0,
        Text = "",
        AutoButtonColor = true,
    })
    addCorner(close, 10)
    make("TextLabel", head, {
        Name = "Title",
        Position = UDim2.fromOffset(82, 0),
        Size = UDim2.new(1, -100, 1, 0),
        BackgroundTransparency = 1,
        Text = name,
        TextColor3 = C.text,
        TextSize = 14,
        Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
    })
    make("TextLabel", frame, {
        Name = "AppIcon",
        Position = UDim2.new(0, 28, 0, 86),
        Size = UDim2.fromOffset(76, 76),
        BackgroundColor3 = C.panel2,
        BorderSizePixel = 0,
        Text = icon,
        TextColor3 = accent or C.gold,
        TextSize = 36,
        Font = Enum.Font.GothamBold,
    })
    make("TextLabel", frame, {
        Name = "AppHeadline",
        Position = UDim2.new(0, 126, 0, 87),
        Size = UDim2.new(1, -154, 0, 42),
        BackgroundTransparency = 1,
        Text = subtitle,
        TextColor3 = C.text,
        TextSize = 22,
        Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextWrapped = true,
    })
    make("TextLabel", frame, {
        Name = "AppDescription",
        Position = UDim2.new(0, 126, 0, 138),
        Size = UDim2.new(1, -160, 0, 100),
        BackgroundTransparency = 1,
        Text = description,
        TextColor3 = C.muted,
        TextSize = 14,
        Font = Enum.Font.Gotham,
        TextWrapped = true,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top,
    })
    local status = make("TextLabel", frame, {
        Name = "AppStatus",
        Position = UDim2.new(0, 28, 1, -58),
        Size = UDim2.new(1, -56, 0, 30),
        BackgroundColor3 = C.panel,
        BorderSizePixel = 0,
        Text = "ALTHEAOS  •  APP SHELL READY",
        TextColor3 = accent or C.gold,
        TextSize = 11,
        Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
    })
    addCorner(status, 7)
    osManager:RegisterWindow(name, frame, {
        Header = head,
        CloseButton = close,
        DockIcon = icon,
        DefaultSize = UDim2.new(0.78, 0, 0.70, 0),
        DefaultPosition = UDim2.new(0.5, 0, 0.49, 0),
        Modal = true,
        BlurSize = 12,
        EscapeCloses = true,
        Installed = false,
        RamMB = ramMB or 320,
    })
end

-- =========================
-- AltheaBook system apps: Settings, Battery, My Files and AirDrop
-- These are local UI windows; all persistent state and file-transfer validation remains server-owned.
local function makeSystemAppWindow(name, icon, ramMB, defaultSize)
    local frame = make("Frame", gui, {
        Name = "AppWindow_" .. name:gsub("[^%w]", ""),
        Size = defaultSize or UDim2.new(0.78, 0, 0.72, 0),
        Position = UDim2.new(0.5, 0, 0.49, 0),
        AnchorPoint = Vector2.new(0.5, 0.5),
        BackgroundColor3 = C.bg,
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        Visible = false,
        ClipsDescendants = true,
    })
    addCorner(frame, 16)
    addStroke(frame, C.line, 1.2, 0.18)
    make("UIGradient", frame, {Rotation = 32, Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(36, 68, 96)), ColorSequenceKeypoint.new(1, C.bg)})})
    local header = make("Frame", frame, {
        Name = "Header", Size = UDim2.new(1, 0, 0, 48),
        BackgroundColor3 = C.panel, BackgroundTransparency = 0.18, BorderSizePixel = 0,
    })
    make("UIGradient", header, {Rotation = 0, Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(47, 78, 105)), ColorSequenceKeypoint.new(1, C.panel)})})
    local close = make("TextButton", header, {
        Name = "CloseButton", Position = UDim2.fromOffset(16, 17), Size = UDim2.fromOffset(14, 14),
        BackgroundColor3 = Color3.fromRGB(255, 95, 86), BorderSizePixel = 0,
        Text = "", AutoButtonColor = true,
    })
    addCorner(close, 8)
    make("TextLabel", header, {
        Name = "Title", Position = UDim2.fromOffset(82, 0), Size = UDim2.new(1, -100, 1, 0),
        BackgroundTransparency = 1, Text = name, TextColor3 = C.text, TextSize = 15,
        Font = Enum.Font.GothamBold, TextXAlignment = Enum.TextXAlignment.Left,
    })
    local body = make("Frame", frame, {
        Name = "Body", Position = UDim2.fromOffset(0, 48), Size = UDim2.new(1, 0, 1, -48),
        BackgroundTransparency = 1, BorderSizePixel = 0,
    })
    return frame, body, header, close
end

local function registerSystemApp(name, icon, ramMB, defaultSize, frame, header, close)
    osManager:RegisterWindow(name, frame, {
        Header = header,
        CloseButton = close,
        DockIcon = icon,
        DefaultSize = defaultSize or UDim2.new(0.78, 0, 0.72, 0),
        DefaultPosition = UDim2.new(0.5, 0, 0.49, 0),
        Modal = false,
        BlurSize = 6,
        EscapeCloses = true,
        Installed = true,
        RamMB = ramMB or 180,
    })
end

local function makeSystemLabel(parent, text, position, size, color, textSize, bold)
    return make("TextLabel", parent, {
        Position = position, Size = size, BackgroundTransparency = 1,
        Text = text, TextColor3 = color or C.text, TextSize = textSize or 12,
        Font = bold and Enum.Font.GothamBold or Enum.Font.Gotham,
        TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Center,
        TextWrapped = true,
    })
end

local function makeSystemButton(parent, name, text, position, size, accent)
    local button = make("TextButton", parent, {
        Name = name, Position = position, Size = size,
        BackgroundColor3 = accent or C.panel2, BorderSizePixel = 0,
        Text = text, TextColor3 = C.text, TextSize = 11, Font = Enum.Font.GothamBold,
        AutoButtonColor = true,
    })
    addCorner(button, 8)
    addStroke(button, accent or C.line, 1, 0.42)
    return button
end

local function makeSystemScroll(parent, name, position, size)
    local scroll = make("ScrollingFrame", parent, {
        Name = name, Position = position, Size = size, BackgroundColor3 = C.panel,
        BorderSizePixel = 0, CanvasSize = UDim2.new(0, 0, 0, 0),
        AutomaticCanvasSize = Enum.AutomaticSize.Y, ScrollingDirection = Enum.ScrollingDirection.Y,
        ScrollBarThickness = 4, ScrollBarImageColor3 = C.line,
    })
    addCorner(scroll, 10)
    make("UIPadding", scroll, {
        PaddingTop = UDim.new(0, 8), PaddingBottom = UDim.new(0, 8),
        PaddingLeft = UDim.new(0, 8), PaddingRight = UDim.new(0, 8),
    })
    make("UIListLayout", scroll, {
        FillDirection = Enum.FillDirection.Vertical, SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0, 7),
    })
    return scroll
end

local function clearSystemScroll(scroll)
    for _, child in ipairs(scroll:GetChildren()) do
        if not child:IsA("UIListLayout") and not child:IsA("UIPadding") then child:Destroy() end
    end
end

-- Settings window
local settingsWindow, settingsBody, settingsHeader, settingsClose = makeSystemAppWindow("Settings", "⚙", 160, UDim2.new(0.76, 0, 0.74, 0))
makeSystemLabel(settingsBody, "System Preferences", UDim2.fromOffset(20, 14), UDim2.new(1, -40, 0, 28), C.text, 22, true)
makeSystemLabel(settingsBody, "Personalize this AltheaBook. Changes are saved to your device profile.", UDim2.fromOffset(20, 44), UDim2.new(1, -40, 0, 30), C.muted, 11, false)
local settingsList = makeSystemScroll(settingsBody, "SettingsList", UDim2.fromOffset(18, 84), UDim2.new(1, -36, 1, -128))
local settingsStatus = makeSystemLabel(settingsBody, "", UDim2.new(0, 20, 1, -36), UDim2.new(1, -40, 0, 24), C.cyan, 10, false)
local settingsRefreshers = {}

local function saveSetting(key, value)
    local response = requestServer("UpdateSettings", { key = key, value = value })
    if response.profile then currentProfile = response.profile end
    if response.ok then
        local settings = currentProfile.Settings or {}
        if key == "Wallpaper" then osManager:SetWallpaperStyle(settings.Wallpaper or value)
        elseif key == "DockAutoHide" then osManager:SetDockAutoHide(settings.DockAutoHide == true)
        elseif key == "ReducedMotion" then osManager:SetReducedMotion(settings.ReducedMotion == true)
        elseif key == "ShowBatteryPercent" then osManager:SetShowBatteryPercent(settings.ShowBatteryPercent == true)
        end
        settingsStatus.Text = response.message or "Setting saved."
        settingsStatus.TextColor3 = C.cyan
    else
        settingsStatus.Text = response.message or "Could not save setting."
        settingsStatus.TextColor3 = C.warning
    end
    for _, refresh in ipairs(settingsRefreshers) do refresh() end
end

local function addSettingRow(titleText, detail, key, values, formatValue)
    local row = make("Frame", settingsList, {
        Name = "Setting_" .. key, Size = UDim2.new(1, -2, 0, 67),
        BackgroundColor3 = C.panel2, BorderSizePixel = 0,
    })
    addCorner(row, 9)
    makeSystemLabel(row, titleText, UDim2.fromOffset(12, 5), UDim2.new(1, -170, 0, 24), C.text, 12, true)
    makeSystemLabel(row, detail, UDim2.fromOffset(12, 30), UDim2.new(1, -170, 0, 28), C.muted, 9, false)
    local action
    if key == "DeviceName" then
        action = make("TextBox", row, {
            Name = "Change", Position = UDim2.new(1, -145, 0.5, -15), Size = UDim2.fromOffset(132, 30),
            BackgroundColor3 = C.panel, BorderSizePixel = 0, Text = "AltheaBook", PlaceholderText = "Device name",
            TextColor3 = C.text, PlaceholderColor3 = C.muted, TextSize = 10, Font = Enum.Font.Gotham,
            ClearTextOnFocus = false, TextXAlignment = Enum.TextXAlignment.Center,
        })
        addCorner(action, 8)
        addStroke(action, C.line, 1, 0.4)
    else
        action = makeSystemButton(row, "Change", "Change", UDim2.new(1, -145, 0.5, -15), UDim2.fromOffset(132, 30), C.panel)
    end
    local function refresh()
        local settings = currentProfile and currentProfile.Settings or DEFAULT_SETTINGS
        local value = settings[key]
        if key == "DeviceName" then
            action.Text = tostring(value or "AltheaBook")
        elseif type(value) == "boolean" then
            action.Text = value and "ON" or "OFF"
            action.BackgroundColor3 = value and Color3.fromRGB(37, 77, 72) or C.panel
        else
            action.Text = formatValue and formatValue(value) or tostring(value)
        end
    end
    if key == "DeviceName" then
        action.FocusLost:Connect(function(enterPressed)
            if enterPressed then
                saveSetting(key, action.Text)
            else
                refresh()
            end
        end)
    else
        action.Activated:Connect(function()
            local settings = currentProfile and currentProfile.Settings or DEFAULT_SETTINGS
            local current = settings[key]
            if type(current) == "boolean" then
                saveSetting(key, not current)
            else
                local index = table.find(values, current) or 1
                index += 1
                if index > #values then index = 1 end
                saveSetting(key, values[index])
            end
        end)
    end
    table.insert(settingsRefreshers, refresh)
    refresh()
end

addSettingRow("Wallpaper", "Cycle through the AltheaBook desktop scenes.", "Wallpaper", {"Orbit", "Aurora", "Midnight", "Dawn"})
addSettingRow("Dock Auto-Hide", "Move the pointer to the bottom edge to reveal Dock.", "DockAutoHide")
addSettingRow("Reduced Motion", "Use shorter transitions for desktop controls.", "ReducedMotion")
addSettingRow("Show Battery Percentage", "Display the remaining battery in the menu bar.", "ShowBatteryPercent")
addSettingRow("AirDrop Receiving", "Choose whether nearby players may request files.", "AirDropMode", {"Everyone", "Off"})
addSettingRow("Device Name", "Name shown to nearby AirDrop devices.", "DeviceName")
registerSystemApp("Settings", "⚙", 160, UDim2.new(0.76, 0, 0.74, 0), settingsWindow, settingsHeader, settingsClose)

-- Battery app with a simulated battery that drains while OS is on and charges at charger parts.
local batteryWindow, batteryBody, batteryHeader, batteryClose = makeSystemAppWindow("Battery", "▰", 140, UDim2.new(0.58, 0, 0.64, 0))
makeSystemLabel(batteryBody, "Battery", UDim2.fromOffset(22, 18), UDim2.new(1, -44, 0, 26), C.text, 22, true)
local batteryPercentLabel = makeSystemLabel(batteryBody, "100%", UDim2.fromOffset(22, 58), UDim2.new(1, -44, 0, 72), C.text, 42, true)
local batteryTrack = make("Frame", batteryBody, {
    Name = "BatteryTrack", Position = UDim2.fromOffset(22, 140), Size = UDim2.new(1, -44, 0, 18),
    BackgroundColor3 = C.panel2, BorderSizePixel = 0,
})
addCorner(batteryTrack, 9)
local batteryFill = make("Frame", batteryTrack, {
    Name = "BatteryFill", Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.fromRGB(90, 198, 139), BorderSizePixel = 0,
})
addCorner(batteryFill, 9)
local batteryStateLabel = makeSystemLabel(batteryBody, "Battery status: Normal", UDim2.fromOffset(22, 170), UDim2.new(1, -44, 0, 24), C.muted, 11, false)
local batteryHint = makeSystemLabel(batteryBody, "Battery drains while AltheaBook is powered on. Walk near a charging station to recharge.", UDim2.fromOffset(22, 198), UDim2.new(1, -44, 0, 48), C.muted, 10, false)
local batteryRefreshButton = makeSystemButton(batteryBody, "RefreshBattery", "REFRESH", UDim2.fromOffset(22, 258), UDim2.new(0.46, -14, 0, 38), C.panel2)
local batteryCellButton = makeSystemButton(batteryBody, "UsePowerCell", "POWER CELL · 75 CR", UDim2.new(0.54, 0, 0, 258), UDim2.new(0.46, -14, 0, 38), Color3.fromRGB(37, 77, 72))
local batteryStatusMessage = makeSystemLabel(batteryBody, "", UDim2.fromOffset(22, 305), UDim2.new(1, -44, 0, 34), C.cyan, 10, false)

local function refreshBatteryUI(response)
    if response and response.profile then currentProfile = response.profile end
    local pct = math.clamp(tonumber(currentProfile and currentProfile.BatteryPercent) or 100, 0, 100)
    local charging = currentProfile and currentProfile.BatteryCharging == true
    batteryPercentLabel.Text = string.format("%.0f%%", pct)
    batteryFill.Size = UDim2.new(pct / 100, 0, 1, 0)
    batteryFill.BackgroundColor3 = pct <= 15 and C.warning or (charging and Color3.fromRGB(94, 208, 150) or Color3.fromRGB(90, 198, 139))
    batteryStateLabel.Text = charging and "Power adapter: Charging" or (pct <= 15 and "Battery is low" or "Power adapter: Not Connected")
    batteryHint.Text = "Walk within " .. tostring(15) .. " studs of a Workspace part named AltheaCharger to recharge automatically."
    osManager:SetBatteryPercent(pct, charging)
end

batteryRefreshButton.Activated:Connect(function()
    local response = requestServer("GetProfile", {})
    refreshBatteryUI(response)
    batteryStatusMessage.Text = response.message or "Battery status refreshed."
end)
batteryCellButton.Activated:Connect(function()
    local response = requestServer("UsePowerCell", {})
    refreshProfileAndStatus(response)
    refreshBatteryUI(response)
    batteryStatusMessage.Text = response.message or "Power Cell request finished."
    batteryStatusMessage.TextColor3 = response.ok and C.cyan or C.warning
end)
registerSystemApp("Battery", "▰", 140, UDim2.new(0.58, 0, 0.64, 0), batteryWindow, batteryHeader, batteryClose)

-- My Files: minimal local document editor backed by server-saved files.
local myFilesWindow, myFilesBody, myFilesHeader, myFilesClose = makeSystemAppWindow("My Files", "▤", 240, UDim2.new(0.76, 0, 0.75, 0))
makeSystemLabel(myFilesBody, "My Files", UDim2.fromOffset(16, 10), UDim2.new(1, -32, 0, 28), C.text, 22, true)
local fileNameBox = make("TextBox", myFilesBody, {
    Name = "FileName", Position = UDim2.fromOffset(16, 46), Size = UDim2.new(0.36, -20, 0, 34),
    BackgroundColor3 = C.panel, BorderSizePixel = 0, Text = "New Note.txt", PlaceholderText = "File name",
    TextColor3 = C.text, PlaceholderColor3 = C.muted, TextSize = 11, Font = Enum.Font.Gotham,
    ClearTextOnFocus = false, TextXAlignment = Enum.TextXAlignment.Left,
})
addCorner(fileNameBox, 7); make("UIPadding", fileNameBox, {PaddingLeft = UDim.new(0, 10), PaddingRight = UDim.new(0, 8)})
local fileContentBox = make("TextBox", myFilesBody, {
    Name = "FileContent", Position = UDim2.new(0.36, 0, 0, 46), Size = UDim2.new(0.64, -16, 0, 72),
    BackgroundColor3 = C.panel, BorderSizePixel = 0, Text = "", PlaceholderText = "Write a short research note…",
    TextColor3 = C.text, PlaceholderColor3 = C.muted, TextSize = 11, Font = Enum.Font.Gotham,
    ClearTextOnFocus = false, TextWrapped = true, TextYAlignment = Enum.TextYAlignment.Top,
    TextXAlignment = Enum.TextXAlignment.Left, MultiLine = true,
})
addCorner(fileContentBox, 7); make("UIPadding", fileContentBox, {PaddingLeft = UDim.new(0, 10), PaddingRight = UDim.new(0, 8), PaddingTop = UDim.new(0, 8)})
local saveFileButton = makeSystemButton(myFilesBody, "SaveFile", "SAVE FILE", UDim2.fromOffset(16, 126), UDim2.fromOffset(130, 32), Color3.fromRGB(37, 77, 72))
local refreshFilesButton = makeSystemButton(myFilesBody, "RefreshFiles", "REFRESH", UDim2.fromOffset(154, 126), UDim2.fromOffset(110, 32), C.panel2)
local filesStatus = makeSystemLabel(myFilesBody, "", UDim2.new(0, 276, 0, 126), UDim2.new(1, -292, 0, 32), C.cyan, 10, false)
local filesList = makeSystemScroll(myFilesBody, "FilesList", UDim2.fromOffset(16, 168), UDim2.new(1, -32, 1, -182))
local function loadFilesIntoList()
    local response = requestServer("GetFiles", {})
    if response.profile then currentProfile = response.profile end
    clearSystemScroll(filesList)
    local files = response.files or {}
    for index, file in ipairs(files) do
        local row = make("Frame", filesList, {
            Name = "File_" .. tostring(file.Id), Size = UDim2.new(1, -2, 0, 52),
            BackgroundColor3 = C.panel2, BorderSizePixel = 0, LayoutOrder = index,
        })
        addCorner(row, 8)
        makeSystemLabel(row, file.Name, UDim2.fromOffset(10, 3), UDim2.new(1, -125, 0, 23), C.text, 11, true)
        makeSystemLabel(row, tostring(#(file.Content or "")) .. " characters · " .. (file.Type or "text/plain"), UDim2.fromOffset(10, 27), UDim2.new(1, -125, 0, 18), C.muted, 9, false)
        local deleteButton = makeSystemButton(row, "Delete", "DELETE", UDim2.new(1, -94, 0.5, -13), UDim2.fromOffset(82, 26), Color3.fromRGB(73, 42, 48))
        deleteButton.Activated:Connect(function()
            local result = requestServer("DeleteFile", { fileId = file.Id })
            filesStatus.Text = result.message or "Delete request complete."
            filesStatus.TextColor3 = result.ok and C.cyan or C.warning
            if result.profile then currentProfile = result.profile end
            loadFilesIntoList()
        end)
    end
    if #files == 0 then
        makeSystemLabel(filesList, "No files yet. Create a note above.", UDim2.new(), UDim2.new(1, -4, 0, 40), C.muted, 11, false)
    end
end
saveFileButton.Activated:Connect(function()
    local response = requestServer("CreateFile", { name = fileNameBox.Text, content = fileContentBox.Text })
    if response.profile then currentProfile = response.profile end
    filesStatus.Text = response.message or "Save request finished."
    filesStatus.TextColor3 = response.ok and C.cyan or C.warning
    if response.ok then
        fileContentBox.Text = ""
        loadFilesIntoList()
    end
end)
refreshFilesButton.Activated:Connect(loadFilesIntoList)
registerSystemApp("My Files", "▤", 240, UDim2.new(0.76, 0, 0.75, 0), myFilesWindow, myFilesHeader, myFilesClose)

-- AirDrop: nearby device discovery, file selection, and accept/decline receive requests.
local airDropWindow, airDropBody, airDropHeader, airDropClose = makeSystemAppWindow("AirDrop", "↗", 180, UDim2.new(0.82, 0, 0.78, 0))
makeSystemLabel(airDropBody, "AirDrop", UDim2.fromOffset(16, 8), UDim2.new(0.55, -20, 0, 28), C.text, 22, true)
makeSystemLabel(airDropBody, "Share small text files with nearby AltheaBook devices. The receiver must accept.", UDim2.fromOffset(16, 36), UDim2.new(1, -32, 0, 26), C.muted, 10, false)
local airDropRefreshButton = makeSystemButton(airDropBody, "RefreshAirDrop", "FIND NEARBY", UDim2.new(1, -144, 0, 8), UDim2.fromOffset(128, 30), C.panel2)
local peerHeader = makeSystemLabel(airDropBody, "NEARBY DEVICES", UDim2.fromOffset(16, 70), UDim2.new(0.48, -22, 0, 20), C.cyan, 10, true)
local fileHeader = makeSystemLabel(airDropBody, "MY FILES", UDim2.new(0.52, 4, 0, 70), UDim2.new(0.48, -22, 0, 20), C.cyan, 10, true)
local peersList = makeSystemScroll(airDropBody, "NearbyDevices", UDim2.fromOffset(16, 94), UDim2.new(0.48, -22, 1, -220))
local shareFilesList = makeSystemScroll(airDropBody, "ShareFiles", UDim2.new(0.52, 4, 0, 94), UDim2.new(0.48, -22, 1, -220))
local selectedPeerLabel = makeSystemLabel(airDropBody, "Selected device: none", UDim2.fromOffset(16, 0), UDim2.new(0.52, -24, 0, 25), C.muted, 10, false)
selectedPeerLabel.Position = UDim2.new(0, 16, 1, -116)
local selectedFileLabel = makeSystemLabel(airDropBody, "Selected file: none", UDim2.new(0.52, 4, 1, -116), UDim2.new(0.48, -22, 0, 25), C.muted, 10, false)
local airDropSendButton = makeSystemButton(airDropBody, "SendAirDrop", "SEND SELECTED FILE", UDim2.new(1, -188, 1, -84), UDim2.fromOffset(172, 34), Color3.fromRGB(37, 77, 72))
local airDropStatus = makeSystemLabel(airDropBody, "Find a nearby device to start sharing.", UDim2.fromOffset(16, 0), UDim2.new(1, -220, 0, 34), C.cyan, 10, false)
airDropStatus.Position = UDim2.new(0, 16, 1, -80)
local incomingHeader = makeSystemLabel(airDropBody, "INCOMING REQUESTS", UDim2.fromOffset(16, 0), UDim2.new(0.48, -22, 0, 18), C.gold, 9, true)
incomingHeader.Position = UDim2.new(0, 16, 1, -44)
local incomingText = makeSystemLabel(airDropBody, "No pending requests.", UDim2.new(0.52, 4, 1, -44), UDim2.new(0.48, -22, 0, 20), C.muted, 9, false)
local airDropPeers, airDropFiles, airDropRequests = {}, {}, {}
local selectedPeerId, selectedAirDropFileId
local lastAirDropAutoRefresh = 0

local function refreshAirDropLists()
    local peersResponse = requestServer("DiscoverPeers", {})
    local filesResponse = requestServer("GetFiles", {})
    local requestsResponse = requestServer("GetPendingAirDrops", {})
    if filesResponse.profile then currentProfile = filesResponse.profile end
    airDropPeers = peersResponse.peers or {}
    airDropFiles = filesResponse.files or {}
    airDropRequests = requestsResponse.requests or {}
    clearSystemScroll(peersList)
    clearSystemScroll(shareFilesList)
    for index, peer in ipairs(airDropPeers) do
        local label = string.format("%s\n%s · %d studs", peer.DeviceName or "AltheaBook", peer.Name or peer.Username, peer.Distance or 0)
        local button = makeSystemButton(peersList, "Peer_" .. tostring(peer.UserId), label, UDim2.new(), UDim2.new(1, -2, 0, 56), selectedPeerId == peer.UserId and Color3.fromRGB(37, 77, 72) or C.panel2)
        button.LayoutOrder = index
        button.TextWrapped = true
        button.TextSize = 10
        button.Activated:Connect(function()
            selectedPeerId = peer.UserId
            selectedPeerLabel.Text = "Selected device: " .. tostring(peer.DeviceName or peer.Name)
            refreshAirDropLists()
        end)
    end
    if #airDropPeers == 0 then
        makeSystemLabel(peersList, "No devices in range. Ask another player to equip AltheaBook and move within 80 studs.", UDim2.new(), UDim2.new(1, -4, 0, 68), C.muted, 10, false)
    end
    for index, file in ipairs(airDropFiles) do
        local button = makeSystemButton(shareFilesList, "File_" .. tostring(file.Id), file.Name .. "\n" .. tostring(#(file.Content or "")) .. " characters", UDim2.new(), UDim2.new(1, -2, 0, 52), selectedAirDropFileId == file.Id and Color3.fromRGB(37, 77, 72) or C.panel2)
        button.LayoutOrder = index
        button.TextWrapped = true
        button.TextSize = 10
        button.Activated:Connect(function()
            selectedAirDropFileId = file.Id
            selectedFileLabel.Text = "Selected file: " .. file.Name
            refreshAirDropLists()
        end)
    end
    if #airDropFiles == 0 then makeSystemLabel(shareFilesList, "Create a file in My Files first.", UDim2.new(), UDim2.new(1, -4, 0, 40), C.muted, 10, false) end
    local pendingText = {}
    for _, item in ipairs(airDropRequests) do
        table.insert(pendingText, item.SenderName .. ": " .. item.FileName)
    end
    incomingText.Text = #pendingText > 0 and table.concat(pendingText, "  |  ") or "No pending requests."
    -- Accept/decline buttons are built in the incoming strip for the first pending request.
    for _, child in ipairs(airDropBody:GetChildren()) do
        if child.Name == "IncomingAccept" or child.Name == "IncomingDecline" then child:Destroy() end
    end
    if #airDropRequests > 0 then
        local item = airDropRequests[1]
        incomingText.Text = item.SenderName .. " wants to send " .. item.FileName
        local accept = makeSystemButton(airDropBody, "IncomingAccept", "ACCEPT", UDim2.new(0.52, 4, 1, -22), UDim2.new(0.22, -5, 0, 20), Color3.fromRGB(37, 77, 72))
        local decline = makeSystemButton(airDropBody, "IncomingDecline", "DECLINE", UDim2.new(0.74, 4, 1, -22), UDim2.new(0.22, -5, 0, 20), Color3.fromRGB(73, 42, 48))
        accept.TextSize = 9; decline.TextSize = 9
        accept.Activated:Connect(function()
            local result = requestServer("RespondAirDrop", { requestId = item.Id, accept = true })
            airDropStatus.Text = result.message or "AirDrop request handled."
            airDropStatus.TextColor3 = result.ok and C.cyan or C.warning
            if result.profile then currentProfile = result.profile end
            if myFilesWindow and myFilesWindow.Visible then loadFilesIntoList() end
            refreshAirDropLists()
        end)
        decline.Activated:Connect(function()
            local result = requestServer("RespondAirDrop", { requestId = item.Id, accept = false })
            airDropStatus.Text = result.message or "AirDrop request declined."
            airDropStatus.TextColor3 = result.ok and C.cyan or C.warning
            refreshAirDropLists()
        end)
    end
end

airDropRefreshButton.Activated:Connect(refreshAirDropLists)
airDropSendButton.Activated:Connect(function()
    if not selectedPeerId then airDropStatus.Text = "Select a nearby device first."; airDropStatus.TextColor3 = C.warning; return end
    if not selectedAirDropFileId then airDropStatus.Text = "Select a file to share first."; airDropStatus.TextColor3 = C.warning; return end
    local response = requestServer("SendAirDrop", { targetUserId = selectedPeerId, fileId = selectedAirDropFileId })
    airDropStatus.Text = response.message or "AirDrop request sent."
    airDropStatus.TextColor3 = response.ok and C.cyan or C.warning
end)
registerSystemApp("AirDrop", "↗", 180, UDim2.new(0.82, 0, 0.78, 0), airDropWindow, airDropHeader, airDropClose)

-- Register system app windows with the same Dock/Window manager.
-- The server profile still controls availability and cannot be overridden by the client.

registerPlaceholder("Space Hub", "🚀", "Your mission starts here", "A central dashboard for missions, vehicle systems, discoveries, and your progress through the Rocket Science world.", C.cyan, 320)
registerPlaceholder("Research Lab", "⚗", "Research & experiments", "A future workspace for experiments, research trees, material properties, and science records. The app shell is ready for the next development phase.", C.gold, 900)
registerPlaceholder("Resource Database", "▤", "Resource inventory", "A future database for every element, mineral, compound, stored quantity, and resource ID shared with crafting and exchange systems.", C.cyan, 520)
registerPlaceholder("Blueprints", "▧", "Engineering blueprints", "A future place to save, open, compare, and version rocket, engine, vehicle, and spacecraft blueprints.", C.gold, 620)
-- Full implementations replace the earlier simple placeholders.
-- My Files, Settings, Battery, and AirDrop are system apps and are preinstalled for every player.
registerPlaceholder("Spectrum Lab", "🌈", "Light & spectral analysis", "A future workspace for emission spectra, absorption lines, wavelength and intensity analysis.", C.cyan, 1150)
registerPlaceholder("Material Workbench", "🧪", "Materials & manufacturing", "A future workspace for materials, compositions, alloys, and manufacturing recipes.", C.gold, 720)


-- ============================================================
-- AltheaOS Extensibility Pack v2: App Requests, Supply, Map, AltheaTag
-- These apps use the same Window Manager and server RemoteFunction as existing apps.

local APP_REQUEST_CATEGORIES = {"Science", "Engineering", "Navigation", "Commerce", "Productivity", "Other"}
local appRequestCategoryIndex = 1

local function makeGlassInput(parent, name, placeholder, position, size, multiline)
    local input = make("TextBox", parent, {
        Name = name,
        Position = position,
        Size = size,
        BackgroundColor3 = C.panel2,
        BackgroundTransparency = 0.16,
        BorderSizePixel = 0,
        Text = "",
        PlaceholderText = placeholder,
        PlaceholderColor3 = C.muted,
        TextColor3 = C.text,
        TextSize = 11,
        Font = Enum.Font.Gotham,
        ClearTextOnFocus = false,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = multiline and Enum.TextYAlignment.Top or Enum.TextYAlignment.Center,
        TextWrapped = multiline == true,
        MultiLine = multiline == true,
    })
    addCorner(input, 9)
    addStroke(input, C.line, 1, 0.5)
    make("UIPadding", input, {PaddingLeft=UDim.new(0,10), PaddingRight=UDim.new(0,10), PaddingTop=UDim.new(0,7), PaddingBottom=UDim.new(0,7)})
    return input
end

local function makeFeatureRow(parent, name, description, height, order)
    local row = make("Frame", parent, {
        Name = "Row_" .. tostring(order or name):gsub("[^%w]", ""),
        Size = UDim2.new(1, -4, 0, height or 68),
        BackgroundColor3 = C.panel2,
        BackgroundTransparency = 0.16,
        BorderSizePixel = 0,
        LayoutOrder = order or 1,
    })
    addCorner(row, 10)
    addStroke(row, C.line, 1, 0.64)
    make("TextLabel", row, {
        Name = "Title", Position = UDim2.fromOffset(12, 7), Size = UDim2.new(1, -24, 0, 22),
        BackgroundTransparency = 1, Text = name, TextColor3 = C.text, TextSize = 12,
        Font = Enum.Font.GothamBold, TextXAlignment = Enum.TextXAlignment.Left,
    })
    make("TextLabel", row, {
        Name = "Description", Position = UDim2.fromOffset(12, 29), Size = UDim2.new(1, -24, 1, -34),
        BackgroundTransparency = 1, Text = description or "", TextColor3 = C.muted, TextSize = 10,
        Font = Enum.Font.Gotham, TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top,
    })
    return row
end

-- App Requests: players request features; only the game owner/admin can moderate statuses.
local appRequestsWindow, appRequestsBody, appRequestsHeader, appRequestsClose = makeSystemAppWindow("App Requests", "✉", 220, UDim2.new(0.78, 0, 0.82, 0))
makeSystemLabel(appRequestsBody, "Request an App or Feature", UDim2.fromOffset(18, 10), UDim2.new(1, -36, 0, 25), C.text, 19, true)
makeSystemLabel(appRequestsBody, "Suggestions go to the AltheaOS development queue. Requests never execute submitted code.", UDim2.fromOffset(18, 36), UDim2.new(1, -36, 0, 31), C.muted, 10, false)
local requestNameInput = makeGlassInput(appRequestsBody, "RequestName", "App or feature name", UDim2.fromOffset(18, 73), UDim2.new(0.47, -9, 0, 35), false)
local requestCategoryButton = makeSystemButton(appRequestsBody, "RequestCategory", APP_REQUEST_CATEGORIES[1], UDim2.new(0.53, 0, 0, 73), UDim2.new(0.47, -18, 0, 35), C.panel2)
local requestDescriptionInput = makeGlassInput(appRequestsBody, "RequestDescription", "What should this app or feature do?", UDim2.fromOffset(18, 116), UDim2.new(1, -36, 0, 60), true)
local requestUseInput = makeGlassInput(appRequestsBody, "RequestUse", "How would it help in Rocket Science?", UDim2.fromOffset(18, 184), UDim2.new(1, -36, 0, 44), true)
local requestSubmitButton = makeSystemButton(appRequestsBody, "SubmitRequest", "SUBMIT REQUEST", UDim2.fromOffset(18, 238), UDim2.fromOffset(154, 34), C.cyan)
local requestStatusLabel = makeSystemLabel(appRequestsBody, "Requests are reviewed by the developers.", UDim2.new(0, 184, 0, 238), UDim2.new(1, -202, 0, 34), C.muted, 10, false)
local requestList = makeSystemScroll(appRequestsBody, "MyRequests", UDim2.fromOffset(18, 282), UDim2.new(1, -36, 1, -294))

local function renderMyAppRequests()
    clearSystemScroll(requestList)
    local response = requestServer("GetMyAppRequests", {})
    if not response.ok then
        requestStatusLabel.Text = response.message or "Could not load requests."
        return
    end
    local requests = response.requests or {}
    for index, item in ipairs(requests) do
        local row = makeFeatureRow(requestList, tostring(item.Name or "App Request") .. "  ·  " .. tostring(item.Status or "Submitted"),
            tostring(item.Category or "Other") .. "  |  " .. tostring(item.Description or "") .. "\n" .. tostring(item.ReviewMessage or "Awaiting review"), 66, index)
    end
    if #requests == 0 then
        makeFeatureRow(requestList, "No requests yet", "Use the form above to suggest a future application.", 58, 1)
    end
end

requestCategoryButton.Activated:Connect(function()
    appRequestCategoryIndex += 1
    if appRequestCategoryIndex > #APP_REQUEST_CATEGORIES then appRequestCategoryIndex = 1 end
    requestCategoryButton.Text = APP_REQUEST_CATEGORIES[appRequestCategoryIndex]
end)
requestSubmitButton.Activated:Connect(function()
    requestSubmitButton.Active = false
    local response = requestServer("CreateAppRequest", {
        name = requestNameInput.Text,
        category = APP_REQUEST_CATEGORIES[appRequestCategoryIndex],
        description = requestDescriptionInput.Text,
        intendedUse = requestUseInput.Text,
    })
    requestStatusLabel.Text = response.message or (response.ok and "Request submitted." or "Request failed.")
    requestStatusLabel.TextColor3 = response.ok and C.cyan or C.warning
    if response.ok then
        requestNameInput.Text = ""
        requestDescriptionInput.Text = ""
        requestUseInput.Text = ""
        renderMyAppRequests()
    end
    task.delay(0.4, function() if requestSubmitButton.Parent then requestSubmitButton.Active = true end end)
end)
registerSystemApp("App Requests", "✉", 220, UDim2.new(0.78, 0, 0.82, 0), appRequestsWindow, appRequestsHeader, appRequestsClose)

-- Althea Supply: in-game catalogue, cart, checkout, and order history.
local supplyWindow, supplyBody, supplyHeader, supplyClose = makeSystemAppWindow("Althea Supply", "🛒", 380, UDim2.new(0.84, 0, 0.82, 0))
makeSystemLabel(supplyBody, "Althea Supply", UDim2.fromOffset(18, 10), UDim2.new(1, -148, 0, 28), C.text, 21, true)
local supplyOrdersButton = makeSystemButton(supplyBody, "SupplyOrders", "ORDERS", UDim2.new(1, -112, 0, 8), UDim2.fromOffset(94, 30), C.panel2)
local supplyProfileLabel = makeSystemLabel(supplyBody, "Credits: loading · Storage: loading", UDim2.fromOffset(18, 39), UDim2.new(1, -36, 0, 23), C.muted, 10, false)
local supplyList = makeSystemScroll(supplyBody, "SupplyProducts", UDim2.fromOffset(18, 68), UDim2.new(1, -36, 1, -156))
local supplyCartLabel = makeSystemLabel(supplyBody, "Cart: empty", UDim2.new(0, 18, 1, -78), UDim2.new(1, -220, 0, 28), C.cyan, 11, true)
local supplyCheckoutButton = makeSystemButton(supplyBody, "Checkout", "CHECKOUT", UDim2.new(1, -164, 1, -78), UDim2.fromOffset(146, 34), C.cyan)
local supplyStatusLabel = makeSystemLabel(supplyBody, "Items purchased are delivered to your AltheaBook inventory.", UDim2.new(0, 18, 1, -43), UDim2.new(1, -36, 0, 30), C.muted, 10, false)
local supplyProducts = {}
local supplyCart = {}
local supplyMode = "Products"

local function refreshSupplySummary()
    local count, total = 0, 0
    for id, qty in pairs(supplyCart) do
        count += qty
        for _, product in ipairs(supplyProducts) do
            if product.Id == id then total += product.Price * qty break end
        end
    end
    supplyCartLabel.Text = string.format("Cart: %d item(s) · %d Credits", count, total)
    supplyProfileLabel.Text = string.format("Credits: %d  ·  Storage: %s / %s",
        tonumber(currentProfile.Credits) or 0,
        formatSize(tonumber(currentProfile.StorageUsedMB) or 0),
        formatSize(tonumber(currentProfile.StorageCapacityMB) or 32768))
end

local function renderSupplyOrders()
    supplyMode = "Orders"
    supplyOrdersButton.Text = "PRODUCTS"
    supplyCheckoutButton.Visible = false
    supplyCartLabel.Visible = false
    supplyProfileLabel.Visible = true
    clearSystemScroll(supplyList)
    local response = requestServer("GetOrders", {})
    if not response.ok then
        supplyStatusLabel.Text = response.message or "Order history unavailable."
        return
    end
    local orders = response.orders or {}
    for index, order in ipairs(orders) do
        local itemSummary = {}
        for _, item in ipairs(order.Items or {}) do
            table.insert(itemSummary, tostring(item.Name or item.ProductId) .. " × " .. tostring(item.Quantity or 0))
        end
        makeFeatureRow(supplyList,
            string.format("Order %s · %s · %d CR", string.sub(tostring(order.OrderId or ""), 1, 8), tostring(order.Status or "Unknown"), tonumber(order.Total) or 0),
            table.concat(itemSummary, ", ") .. "\nDelivered to: " .. tostring(order.Delivery or "Player Inventory"), 72, index)
    end
    if #orders == 0 then makeFeatureRow(supplyList, "No orders yet", "Completed supply purchases will appear here.", 60, 1) end
    supplyStatusLabel.Text = "Showing recent supply orders."
end

local function renderSupplyProducts()
    supplyMode = "Products"
    supplyOrdersButton.Text = "ORDERS"
    supplyCheckoutButton.Visible = true
    supplyCartLabel.Visible = true
    clearSystemScroll(supplyList)
    local response = requestServer("GetSupplyCatalog", {})
    if not response.ok then
        supplyStatusLabel.Text = response.message or "Supply catalogue unavailable."
        return
    end
    supplyProducts = response.products or {}
    for index, product in ipairs(supplyProducts) do
        local row = makeFeatureRow(supplyList, product.Name .. "  ·  " .. tostring(product.Price) .. " CR / " .. tostring(product.Unit or "unit"),
            tostring(product.Category) .. " · Stock in this server: " .. tostring(product.Stock) .. "\n" .. tostring(product.Description), 76, index)
        local qtyLabel = makeSystemLabel(row, tostring(supplyCart[product.Id] or 0), UDim2.new(1, -214, 0, 45), UDim2.fromOffset(30, 24), C.cyan, 12, true)
        qtyLabel.TextXAlignment = Enum.TextXAlignment.Center
        local minus = makeSystemButton(row, "Minus", "−", UDim2.new(1, -180, 0, 41), UDim2.fromOffset(27, 28), C.panel)
        local plus = makeSystemButton(row, "Plus", "+", UDim2.new(1, -147, 0, 41), UDim2.fromOffset(27, 28), C.panel)
        local add = makeSystemButton(row, "AddToCart", "ADD", UDim2.new(1, -111, 0, 41), UDim2.fromOffset(94, 28), C.cyan)
        minus.Activated:Connect(function()
            supplyCart[product.Id] = math.max(0, (supplyCart[product.Id] or 0) - 1)
            if supplyCart[product.Id] == 0 then supplyCart[product.Id] = nil end
            qtyLabel.Text = tostring(supplyCart[product.Id] or 0)
            refreshSupplySummary()
        end)
        plus.Activated:Connect(function()
            supplyCart[product.Id] = math.min(99, (supplyCart[product.Id] or 0) + 1)
            qtyLabel.Text = tostring(supplyCart[product.Id] or 0)
            refreshSupplySummary()
        end)
        add.Activated:Connect(function()
            if (supplyCart[product.Id] or 0) <= 0 then supplyCart[product.Id] = 1 end
            qtyLabel.Text = tostring(supplyCart[product.Id] or 0)
            refreshSupplySummary()
            supplyStatusLabel.Text = product.Name .. " added to cart."
        end)
    end
    refreshSupplySummary()
end

supplyOrdersButton.Activated:Connect(function()
    if supplyMode == "Orders" then renderSupplyProducts() else renderSupplyOrders() end
end)

supplyCheckoutButton.Activated:Connect(function()
    local items = {}
    for id, quantity in pairs(supplyCart) do
        if quantity > 0 then table.insert(items, { productId = id, quantity = quantity }) end
    end
    if #items == 0 then supplyStatusLabel.Text = "Add at least one product to the cart first."; return end
    supplyCheckoutButton.Active = false
    local response = requestServer("CheckoutSupply", { items = items, requestId = HttpService:GenerateGUID(false) })
    if response.profile then currentProfile = response.profile end
    supplyStatusLabel.Text = response.message or "Checkout completed."
    supplyStatusLabel.TextColor3 = response.ok and C.cyan or C.warning
    if response.ok then
        table.clear(supplyCart)
        renderSupplyProducts()
    else
        refreshSupplySummary()
    end
    task.delay(0.5, function() if supplyCheckoutButton.Parent then supplyCheckoutButton.Active = true end end)
end)
registerSystemApp("Althea Supply", "🛒", 380, UDim2.new(0.84, 0, 0.82, 0), supplyWindow, supplyHeader, supplyClose)

-- AltheaMap: 2D X/Z projection for public map markers and the player's own tagged rockets.
local mapWindow, mapBody, mapHeader, mapClose = makeSystemAppWindow("AltheaMap", "🗺", 460, UDim2.new(0.86, 0, 0.82, 0))
makeSystemLabel(mapBody, "AltheaMap", UDim2.fromOffset(18, 10), UDim2.new(1, -150, 0, 28), C.text, 21, true)
local mapRefreshButton = makeSystemButton(mapBody, "RefreshMap", "REFRESH", UDim2.new(1, -116, 0, 9), UDim2.fromOffset(98, 30), C.cyan)
local mapCanvas = make("Frame", mapBody, {
    Name = "MapCanvas", Position = UDim2.fromOffset(18, 49), Size = UDim2.new(0.64, -24, 1, -66),
    BackgroundColor3 = Color3.fromRGB(10, 25, 40), BackgroundTransparency = 0.1, BorderSizePixel = 0, ClipsDescendants = true,
})
addCorner(mapCanvas, 12); addStroke(mapCanvas, C.line, 1, 0.35)
make("UIGradient", mapCanvas, {Rotation=90, Color=ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(20, 54, 78)),ColorSequenceKeypoint.new(1, Color3.fromRGB(7, 17, 30))})})
local mapInfoPanel = make("Frame", mapBody, {
    Name = "MapInfoPanel", Position = UDim2.new(0.64, 2, 0, 49), Size = UDim2.new(0.36, -20, 1, -66),
    BackgroundColor3 = C.panel2, BackgroundTransparency = 0.20, BorderSizePixel = 0,
})
addCorner(mapInfoPanel, 12); addStroke(mapInfoPanel, C.line, 1, 0.55)
local mapSelectedLabel = makeSystemLabel(mapInfoPanel, "Select a map marker", UDim2.fromOffset(12, 12), UDim2.new(1, -24, 0, 44), C.text, 14, true)
local mapDetailLabel = makeSystemLabel(mapInfoPanel, "Press REFRESH to load visible map markers and tracked rockets.", UDim2.fromOffset(12, 62), UDim2.new(1, -24, 0, 160), C.muted, 10, false)
local mapStatusLabel = makeSystemLabel(mapInfoPanel, "Map coordinates use world X/Z.", UDim2.new(0, 12, 1, -42), UDim2.new(1, -24, 0, 30), C.cyan, 10, false)
local currentMapData = nil

local function renderMap()
    for _, child in ipairs(mapCanvas:GetChildren()) do
        if not child:IsA("UICorner") and not child:IsA("UIStroke") and not child:IsA("UIGradient") then child:Destroy() end
    end
    local response = requestServer("GetMapData", {})
    if not response.ok then mapStatusLabel.Text = response.message or "Map unavailable."; return end
    currentMapData = response
    local markers = response.markers or {}
    local points = {}
    for _, marker in ipairs(markers) do
        local p = marker.Position or {}
        table.insert(points, {marker=marker, x=tonumber(p.X) or 0, z=tonumber(p.Z) or 0})
    end
    if #points == 0 then
        mapSelectedLabel.Text = "No map markers"
        mapDetailLabel.Text = "Tag a BasePart with AltheaMapMarker and set MapLabel / MapCategory attributes, or install AltheaTag on one of your rockets."
        mapStatusLabel.Text = "0 markers"
        return
    end
    local minX,maxX,minZ,maxZ = math.huge,-math.huge,math.huge,-math.huge
    for _, p in ipairs(points) do minX=math.min(minX,p.x); maxX=math.max(maxX,p.x); minZ=math.min(minZ,p.z); maxZ=math.max(maxZ,p.z) end
    if maxX-minX < 1 then minX -= 50; maxX += 50 end
    if maxZ-minZ < 1 then minZ -= 50; maxZ += 50 end
    local width,height = mapCanvas.AbsoluteSize.X,mapCanvas.AbsoluteSize.Y
    for i, point in ipairs(points) do
        local nx = 0.08 + ((point.x-minX)/(maxX-minX))*0.84
        local nz = 0.08 + ((point.z-minZ)/(maxZ-minZ))*0.84
        local color = point.marker.Kind == "Player" and C.cyan or (point.marker.Kind == "Rocket" and C.gold or Color3.fromRGB(117, 212, 169))
        local dot = make("TextButton", mapCanvas, {
            Name = "Marker_" .. tostring(i), AnchorPoint = Vector2.new(0.5,0.5), Position = UDim2.fromScale(nx, 1-nz),
            Size = UDim2.fromOffset(point.marker.Kind == "Rocket" and 20 or 15, point.marker.Kind == "Rocket" and 20 or 15),
            BackgroundColor3 = color, BorderSizePixel = 0, Text = point.marker.Kind == "Rocket" and "R" or (point.marker.Kind == "Player" and "●" or "•"),
            TextColor3 = Color3.fromRGB(8,18,28), TextSize = 10, Font = Enum.Font.GothamBold, AutoButtonColor = true, ZIndex = 4,
        })
        addCorner(dot, 20); addStroke(dot, Color3.fromRGB(235,245,255), 1, 0.2)
        dot.Activated:Connect(function()
            local m = point.marker
            mapSelectedLabel.Text = tostring(m.Name or "Map Marker")
            local detail = string.format("Type: %s\nX: %.1f\nY: %.1f\nZ: %.1f\nStatus: %s",
                tostring(m.Kind or "Location"), point.x, tonumber((m.Position or {}).Y) or 0, point.z,
                tostring(m.Status or "Visible"))
            local telemetryLines = {}
            if m.Altitude ~= nil then table.insert(telemetryLines, string.format("Altitude: %.1f", m.Altitude)) end
            if m.FuelPercent ~= nil then table.insert(telemetryLines, string.format("Fuel: %.0f%%", m.FuelPercent)) end
            if m.FlightStage ~= nil then table.insert(telemetryLines, "Stage: " .. tostring(m.FlightStage)) end
            if m.MissionStatus ~= nil then table.insert(telemetryLines, "Mission: " .. tostring(m.MissionStatus)) end
            if m.HeadingDegrees ~= nil then table.insert(telemetryLines, string.format("Heading: %.1f°", m.HeadingDegrees)) end
            if type(m.Velocity) == "table" then table.insert(telemetryLines, string.format("Velocity: %.1f studs/s", tonumber(m.Velocity.Speed) or 0)) end
            if #telemetryLines > 0 then detail ..= "\n" .. table.concat(telemetryLines, "\n") end
            if m.Description then detail ..= "\n\n" .. tostring(m.Description) end
            mapDetailLabel.Text = detail
            mapStatusLabel.Text = m.Distance and ("Distance: " .. tostring(math.floor(m.Distance)) .. " studs") or "Selected marker"
        end)
    end
    mapStatusLabel.Text = tostring(#points) .. " marker(s) · Refresh to update"
end
mapRefreshButton.Activated:Connect(renderMap)
registerSystemApp("AltheaMap", "🗺", 460, UDim2.new(0.86, 0, 0.82, 0), mapWindow, mapHeader, mapClose)

-- AltheaTag: install/remove a purchased tracking beacon on an owned, tagged rocket.
local tagWindow, tagBody, tagHeader, tagClose = makeSystemAppWindow("AltheaTag", "📡", 260, UDim2.new(0.76, 0, 0.76, 0))
makeSystemLabel(tagBody, "Rocket Tracking Beacons", UDim2.fromOffset(18, 10), UDim2.new(1, -36, 0, 27), C.text, 19, true)
makeSystemLabel(tagBody, "Buy AltheaTag devices in Althea Supply, then install them on an owned rocket.", UDim2.fromOffset(18, 39), UDim2.new(1, -36, 0, 35), C.muted, 10, false)
local tagRefreshButton = makeSystemButton(tagBody, "RefreshTargets", "REFRESH TARGETS", UDim2.fromOffset(18, 80), UDim2.fromOffset(148, 32), C.cyan)
local tagInventoryLabel = makeSystemLabel(tagBody, "AltheaTag devices: 0", UDim2.new(0, 180, 0, 80), UDim2.new(1, -198, 0, 32), C.muted, 10, true)
local tagList = makeSystemScroll(tagBody, "TrackableRockets", UDim2.fromOffset(18, 122), UDim2.new(1, -36, 1, -134))

local function renderTrackableRockets()
    clearSystemScroll(tagList)
    local response = requestServer("GetTrackableRockets", {})
    local inventory = currentProfile and currentProfile.Inventory or {}
    tagInventoryLabel.Text = "AltheaTag devices: " .. tostring(inventory.AltheaTagDevice or 0)
    if not response.ok then makeFeatureRow(tagList, "Cannot load rockets", response.message or "Request failed.", 60, 1); return end
    local rockets = response.rockets or {}
    for index, rocket in ipairs(rockets) do
        local row = makeFeatureRow(tagList, tostring(rocket.Name) .. "  ·  " .. tostring(rocket.RocketId),
            "Position: " .. tostring(rocket.Position and math.floor(rocket.Position.X or 0) or 0) .. ", " .. tostring(rocket.Position and math.floor(rocket.Position.Y or 0) or 0) .. ", " .. tostring(rocket.Position and math.floor(rocket.Position.Z or 0) or 0) .. "\n" .. (rocket.Tracked and "Tracking active" or "No tracker installed"), 72, index)
        local action = makeSystemButton(row, "TrackerAction", rocket.Tracked and "REMOVE" or "INSTALL", UDim2.new(1, -112, 0, 22), UDim2.fromOffset(96, 30), rocket.Tracked and C.warning or C.cyan)
        action.Activated:Connect(function()
            local result
            if rocket.Tracked then
                result = requestServer("RemoveAltheaTag", { rocketId = rocket.RocketId })
            else
                result = requestServer("InstallAltheaTag", { rocketId = rocket.RocketId })
            end
            if result.profile then currentProfile = result.profile end
            tagInventoryLabel.Text = result.message or "Tracker updated."
            tagInventoryLabel.TextColor3 = result.ok and C.cyan or C.warning
            renderTrackableRockets()
        end)
    end
    if #rockets == 0 then makeFeatureRow(tagList, "No eligible rockets found", "Tag your rocket Model with CollectionService tag AltheaRocket and set RocketId and OwnerUserId attributes.", 72, 1) end
end
tagRefreshButton.Activated:Connect(renderTrackableRockets)
registerSystemApp("AltheaTag", "📡", 260, UDim2.new(0.76, 0, 0.76, 0), tagWindow, tagHeader, tagClose)

-- V4: Mission & Jobs. Contracts consume items from the player's verified inventory;
-- payouts and completion checks are server-authoritative.
local jobsWindow, jobsBody, jobsHeader, jobsClose = makeSystemAppWindow("Mission & Jobs", "📋", 260, UDim2.new(0.82, 0, 0.80, 0))
makeSystemLabel(jobsBody, "Mission & Job Contracts", UDim2.fromOffset(18, 10), UDim2.new(1, -36, 0, 28), C.text, 21, true)
makeSystemLabel(jobsBody, "Accept supply contracts. Complete them with resources earned through mining and production systems.", UDim2.fromOffset(18, 40), UDim2.new(1, -36, 0, 30), C.muted, 10, false)
local jobsRefreshButton = makeSystemButton(jobsBody, "RefreshJobs", "REFRESH", UDim2.new(1, -116, 0, 8), UDim2.fromOffset(98, 30), C.cyan)
local jobsStatus = makeSystemLabel(jobsBody, "Contract board ready.", UDim2.fromOffset(18, 76), UDim2.new(1, -36, 0, 26), C.cyan, 10, false)
local jobsList = makeSystemScroll(jobsBody, "JobsList", UDim2.fromOffset(18, 108), UDim2.new(1, -36, 1, -120))

local function renderJobs()
    clearSystemScroll(jobsList)
    local response = requestServer("GetJobs", {})
    if not response.ok then
        jobsStatus.Text = response.message or "Could not load contracts."
        makeFeatureRow(jobsList, "Contracts unavailable", jobsStatus.Text, 60, 1)
        return
    end
    if response.profile then currentProfile = response.profile end
    local jobs = response.jobs or {}
    for index, job in ipairs(jobs) do
        local requirementCount = (currentProfile.Inventory and currentProfile.Inventory[job.RequirementId]) or 0
        local titleText = string.format("%s  ·  +%d Credits", job.Name, job.Reward)
        local descText = string.format("%s\nDeliver %d × %s  ·  You have %d", job.Description, job.Quantity, job.RequirementId, requirementCount)
        local row = makeFeatureRow(jobsList, titleText, descText, 82, index)
        local active = job.Active == true
        local actionText = active and (requirementCount >= job.Quantity and "COMPLETE" or "ACCEPTED") or "ACCEPT"
        local actionButton = makeSystemButton(row, "JobAction", actionText, UDim2.new(1, -118, 0, 25), UDim2.fromOffset(100, 30), active and (requirementCount >= job.Quantity and C.cyan or C.panel2) or C.panel2)
        actionButton.Activated:Connect(function()
            if active then
                if requirementCount < job.Quantity then
                    jobsStatus.Text = "You need more resources before completing this contract."
                    return
                end
                local result = requestServer("CompleteJob", { jobId=job.Id })
                if result.profile then currentProfile = result.profile end
                jobsStatus.Text = result.message or "Contract completion requested."
            else
                local result = requestServer("AcceptJob", { jobId=job.Id })
                if result.profile then currentProfile = result.profile end
                jobsStatus.Text = result.message or "Contract request submitted."
            end
            renderJobs()
        end)
    end
    jobsStatus.Text = string.format("%d contracts available · Credits are paid by the server after verified delivery.", #jobs)
end
jobsRefreshButton.Activated:Connect(renderJobs)
registerSystemApp("Mission & Jobs", "📋", 260, UDim2.new(0.82, 0, 0.80, 0), jobsWindow, jobsHeader, jobsClose)

-- V4: Global Exchange. Listings are shared through the server's persistent global order book.
local marketWindow, marketBody, marketHeader, marketClose = makeSystemAppWindow("Global Exchange", "⇄", 420, UDim2.new(0.88, 0, 0.84, 0))
makeSystemLabel(marketBody, "Global Exchange", UDim2.fromOffset(18, 10), UDim2.new(1, -36, 0, 28), C.text, 21, true)
makeSystemLabel(marketBody, "Trade inventory materials with explorers across live servers. Items are escrowed while listed.", UDim2.fromOffset(18, 40), UDim2.new(1, -36, 0, 29), C.muted, 10, false)
local marketRefreshButton = makeSystemButton(marketBody, "RefreshMarket", "REFRESH", UDim2.new(1, -116, 0, 8), UDim2.fromOffset(98, 30), C.cyan)
local marketStatus = makeSystemLabel(marketBody, "Global order book ready.", UDim2.fromOffset(18, 74), UDim2.new(1, -36, 0, 24), C.cyan, 10, false)
local marketForm = make("Frame", marketBody, { Name="CreateListingPanel", Position=UDim2.fromOffset(18, 104), Size=UDim2.new(1, -36, 0, 82), BackgroundColor3=C.panel, BackgroundTransparency=0.12, BorderSizePixel=0 })
addCorner(marketForm, 10); addStroke(marketForm, C.line, 1, 0.45); make("UIGradient", marketForm, {Rotation=20, Color=ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(42,77,104)), ColorSequenceKeypoint.new(1, C.panel)})})
local marketItemButton = makeSystemButton(marketForm, "MarketItem", "ITEM: WaterIce", UDim2.fromOffset(10, 10), UDim2.new(0.34, -12, 0, 28), C.panel2)
local marketQtyInput = makeGlassInput(marketForm, "MarketQuantity", "Quantity", UDim2.new(0.35, 0, 0, 10), UDim2.new(0.17, -6, 0, 28), false)
local marketPriceInput = makeGlassInput(marketForm, "MarketPrice", "Credits / unit", UDim2.new(0.53, 0, 0, 10), UDim2.new(0.22, -6, 0, 28), false)
marketQtyInput.Text = "1"; marketPriceInput.Text = "50"
local marketCreateButton = makeSystemButton(marketForm, "CreateListing", "LIST ITEM", UDim2.new(0.76, 0, 0, 10), UDim2.new(0.22, -10, 0, 28), C.cyan)
local marketFeeNote = makeSystemLabel(marketForm, "3% transaction fee · Select an inventory item", UDim2.fromOffset(10, 45), UDim2.new(1, -20, 0, 24), C.muted, 10, false)
local marketList = makeSystemScroll(marketBody, "MarketListings", UDim2.fromOffset(18, 196), UDim2.new(1, -36, 1, -208))

local marketItemChoices = { "WaterIce", "LunarRegolith", "HematiteOre", "Silica", "AluminumAlloy", "CarbonComposite", "HydrogenGas", "OxygenGas", "BatteryCell", "AltheaTagDevice", "RocketEnginePart", "FuelTank" }
local marketItemIndex = 1
local function refreshMarketItemButton()
    marketItemButton.Text = "ITEM: " .. marketItemChoices[marketItemIndex]
end
marketItemButton.Activated:Connect(function()
    marketItemIndex += 1
    if marketItemIndex > #marketItemChoices then marketItemIndex = 1 end
    refreshMarketItemButton()
end)

local function renderGlobalMarket()
    clearSystemScroll(marketList)
    local response = requestServer("GetMarketListings", {})
    if not response.ok then
        marketStatus.Text = response.message or "Global Exchange unavailable."
        makeFeatureRow(marketList, "Market unavailable", marketStatus.Text, 60, 1)
        return
    end
    if response.profile then currentProfile = response.profile end
    marketFeeNote.Text = tostring(response.feePercent or 3) .. "% fee · Inventory: " .. tostring(currentProfile.Inventory and currentProfile.Inventory[marketItemChoices[marketItemIndex]] or 0) .. " × " .. marketItemChoices[marketItemIndex]
    local listings = response.listings or {}
    for index, listing in ipairs(listings) do
        local own = listing.SellerUserId == player.UserId
        local titleText = string.format("%s  ·  %d × %s", listing.ItemName, listing.Quantity, listing.Unit)
        local descText = string.format("%d Credits / unit  ·  Total %d Credits\nSeller: %s  ·  Listing %s", listing.UnitPrice, listing.Total, listing.SellerName, string.sub(listing.Id, 1, 8))
        local row = makeFeatureRow(marketList, titleText, descText, 76, index)
        local action = makeSystemButton(row, "ListingAction", own and "CANCEL" or "BUY", UDim2.new(1, -112, 0, 22), UDim2.fromOffset(94, 30), own and C.warning or C.cyan)
        action.Activated:Connect(function()
            action.Active = false
            local result
            if own then result = requestServer("CancelMarketListing", { listingId=listing.Id })
            else result = requestServer("BuyMarketListing", { listingId=listing.Id }) end
            if result.profile then currentProfile = result.profile end
            marketStatus.Text = result.message or "Transaction requested."
            renderGlobalMarket()
        end)
    end
    if #listings == 0 then makeFeatureRow(marketList, "No active listings", "List material from your Inventory, or refresh after another player publishes an offer.", 62, 1) end
    marketStatus.Text = string.format("%d active listing(s) · prices and payments are validated on the server.", #listings)
end

marketCreateButton.Activated:Connect(function()
    local qty = tonumber(marketQtyInput.Text)
    local price = tonumber(marketPriceInput.Text)
    if not qty or not price then marketStatus.Text = "Enter a valid integer quantity and unit price."; return end
    marketCreateButton.Active = false
    local result = requestServer("CreateMarketListing", { itemId=marketItemChoices[marketItemIndex], quantity=qty, unitPrice=price })
    if result.profile then currentProfile = result.profile end
    marketStatus.Text = result.message or "Listing requested."
    renderGlobalMarket()
end)
marketRefreshButton.Activated:Connect(renderGlobalMarket)
registerSystemApp("Global Exchange", "⇄", 420, UDim2.new(0.88, 0, 0.84, 0), marketWindow, marketHeader, marketClose)

-- Lazy refresh when launching a feature app from the Dock.
local function refreshFeatureApp(name)
    if name == "App Requests" then renderMyAppRequests()
    elseif name == "Althea Supply" then
        if supplyMode == "Orders" then renderSupplyOrders() else renderSupplyProducts() end
    elseif name == "AltheaMap" then renderMap()
    elseif name == "AltheaTag" then renderTrackableRockets()
    elseif name == "Mission & Jobs" then renderJobs()
    elseif name == "Global Exchange" then renderGlobalMarket() end
end
local featureRefresh = playerScripts:FindFirstChild("AltheaOSFeatureRefresh")
if not featureRefresh then
    featureRefresh = Instance.new("BindableEvent")
    featureRefresh.Name = "AltheaOSFeatureRefresh"
    featureRefresh.Parent = playerScripts
end
featureRefresh.Event:Connect(refreshFeatureApp)

-- Connect complete system apps after their windows have been registered.
loadFilesIntoList()
refreshAirDropLists()
local systemMenuEvent = playerScripts:FindFirstChild("AltheaOSSystemMenuEvent")
if systemMenuEvent and systemMenuEvent:IsA("BindableEvent") then
    systemMenuEvent.Event:Connect(function(appName)
        if appName == "Battery" then
            local response = requestServer("GetProfile", {})
            refreshBatteryUI(response)
            osManager:OpenWindow("Battery")
        elseif appName == "Settings" then
            osManager:OpenWindow("Settings")
        end
    end)
end

-- The temporary builder ScreenGui is no longer needed: WindowManager owns all windows.
-- The OS Shell itself starts disabled; no desktop, dock, or app pops up at game start.
if gui and gui.Parent then
    gui:Destroy()
end

-- Pre-select Hydrogen so it is ready when the player opens Periodic Table from the Dock; the window remains closed.
selectedElement = elementByNumber[1]
showElement(selectedElement)
updateFilters()
for _, refs in pairs(elementButtons) do
    refs.stroke.Thickness = 1
end
if elementButtons[1] then
    elementButtons[1].stroke.Color = C.gold
    elementButtons[1].stroke.Thickness = 2
end

-- Keep the displayed memory use current while the Store is visible.
task.spawn(function()
    while script.Parent do
        if appStoreWindow and appStoreWindow.Visible then
            updateStoreSummary()
            if storePage == "Hardware" and storeContent then
                local overview = storeContent:FindFirstChild("RAMOverview")
                local usageLabel = overview and overview:FindFirstChild("CurrentRamUsage")
                if usageLabel then
                    local level = tonumber(currentProfile.RAMLevel) or 1
                    local tier = RAM_TIERS[level] or RAM_TIERS[1]
                    usageLabel.Text = string.format("%s installed  ·  %s currently allocated", tier.Name, formatSize(osManager:GetRAMUsageMB()))
                end
            end
        end
        task.wait(1)
    end
end)

-- Sync the physical power state with the server and refresh battery status.
-- This also catches the menu-bar Power button closing the desktop, not only Tool.Unequipped.
task.spawn(function()
    local lastPowerState = osManager.desktopOpen == true
    local tickCount = 0
    while script.Parent do
        local powerState = osManager.desktopOpen == true
        if powerState ~= lastPowerState then
            local powerResponse = requestServer("SetDevicePower", { enabled = powerState })
            lastPowerState = powerState
            if powerResponse.profile then
                currentProfile = powerResponse.profile
                osManager:SetBatteryPercent(currentProfile.BatteryPercent or 100, currentProfile.BatteryCharging == true)
            end
            if powerState and not powerResponse.ok then
                osManager:CloseDesktop()
                osManager:_showToast(powerResponse.message or "Battery depleted. Charge the device first.")
                lastPowerState = false
            end
        else
            tickCount += 1
            if tickCount % 2 == 0 then
                local statusResponse = requestServer("GetProfile", {})
                if statusResponse.profile then
                    currentProfile = statusResponse.profile
                    osManager:SetBatteryPercent(currentProfile.BatteryPercent or 100, currentProfile.BatteryCharging == true)
                    if currentProfile.BatteryPercent <= 0 and osManager.desktopOpen then
                        osManager:CloseDesktop()
                    end
                end
            end
        end
        if airDropWindow and airDropWindow.Visible and os.clock() - lastAirDropAutoRefresh >= 12 then
            refreshAirDropLists()
            lastAirDropAutoRefresh = os.clock()
        end
        if batteryWindow and batteryWindow.Visible then
            -- UI updates are cheap; server profile polls above remain rate-limited to every 10 seconds.
            refreshBatteryUI()
        end
        task.wait(5)
    end
end)

-- Load the saved device profile from the Server. Server owns installs, RAM, battery and settings.
task.spawn(function()
    local response = requestServer("GetProfile", {})
    if response and response.ok and response.profile then
        refreshProfileAndStatus(response)
        renderStore()
    else
        refreshProfileAndStatus(response or { ok = false, message = "Could not load profile." })
        renderStore()
    end
end)


-- Refresh data for extension apps while their windows are visible; low-frequency polling only.
task.spawn(function()
    while script.Parent do
        if osManager.desktopOpen then
            if appRequestsWindow and appRequestsWindow.Visible then renderMyAppRequests() end
            if supplyWindow and supplyWindow.Visible then refreshSupplySummary() end
        end
        task.wait(15)
    end
end)
