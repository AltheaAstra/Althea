-- AltheaBook Full System Server V3 — Economy Reward Bridge
-- Install in ServerScriptService. The server owns persistent Credits, apps, RAM,
-- battery state, system preferences, device files, and AirDrop transfers.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local DataStoreService = game:GetService("DataStoreService")
local HttpService = game:GetService("HttpService")
local CollectionService = game:GetService("CollectionService")
local AppRegistry = require(ReplicatedStorage:WaitForChild("AltheaAppRegistry"))

local DATASTORE_NAME = "AltheaBookProfile_v1"
local WALLET_DATASTORE_NAME = "AltheaBookWallet_v1"
local MARKET_DATASTORE_NAME = "AltheaGlobalExchange_v1"
local STORAGE_CAPACITY_MB = 32768
local STARTING_CREDITS = 1200
local REQUEST_COOLDOWN = 0.18
local MAX_FILES = 35
local MAX_FILE_CONTENT = 6000
local AIRDROP_RANGE = 80
local CHARGER_RANGE = 15
local BATTERY_STEP_SECONDS = 10
local BATTERY_DRAIN_PER_MINUTE = 1.5
local BATTERY_CHARGE_ON_PER_MINUTE = 0.8
local BATTERY_CHARGE_OFF_PER_MINUTE = 4.0

local APP_CATALOG = {}
for _, app in ipairs(AppRegistry.Apps) do
    if app.Id ~= "AppStore" then
        APP_CATALOG[app.Id] = {
            Price = app.Price,
            SizeMB = app.SizeMB,
            Protected = app.Protected == true,
            SystemApp = app.SystemApp == true,
            Status = app.Status or "Available",
            Version = app.Version or "1.0.0",
        }
    end
end

local RAM_TIERS = {
    [1] = { CapacityMB = 4096, Price = 0, Name = "4 GB" },
    [2] = { CapacityMB = 8192, Price = 350, Name = "8 GB" },
    [3] = { CapacityMB = 16384, Price = 800, Name = "16 GB" },
    [4] = { CapacityMB = 32768, Price = 1800, Name = "32 GB" },
}

-- Server-authoritative reward definitions. Client requests cannot award Credits directly.
-- Trusted mission/mining/utility server scripts call the ServerStorage BindableFunction below
-- only after the actual objective has been verified.
local REWARD_CATALOG = {
    RocketLaunchOrbit = { Amount = 350, Label = "Rocket launch mission" },
    RocketPayloadDelivered = { Amount = 600, Label = "Payload delivery mission" },
    ExplorationMilestone = { Amount = 450, Label = "Exploration milestone" },
    MiningContractSmall = { Amount = 120, Label = "NPC mining contract" },
    MiningContractRareOre = { Amount = 280, Label = "Rare ore contract" },
    WaterTreatmentBatch = { Amount = 100, Label = "Water treatment contract" },
    WaterProductionBatch = { Amount = 120, Label = "Water production contract" },
    PowerProductionBatch = { Amount = 150, Label = "Power production contract" },
}

local DEFAULT_SETTINGS = {
    Wallpaper = "Orbit",
    DockAutoHide = true,
    ReducedMotion = false,
    ShowBatteryPercent = true,
    AirDropMode = "Everyone",
    DeviceName = "AltheaBook",
}

-- Supply stock is per live server in V2. Use a dedicated global stock service before a cross-server economy launch.
local SUPPLY_CATALOG = {
    WaterIce = { Name="Water Ice", Category="Raw Resources", Description="Icy resource for water processing research.", Price=35, Stock=300, Unit="kg", InventoryId="WaterIce" },
    LunarRegolith = { Name="Lunar Regolith", Category="Raw Resources", Description="Mixed surface material for extraction and construction.", Price=22, Stock=500, Unit="kg", InventoryId="LunarRegolith" },
    HematiteOre = { Name="Hematite Ore", Category="Ores", Description="Iron-bearing ore for a future refining workflow.", Price=50, Stock=250, Unit="kg", InventoryId="HematiteOre" },
    Silica = { Name="Silica", Category="Materials", Description="Silicon dioxide feedstock for glass and ceramics.", Price=40, Stock=240, Unit="kg", InventoryId="Silica" },
    AluminumAlloy = { Name="Aluminum Alloy", Category="Refined Materials", Description="Lightweight engineering material for vehicle structures.", Price=95, Stock=180, Unit="kg", InventoryId="AluminumAlloy" },
    CarbonComposite = { Name="Carbon Composite", Category="Refined Materials", Description="High-stiffness composite for aerospace structures.", Price=140, Stock=120, Unit="kg", InventoryId="CarbonComposite" },
    HydrogenGas = { Name="Hydrogen Gas", Category="Chemicals", Description="Stored research resource; handling rules are simulated by the game.", Price=125, Stock=150, Unit="kg", InventoryId="HydrogenGas" },
    OxygenGas = { Name="Oxygen Gas", Category="Chemicals", Description="Oxidizer / life-support resource for game recipes.", Price=85, Stock=180, Unit="kg", InventoryId="OxygenGas" },
    BatteryCell = { Name="Power Cell", Category="Electronics", Description="Portable charge item for AltheaBook battery gameplay.", Price=75, Stock=250, Unit="unit", InventoryId="BatteryCell" },
    AltheaTagDevice = { Name="AltheaTag Device", Category="Navigation", Description="Tracking beacon that can be installed on an owned, tagged rocket.", Price=250, Stock=100, Unit="unit", InventoryId="AltheaTagDevice" },
    RocketEnginePart = { Name="Rocket Engine Component", Category="Rocket Parts", Description="A future manufacturing input for rocket engines.", Price=400, Stock=60, Unit="unit", InventoryId="RocketEnginePart" },
    FuelTank = { Name="Fuel Tank", Category="Rocket Parts", Description="A future vehicle-building component.", Price=320, Stock=75, Unit="unit", InventoryId="FuelTank" },
}
local supplyStock = {}
for productId, product in pairs(SUPPLY_CATALOG) do supplyStock[productId] = product.Stock end

local APP_REQUEST_STATUSES = { Submitted=true, ["Under Review"]=true, Planned=true, ["In Development"]=true, Released=true, Declined=true }
local ADMIN_USER_IDS = { } -- Optional: add trusted numeric UserIds here. The experience owner is automatically admin when owned by a user.
local store = DataStoreService:GetDataStore(DATASTORE_NAME)
local walletStore = DataStoreService:GetDataStore(WALLET_DATASTORE_NAME)
local marketStore = DataStoreService:GetDataStore(MARKET_DATASTORE_NAME)
local appRequestsStore = DataStoreService:GetDataStore("AltheaAppRequests_v1")
local profiles, lastRequestAt, devicePower = {}, {}, {}
local pendingAirDrops = {}
local persistenceState = {}
local lastSavedBattery, lastBatterySaveAt = {}, {}
local appRequestCooldownAt, supplyTransactionLock = {}, {}

local remotes = ReplicatedStorage:FindFirstChild("AltheaBookRemotes")
if not remotes then
    remotes = Instance.new("Folder")
    remotes.Name = "AltheaBookRemotes"
    remotes.Parent = ReplicatedStorage
end
local requestRemote = remotes:FindFirstChild("Request")
if not requestRemote then
    requestRemote = Instance.new("RemoteFunction")
    requestRemote.Name = "Request"
    requestRemote.Parent = remotes
end

-- Server-only reward bridge. This lives in ServerStorage, so LocalScripts cannot invoke it.
local economyBridge = ServerStorage:FindFirstChild("AltheaEconomyBridge")
if not economyBridge then
    economyBridge = Instance.new("BindableFunction")
    economyBridge.Name = "AltheaEconomyBridge"
    economyBridge.Parent = ServerStorage
end

local function defaultFiles()
    return {
        {
            Id = "welcome_note",
            Name = "Welcome to AltheaBook.txt",
            Type = "text/plain",
            Content = "Welcome to AltheaBook.\n\nUse App Store to install apps. Use Settings to personalize your desktop.\nUse AirDrop to share files with nearby explorers.",
        },
        {
            Id = "rocket_science_notes",
            Name = "Rocket Science Notes.txt",
            Type = "text/plain",
            Content = "Rocket Science notebook\n\nElements -> Materials -> Resources -> Refining -> Reactions -> Rocket manufacturing.\n\nExample: water electrolysis produces hydrogen and oxygen in a 2:1 molecular ratio.",
        },
    }
end

local function defaultProfile()
    local settings = table.clone(DEFAULT_SETTINGS)
    return {
        Version = 4,
        Credits = STARTING_CREDITS,
        InstalledApps = {
            AppStore = true,
            PeriodicTable = true,
            Settings = true,
            Battery = true,
            AirDrop = true,
            MyFiles = true,
            AppRequests = true,
            AltheaSupply = true,
            AltheaMap = true,
            AltheaTag = true,
            JobBoard = true,
            GlobalExchange = true,
        },
        RAMLevel = 1,
        BatteryPercent = 100,
        Settings = settings,
        Files = defaultFiles(),
        Inventory = {},
        Orders = {},
        Trackers = {},
        ProcessedOrderIds = {},
        ProcessedRewardIds = {},
        ProcessedMarketReceipts = {},
        ActiveJobs = {},
    }
end

local function cloneDict(source)
    local result = {}
    if type(source) == "table" then
        for key, value in pairs(source) do
            if type(key) == "string" and value == true then result[key] = true end
        end
    end
    return result
end

local function cleanString(value, maxLength)
    if type(value) ~= "string" then return nil end
    value = value:gsub("\r\n", "\n"):gsub("\r", "\n")
    value = value:gsub("[%z\1-\8\11\12\14-\31]", "")
    if #value > maxLength then value = string.sub(value, 1, maxLength) end
    return value
end

local function normalizeSettings(raw)
    local result = table.clone(DEFAULT_SETTINGS)
    if type(raw) ~= "table" then return result end
    if raw.Wallpaper == "Orbit" or raw.Wallpaper == "Aurora" or raw.Wallpaper == "Midnight" or raw.Wallpaper == "Dawn" then
        result.Wallpaper = raw.Wallpaper
    end
    if type(raw.DockAutoHide) == "boolean" then result.DockAutoHide = raw.DockAutoHide end
    if type(raw.ReducedMotion) == "boolean" then result.ReducedMotion = raw.ReducedMotion end
    if type(raw.ShowBatteryPercent) == "boolean" then result.ShowBatteryPercent = raw.ShowBatteryPercent end
    if raw.AirDropMode == "Everyone" or raw.AirDropMode == "Off" then result.AirDropMode = raw.AirDropMode end
    local deviceName = cleanString(raw.DeviceName, 24)
    if deviceName and #deviceName > 0 then result.DeviceName = deviceName end
    return result
end

local function normalizeFiles(rawFiles, defaultsIfMissing)
    if type(rawFiles) ~= "table" then
        return defaultsIfMissing and defaultFiles() or {}
    end
    local files = {}
    for _, rawFile in ipairs(rawFiles) do
        if #files >= MAX_FILES then break end
        if type(rawFile) == "table" then
            local id = cleanString(rawFile.Id, 80)
            local name = cleanString(rawFile.Name, 64)
            local content = cleanString(rawFile.Content, MAX_FILE_CONTENT)
            local fileType = cleanString(rawFile.Type or "text/plain", 40) or "text/plain"
            if id and name and content and #name > 0 then
                table.insert(files, { Id = id, Name = name, Type = fileType, Content = content })
            end
        end
    end
    return files
end

local function normalizeInventory(raw)
    local result = {}
    if type(raw) ~= "table" then return result end
    for itemId, quantity in pairs(raw) do
        if type(itemId) == "string" and #itemId <= 64 and type(quantity) == "number" and quantity > 0 then
            result[itemId] = math.clamp(math.floor(quantity), 0, 99999)
        end
    end
    return result
end

local function normalizeOrderList(raw)
    local result = {}
    if type(raw) ~= "table" then return result end
    for _, order in ipairs(raw) do
        if #result >= 30 then break end
        if type(order) == "table" and type(order.OrderId) == "string" then
            table.insert(result, {
                OrderId = cleanString(order.OrderId, 80) or "",
                RequestId = cleanString(order.RequestId, 80) or "",
                CreatedAt = tonumber(order.CreatedAt) or os.time(),
                Status = cleanString(order.Status, 24) or "Delivered",
                Total = math.max(0, math.floor(tonumber(order.Total) or 0)),
                Items = type(order.Items) == "table" and order.Items or {},
            })
        end
    end
    return result
end

local function normalizeTrackers(raw)
    local result = {}
    if type(raw) ~= "table" then return result end
    for _, tracker in ipairs(raw) do
        if #result >= 30 then break end
        if type(tracker) == "table" and type(tracker.RocketId) == "string" and type(tracker.TrackerId) == "string" then
            local p = type(tracker.LastPosition) == "table" and tracker.LastPosition or {}
            table.insert(result, {
                TrackerId = cleanString(tracker.TrackerId, 80),
                RocketId = cleanString(tracker.RocketId, 80),
                RocketName = cleanString(tracker.RocketName or "Rocket", 64) or "Rocket",
                LastPosition = { X=tonumber(p.X) or 0, Y=tonumber(p.Y) or 0, Z=tonumber(p.Z) or 0 },
                LastSeenAt = tonumber(tracker.LastSeenAt) or 0,
                State = cleanString(tracker.State or "LAST_KNOWN", 24) or "LAST_KNOWN",
                FuelPercent = type(tracker.FuelPercent) == "number" and math.clamp(tracker.FuelPercent, 0, 100) or nil,
                Altitude = tonumber(tracker.Altitude),
                FlightStage = tracker.FlightStage ~= nil and cleanString(tostring(tracker.FlightStage), 24) or nil,
                MissionStatus = tracker.MissionStatus ~= nil and cleanString(tostring(tracker.MissionStatus), 32) or nil,
                HeadingDegrees = tonumber(tracker.HeadingDegrees),
                Velocity = type(tracker.Velocity) == "table" and { X=tonumber(tracker.Velocity.X) or 0, Y=tonumber(tracker.Velocity.Y) or 0, Z=tonumber(tracker.Velocity.Z) or 0, Speed=tonumber(tracker.Velocity.Speed) or 0 } or nil,
            })
        end
    end
    return result
end

local function normalizeStringList(raw, maxItems)
    local result = {}
    if type(raw) ~= "table" then return result end
    for _, value in ipairs(raw) do
        if #result >= (maxItems or 50) then break end
        if type(value) == "string" and #value <= 80 then table.insert(result, value) end
    end
    return result
end

local function normalizeProfile(raw)
    local profile = defaultProfile()
    if type(raw) == "table" then
        if type(raw.Credits) == "number" and raw.Credits >= 0 then profile.Credits = math.floor(raw.Credits) end
        if type(raw.RAMLevel) == "number" then profile.RAMLevel = math.clamp(math.floor(raw.RAMLevel), 1, #RAM_TIERS) end
        if type(raw.BatteryPercent) == "number" then profile.BatteryPercent = math.clamp(raw.BatteryPercent, 0, 100) end
        profile.Settings = normalizeSettings(raw.Settings)
        profile.Files = normalizeFiles(raw.Files, raw.Files == nil)
        profile.Inventory = normalizeInventory(raw.Inventory)
        profile.Orders = normalizeOrderList(raw.Orders)
        profile.Trackers = normalizeTrackers(raw.Trackers)
        profile.ProcessedOrderIds = normalizeStringList(raw.ProcessedOrderIds, 50)
        profile.ProcessedRewardIds = normalizeStringList(raw.ProcessedRewardIds, 200)
        profile.ProcessedMarketReceipts = normalizeStringList(raw.ProcessedMarketReceipts, 300)
        profile.ActiveJobs = type(raw.ActiveJobs) == "table" and raw.ActiveJobs or {}
        profile.InstalledApps = cloneDict(raw.InstalledApps)
        profile.InstalledApps.AppStore = true
        profile.InstalledApps.PeriodicTable = true
        profile.InstalledApps.Settings = true
        profile.InstalledApps.Battery = true
        profile.InstalledApps.AirDrop = true
        profile.InstalledApps.MyFiles = true
        profile.InstalledApps.AppRequests = true
        profile.InstalledApps.AltheaSupply = true
        profile.InstalledApps.AltheaMap = true
        profile.InstalledApps.AltheaTag = true
        profile.InstalledApps.JobBoard = true
        profile.InstalledApps.GlobalExchange = true
        for appId in pairs(profile.InstalledApps) do
            if appId ~= "AppStore" and not APP_CATALOG[appId] then profile.InstalledApps[appId] = nil end
        end
    end
    profile.ProcessedRewardIds = profile.ProcessedRewardIds or {}
    return profile
end

local function getFileStorageMB(profile)
    local usedMB = 0
    for _, file in ipairs(profile.Files or {}) do
        -- File packages consume at least 1 MB in the virtual file system.
        usedMB += math.max(1, math.ceil(#(file.Content or "") / (1024 * 1024)))
    end
    return usedMB
end

local function getStorageUsed(profile)
    local used = 150 -- App Store system package
    for appId, installed in pairs(profile.InstalledApps) do
        if installed and appId ~= "AppStore" then
            local item = APP_CATALOG[appId]
            if item then used += item.SizeMB end
        end
    end
    used += getFileStorageMB(profile)
    return used
end

local function rootPart(player)
    local character = player.Character
    return character and character:FindFirstChild("HumanoidRootPart") or nil
end

local function isChargerPart(part)
    return part:IsA("BasePart") and (
        part.Name == "AltheaCharger"
        or part.Name == "AltheaChargingStation"
        or CollectionService:HasTag(part, "AltheaCharger")
    )
end

-- Cache charger parts instead of scanning the whole Workspace on every status request.
local chargerParts = {}
for _, item in ipairs(workspace:GetDescendants()) do
    if isChargerPart(item) then chargerParts[item] = true end
end
workspace.DescendantAdded:Connect(function(item)
    if item:IsA("BasePart") and isChargerPart(item) then chargerParts[item] = true end
end)
workspace.DescendantRemoving:Connect(function(item)
    chargerParts[item] = nil
end)
CollectionService:GetInstanceAddedSignal("AltheaCharger"):Connect(function(item)
    if item:IsA("BasePart") then chargerParts[item] = true end
end)
CollectionService:GetInstanceRemovedSignal("AltheaCharger"):Connect(function(item)
    if item:IsA("BasePart") and item.Name ~= "AltheaCharger" and item.Name ~= "AltheaChargingStation" then
        chargerParts[item] = nil
    end
end)

local function nearCharger(player)
    local root = rootPart(player)
    if not root then return false end
    for item in pairs(chargerParts) do
        if item.Parent and item:IsDescendantOf(workspace) and (root.Position - item.Position).Magnitude <= CHARGER_RANGE then
            return true
        end
    end
    return false
end

local function findFile(profile, fileId)
    for index, file in ipairs(profile.Files) do
        if file.Id == fileId then return file, index end
    end
    return nil, nil
end

local function playerDistance(a, b)
    local rootA, rootB = rootPart(a), rootPart(b)
    if not rootA or not rootB then return math.huge end
    return (rootA.Position - rootB.Position).Magnitude
end

local function publicProfile(player, profile)
    local ram = RAM_TIERS[profile.RAMLevel] or RAM_TIERS[1]
    local isCharging = nearCharger(player) and profile.BatteryPercent < 100
    return {
        Version = profile.Version or 2,
        Credits = profile.Credits,
        InstalledApps = cloneDict(profile.InstalledApps),
        RAMLevel = profile.RAMLevel,
        RamCapacityMB = ram.CapacityMB,
        RamName = ram.Name,
        StorageCapacityMB = STORAGE_CAPACITY_MB,
        StorageUsedMB = getStorageUsed(profile),
        BatteryPercent = math.floor(profile.BatteryPercent * 10 + 0.5) / 10,
        BatteryCharging = isCharging,
        Settings = table.clone(profile.Settings),
        FileCount = #profile.Files,
        DeviceName = profile.Settings.DeviceName,
        Inventory = table.clone(profile.Inventory or {}),
        Orders = profile.Orders or {},
        Trackers = profile.Trackers or {},
        ActiveJobs = profile.ActiveJobs or {},
        ProcessedMarketReceipts = profile.ProcessedMarketReceipts or {},
    }
end

local function normalizeWalletRecord(raw, fallbackBalance)
    local balance = fallbackBalance or STARTING_CREDITS
    local receipts = {}
    if type(raw) == "number" then
        balance = raw
    elseif type(raw) == "table" then
        if type(raw.Balance) == "number" and raw.Balance >= 0 then balance = raw.Balance end
        if type(raw.Receipts) == "table" then
            for _, receipt in ipairs(raw.Receipts) do
                if type(receipt) == "string" and #receipt <= 140 then table.insert(receipts, receipt) end
            end
        end
    end
    return { Balance = math.max(0, math.floor(balance)), Receipts = receipts }
end

local function hasWalletReceipt(wallet, receiptId)
    return table.find(wallet.Receipts or {}, receiptId) ~= nil
end

local function ensureWallet(userId, fallbackBalance)
    local key = "u_" .. tostring(userId)
    local ok, value = pcall(function()
        return walletStore:UpdateAsync(key, function(raw)
            return normalizeWalletRecord(raw, fallbackBalance or STARTING_CREDITS)
        end)
    end)
    if not ok then return nil, value end
    return normalizeWalletRecord(value, fallbackBalance or STARTING_CREDITS)
end

-- The wallet DataStore is the source of truth for Credits across different live servers.
-- Stable receipts make repeated spend/reward requests idempotent.
local function changeWalletByUserId(userId, delta, receiptId, fallbackBalance)
    if type(receiptId) ~= "string" or #receiptId < 4 or #receiptId > 140 then
        return nil, nil, "Invalid wallet receipt."
    end
    local key = "u_" .. tostring(userId)
    local ok, value = pcall(function()
        return walletStore:UpdateAsync(key, function(raw)
            local wallet = normalizeWalletRecord(raw, fallbackBalance or STARTING_CREDITS)
            if hasWalletReceipt(wallet, receiptId) then return wallet end
            if delta < 0 and wallet.Balance < math.abs(delta) then return wallet end
            wallet.Balance = math.max(0, math.floor(wallet.Balance + delta))
            table.insert(wallet.Receipts, receiptId)
            while #wallet.Receipts > 500 do table.remove(wallet.Receipts, 1) end
            return wallet
        end)
    end)
    if not ok then return nil, nil, value end
    local wallet = normalizeWalletRecord(value, fallbackBalance or STARTING_CREDITS)
    if not hasWalletReceipt(wallet, receiptId) then
        return false, wallet.Balance, "Not enough Credits."
    end
    local online = Players:GetPlayerByUserId(userId)
    if online and profiles[online] then profiles[online].Credits = wallet.Balance end
    return true, wallet.Balance
end

local function syncWallet(player, profile)
    local ok, raw = pcall(function()
        return walletStore:GetAsync("u_" .. tostring(player.UserId))
    end)
    if ok then
        if raw == nil then
            local wallet = ensureWallet(player.UserId, profile.Credits)
            if wallet then profile.Credits = wallet.Balance end
        else
            profile.Credits = normalizeWalletRecord(raw, profile.Credits).Balance
        end
    end
end

local function changePlayerCredits(player, delta, receiptId)
    local profile = profiles[player]
    if not profile then return nil, nil, "Player profile is not loaded." end
    local ok, balance, err = changeWalletByUserId(player.UserId, delta, receiptId, profile.Credits)
    if ok ~= nil then profile.Credits = balance end
    return ok, balance, err
end

local function loadProfile(player)
    if profiles[player] then return profiles[player] end
    local loaded
    local ok, result = pcall(function()
        return store:GetAsync("u_" .. tostring(player.UserId))
    end)
    persistenceState[player] = ok
    if ok then
        loaded = result
    else
        warn("AltheaBook: DataStore load failed; using session profile. Enable API Services for persistent saves.", result)
    end
    local profile = normalizeProfile(loaded)
    local wallet, walletErr = ensureWallet(player.UserId, profile.Credits)
    if wallet then profile.Credits = wallet.Balance else persistenceState[player] = false; warn("AltheaBook wallet load failed; using profile balance for this session:", walletErr) end
    profiles[player] = profile
    lastSavedBattery[player] = profile.BatteryPercent
    lastBatterySaveAt[player] = os.clock()
    return profile
end

local function saveProfile(player)
    local profile = profiles[player]
    if not profile then return false end
    -- UpdateAsync avoids plain blind SetAsync writes; Credits are always reloaded from the separate wallet store.
    local snapshot = table.clone(profile)
    local ok, err = pcall(function()
        store:UpdateAsync("u_" .. tostring(player.UserId), function(_old)
            return snapshot
        end)
    end)
    persistenceState[player] = ok
    if not ok then
        warn("AltheaBook: DataStore save failed; retrying is safe where transaction receipts are used:", err)
    end
    return ok
end

-- Use only from trusted server-side quest/mission/resource systems.
-- receiptId must be a stable unique ID for the completed event (e.g. MissionRunId).
local function awardTrustedReward(player, rewardId, receiptId)
    local profile = profiles[player]
    if not profile then return { ok = false, message = "Player profile is not loaded." } end
    if type(rewardId) ~= "string" or type(receiptId) ~= "string" then
        return { ok = false, message = "Invalid reward request." }
    end
    local reward = REWARD_CATALOG[rewardId]
    if not reward then return { ok = false, message = "Unknown reward ID." } end
    receiptId = cleanString(receiptId, 100)
    if not receiptId or #receiptId < 4 then return { ok = false, message = "A valid unique receipt ID is required." } end
    local ledgerId = rewardId .. ":" .. receiptId
    if table.find(profile.ProcessedRewardIds, ledgerId) then
        syncWallet(player, profile)
        return { ok = true, duplicate = true, amount = 0, credits = profile.Credits, message = "Reward already processed." }
    end

    local credited, balance, walletErr = changePlayerCredits(player, reward.Amount, "reward:" .. ledgerId)
    if credited ~= true then
        return { ok = false, message = "Could not update wallet safely: " .. tostring(walletErr or "try again") }
    end
    if not table.find(profile.ProcessedRewardIds, ledgerId) then table.insert(profile.ProcessedRewardIds, ledgerId) end
    while #profile.ProcessedRewardIds > 200 do table.remove(profile.ProcessedRewardIds, 1) end
    local saved = saveProfile(player)
    return {
        ok = true, duplicate = false, amount = reward.Amount, credits = balance,
        label = reward.Label, persistent = saved,
        message = string.format("%s complete: +%d Credits", reward.Label, reward.Amount),
    }
end

economyBridge.OnInvoke = function(player, operation, payload)
    if operation ~= "AwardReward" or type(payload) ~= "table" then
        return { ok = false, message = "Unsupported server economy operation." }
    end
    return awardTrustedReward(player, payload.rewardId, payload.receiptId)
end

local function responseFor(player, ok, message, profile, extra)
    local response = {
        ok = ok,
        message = message,
        profile = publicProfile(player, profile),
        persistent = persistenceState[player] ~= false,
    }
    if type(extra) == "table" then
        for key, value in pairs(extra) do response[key] = value end
    end
    return response
end

local function fail(player, message, profile, extra)
    return responseFor(player, false, message, profile, extra)
end

local function getPeers(player)
    local result = {}
    for _, target in ipairs(Players:GetPlayers()) do
        if target ~= player then
            local distance = playerDistance(player, target)
            if distance <= AIRDROP_RANGE then
                table.insert(result, {
                    UserId = target.UserId,
                    Name = target.DisplayName,
                    Username = target.Name,
                    Distance = math.floor(distance + 0.5),
                    DeviceName = profiles[target] and profiles[target].Settings.DeviceName or "AltheaBook",
                })
            end
        end
    end
    table.sort(result, function(a, b) return a.Distance < b.Distance end)
    return result
end

local function pendingFor(player)
    local list = pendingAirDrops[player.UserId] or {}
    local visible = {}
    local now = os.time()
    for index = #list, 1, -1 do
        if now - (list[index].CreatedAt or now) > 60 then table.remove(list, index) end
    end
    for _, request in ipairs(list) do
        table.insert(visible, {
            Id = request.Id,
            SenderUserId = request.SenderUserId,
            SenderName = request.SenderName,
            FileName = request.File.Name,
            FileType = request.File.Type,
        })
    end
    return visible
end

local function isAdmin(player)
    if game.CreatorType == Enum.CreatorType.User and player.UserId == game.CreatorId then return true end
    return table.find(ADMIN_USER_IDS, player.UserId) ~= nil
end

local function copyProductCatalog()
    local result = {}
    for id, product in pairs(SUPPLY_CATALOG) do
        table.insert(result, {
            Id = id, Name = product.Name, Category = product.Category,
            Description = product.Description, Price = product.Price,
            Stock = supplyStock[id] or 0, Unit = product.Unit,
        })
    end
    table.sort(result, function(a,b) if a.Category == b.Category then return a.Name < b.Name end return a.Category < b.Category end)
    return result
end

local function readAllAppRequests()
    local ok, result = pcall(function() return appRequestsStore:GetAsync("all") end)
    if not ok then
        warn("AltheaOS App Requests read failed:", result)
        return nil, "Request database unavailable. Check DataStore access and Output."
    end
    return type(result) == "table" and result or {}, nil
end

local function getMyAppRequests(player)
    local all, err = readAllAppRequests()
    if not all then return nil, err end
    local result = {}
    for _, item in ipairs(all) do
        if type(item) == "table" and tonumber(item.UserId) == player.UserId then
            table.insert(result, {
                Id=item.Id, Name=item.Name, Category=item.Category, Description=item.Description,
                IntendedUse=item.IntendedUse, Status=item.Status, ReviewMessage=item.ReviewMessage,
                CreatedAt=item.CreatedAt,
            })
        end
    end
    table.sort(result, function(a,b) return (a.CreatedAt or 0) > (b.CreatedAt or 0) end)
    return result, nil
end

local function getObjectPosition(object)
    if object:IsA("BasePart") then return object.Position end
    if object:IsA("Model") then
        local ok, pivot = pcall(function() return object:GetPivot() end)
        if ok then return pivot.Position end
        local part = object.PrimaryPart or object:FindFirstChildWhichIsA("BasePart", true)
        return part and part.Position or nil
    end
    return nil
end

local function getObjectRocketId(object)
    local id = object:GetAttribute("RocketId") or object:GetAttribute("AltheaRocketId")
    if type(id) == "number" then id = tostring(id) end
    if type(id) == "string" and #id > 0 then return id end
    return nil
end

local function getRocketTelemetry(object)
    local telemetry = {}
    local fuel = object:GetAttribute("FuelPercent")
    if type(fuel) == "number" then telemetry.FuelPercent = math.clamp(fuel, 0, 100) end
    local altitude = object:GetAttribute("Altitude")
    if type(altitude) == "number" then telemetry.Altitude = altitude end
    local stage = object:GetAttribute("FlightStage")
    if type(stage) == "string" or type(stage) == "number" then telemetry.FlightStage = cleanString(tostring(stage), 24) end
    local mission = object:GetAttribute("MissionStatus")
    if type(mission) == "string" then telemetry.MissionStatus = cleanString(mission, 32) end
    local heading = object:GetAttribute("HeadingDegrees")
    if type(heading) == "number" then telemetry.HeadingDegrees = heading % 360 end
    local part = nil
    if object:IsA("BasePart") then
        part = object
    elseif object:IsA("Model") then
        part = object.PrimaryPart or object:FindFirstChildWhichIsA("BasePart", true)
    end
    if part then
        local velocity = part.AssemblyLinearVelocity
        telemetry.Velocity = { X=velocity.X, Y=velocity.Y, Z=velocity.Z, Speed=velocity.Magnitude }
    end
    return telemetry
end

local function getObjectOwnerMatches(player, object)
    local ownerUserId = tonumber(object:GetAttribute("OwnerUserId"))
    if ownerUserId then return ownerUserId == player.UserId end
    local ownerTeam = object:GetAttribute("OwnerTeam")
    return player.Team ~= nil and type(ownerTeam) == "string" and ownerTeam == player.Team.Name
end

local function getRocketTargets()
    local result, seen = {}, {}
    for _, tagName in ipairs({"AltheaRocket", "AltheaTrackable"}) do
        for _, object in ipairs(CollectionService:GetTagged(tagName)) do
            if (object:IsA("Model") or object:IsA("BasePart")) and not seen[object] then
                seen[object] = true
                local rocketId = getObjectRocketId(object)
                local pos = getObjectPosition(object)
                if rocketId and pos then
                    table.insert(result, { Object=object, RocketId=rocketId, Position=pos })
                end
            end
        end
    end
    return result
end

local function findOwnedRocket(player, rocketId)
    for _, record in ipairs(getRocketTargets()) do
        if record.RocketId == rocketId and getObjectOwnerMatches(player, record.Object) then
            return record
        end
    end
    return nil
end

local function findTracker(profile, rocketId)
    for index, tracker in ipairs(profile.Trackers or {}) do
        if tracker.RocketId == rocketId then return tracker, index end
    end
    return nil, nil
end

local function updateTrackerPositions(player, profile)
    local liveById = {}
    for _, target in ipairs(getRocketTargets()) do
        if getObjectOwnerMatches(player, target.Object) then liveById[target.RocketId] = target end
    end
    for _, tracker in ipairs(profile.Trackers or {}) do
        local target = liveById[tracker.RocketId]
        if target then
            local attachedId = target.Object:GetAttribute("AltheaTagTrackerId")
            if attachedId == nil then
                -- Restore a saved tracker link when the same owned rocket respawns.
                target.Object:SetAttribute("AltheaTagTrackerId", tracker.TrackerId)
                attachedId = tracker.TrackerId
            end
            if attachedId == tracker.TrackerId then
                tracker.LastPosition = { X=target.Position.X, Y=target.Position.Y, Z=target.Position.Z }
                tracker.LastSeenAt = os.time()
                tracker.State = "LIVE"
                tracker.RocketName = cleanString(target.Object:GetAttribute("RocketName") or target.Object.Name, 64) or "Rocket"
                local telemetry = getRocketTelemetry(target.Object)
                tracker.FuelPercent = telemetry.FuelPercent
                tracker.Altitude = telemetry.Altitude
                tracker.FlightStage = telemetry.FlightStage
                tracker.MissionStatus = telemetry.MissionStatus
                tracker.HeadingDegrees = telemetry.HeadingDegrees
                tracker.Velocity = telemetry.Velocity
            else
                tracker.State = "LAST_KNOWN"
            end
        else
            tracker.State = "LAST_KNOWN"
        end
    end
end

local function makeMapData(player, profile)
    updateTrackerPositions(player, profile)
    local markers = {}
    local root = rootPart(player)
    if root then
        table.insert(markers, {
            Id="player:" .. tostring(player.UserId), Name="You", Kind="Player",
            Position={X=root.Position.X, Y=root.Position.Y, Z=root.Position.Z}, Status="LIVE", Description="Your current position.",
        })
    end
    local seen = {}
    for _, object in ipairs(CollectionService:GetTagged("AltheaMapMarker")) do
        if #markers >= 150 then break end
        if (object:IsA("BasePart") or object:IsA("Model")) and object:GetAttribute("PublicMapMarker") ~= false then
            local pos = getObjectPosition(object)
            if pos and not seen[object] then
                seen[object] = true
                table.insert(markers, {
                    Id=cleanString(object:GetAttribute("MapId") or (object.Name .. ":" .. tostring(#markers + 1)), 80) or object.Name,
                    Name=cleanString(object:GetAttribute("MapLabel") or object.Name, 64) or object.Name,
                    Kind=cleanString(object:GetAttribute("MapCategory") or "Location", 24) or "Location",
                    Position={X=pos.X,Y=pos.Y,Z=pos.Z}, Status="LIVE",
                    Distance=root and (root.Position - pos).Magnitude or nil,
                    Description=cleanString(object:GetAttribute("MapDescription") or "World map marker.", 120) or "World map marker.",
                })
            end
        end
    end
    for _, tracker in ipairs(profile.Trackers or {}) do
        if #markers >= 150 then break end
        local pos = tracker.LastPosition or {X=0,Y=0,Z=0}
        local live = tracker.State == "LIVE"
        table.insert(markers, {
            Id="tracker:" .. tracker.TrackerId, Name=tracker.RocketName or tracker.RocketId,
            Kind="Rocket", RocketId=tracker.RocketId, TrackerId=tracker.TrackerId,
            Position={X=pos.X or 0,Y=pos.Y or 0,Z=pos.Z or 0}, Status=live and "LIVE" or "LAST KNOWN",
            Distance=root and (root.Position - Vector3.new(pos.X or 0, pos.Y or 0, pos.Z or 0)).Magnitude or nil,
            LastSeenAt=tracker.LastSeenAt or 0,
            FuelPercent=tracker.FuelPercent, Altitude=tracker.Altitude,
            FlightStage=tracker.FlightStage, MissionStatus=tracker.MissionStatus,
            HeadingDegrees=tracker.HeadingDegrees, Velocity=tracker.Velocity,
            Description=live and "AltheaTag signal active." or "Signal unavailable. Showing the last recorded position.",
        })
    end
    return markers
end

local function makeTrackableRocketList(player, profile)
    updateTrackerPositions(player, profile)
    local result = {}
    for _, record in ipairs(getRocketTargets()) do
        if getObjectOwnerMatches(player, record.Object) then
            local tracker = findTracker(profile, record.RocketId)
            local pos = record.Position
            table.insert(result, {
                RocketId=record.RocketId,
                Name=cleanString(record.Object:GetAttribute("RocketName") or record.Object.Name, 64) or "Rocket",
                Position={X=pos.X,Y=pos.Y,Z=pos.Z},
                Telemetry=getRocketTelemetry(record.Object),
                Tracked=tracker ~= nil and record.Object:GetAttribute("AltheaTagTrackerId") == tracker.TrackerId,
            })
        end
        if #result >= 100 then break end
    end
    return result
end

-- V4: Server-authoritative job contracts and cross-server global exchange.
local JOB_CATALOG = {
    { Id="OreSurveyDelivery", Name="Ore Survey Delivery", Category="Mining", RequirementId="HematiteOre", Quantity=10, Reward=300, Description="Deliver 10 units of Hematite Ore collected from a mining site." },
    { Id="WaterRecovery", Name="Water Recovery Contract", Category="Utilities", RequirementId="WaterIce", Quantity=10, Reward=220, Description="Deliver 10 units of Water Ice from an exploration or extraction operation." },
    { Id="PowerCellRecovery", Name="Power Cell Recovery", Category="Utilities", RequirementId="BatteryCell", Quantity=4, Reward=180, Description="Deliver 4 recovered Power Cells to the service depot." },
    { Id="CarbonCompositeSupply", Name="Composite Materials Contract", Category="Engineering", RequirementId="CarbonComposite", Quantity=3, Reward=300, Description="Deliver 3 units of Carbon Composite for aerospace repairs." },
}
local JOB_BY_ID = {}
for _, job in ipairs(JOB_CATALOG) do JOB_BY_ID[job.Id] = job end
local MARKET_ITEM_BY_ID = {}
for productId, product in pairs(SUPPLY_CATALOG) do
    MARKET_ITEM_BY_ID[product.InventoryId] = { ProductId=productId, Name=product.Name, Unit=product.Unit }
end
local MARKET_LISTING_TTL = 7 * 24 * 60 * 60
local MAX_OPEN_MARKET_LISTINGS = 250
local MARKET_FEE_PERCENT = 3

local function readMarketBook()
    local ok, value = pcall(function() return marketStore:GetAsync("OrderBook") end)
    if not ok then return nil, value end
    return type(value) == "table" and value or {}, nil
end

local function updateMarketBook(mutator)
    local ok, value = pcall(function()
        return marketStore:UpdateAsync("OrderBook", function(old)
            local current = type(old) == "table" and old or {}
            local nextValue = {}
            for _, listing in ipairs(current) do
                if type(listing) == "table" then table.insert(nextValue, table.clone(listing)) end
            end
            return mutator(nextValue) or nextValue
        end)
    end)
    if not ok then return nil, value end
    return type(value) == "table" and value or {}, nil
end

local function findMarketListing(book, listingId)
    for index, listing in ipairs(book or {}) do
        if listing.Id == listingId then return listing, index end
    end
    return nil, nil
end

local function publicMarketListing(listing)
    return {
        Id=listing.Id, SellerUserId=listing.SellerUserId, SellerName=listing.SellerName,
        ItemId=listing.ItemId, ItemName=listing.ItemName, Unit=listing.Unit,
        Quantity=listing.Quantity, UnitPrice=listing.UnitPrice,
        Total=listing.Quantity * listing.UnitPrice, CreatedAt=listing.CreatedAt,
        ExpiresAt=listing.ExpiresAt, Status=listing.Status,
    }
end

local function marketReadListings(viewerUserId)
    local book, err = readMarketBook()
    if not book then return nil, err end
    local result = {}
    for _, listing in ipairs(book) do
        local visibleOpen = listing.Status == "Open" and (tonumber(listing.ExpiresAt) or 0) > os.time()
        local visibleReservedForBuyer = listing.Status == "Reserved" and tonumber(listing.BuyerUserId) == tonumber(viewerUserId)
        if visibleOpen or visibleReservedForBuyer then table.insert(result, publicMarketListing(listing)) end
    end
    table.sort(result, function(a, b)
        if a.UnitPrice == b.UnitPrice then return a.CreatedAt > b.CreatedAt end
        return a.UnitPrice < b.UnitPrice
    end)
    while #result > 100 do table.remove(result) end
    return result
end

local function processedMarketReceipt(profile, receipt)
    profile.ProcessedMarketReceipts = profile.ProcessedMarketReceipts or {}
    return table.find(profile.ProcessedMarketReceipts, receipt) ~= nil
end

local function addMarketReceipt(profile, receipt)
    profile.ProcessedMarketReceipts = profile.ProcessedMarketReceipts or {}
    if not table.find(profile.ProcessedMarketReceipts, receipt) then
        table.insert(profile.ProcessedMarketReceipts, receipt)
        while #profile.ProcessedMarketReceipts > 300 do table.remove(profile.ProcessedMarketReceipts, 1) end
    end
end

local function publicJob(job, active)
    return { Id=job.Id, Name=job.Name, Category=job.Category, RequirementId=job.RequirementId,
        Quantity=job.Quantity, Reward=job.Reward, Description=job.Description,
        Active=active ~= nil, RunId=active and active.RunId or nil, AcceptedAt=active and active.AcceptedAt or nil }
end

requestRemote.OnServerInvoke = function(player, payload)
    if type(payload) ~= "table" or type(payload.action) ~= "string" then
        return { ok = false, message = "Invalid request." }
    end
    local profile = loadProfile(player)
    local action = payload.action

    -- Read-only / low-cost state calls do not consume the mutation cooldown.
    if action == "GetProfile" then
        syncWallet(player, profile)
        return responseFor(player, true, "AltheaBook profile loaded.", profile)
    elseif action == "GetFiles" then
        local copied = {}
        for _, file in ipairs(profile.Files) do
            table.insert(copied, { Id = file.Id, Name = file.Name, Type = file.Type, Content = file.Content })
        end
        return responseFor(player, true, "Files loaded.", profile, { files = copied })
    elseif action == "GetPendingAirDrops" then
        return responseFor(player, true, "Incoming AirDrop requests loaded.", profile, { requests = pendingFor(player) })
    elseif action == "DiscoverPeers" then
        return responseFor(player, true, "Nearby AltheaBook devices found.", profile, { peers = getPeers(player) })
    elseif action == "GetSupplyCatalog" then
        return responseFor(player, true, "Supply catalogue loaded.", profile, { products = copyProductCatalog() })
    elseif action == "GetMyAppRequests" then
        local requests, err = getMyAppRequests(player)
        if not requests then return fail(player, err or "Could not load app requests.", profile) end
        return responseFor(player, true, "Your requests loaded.", profile, { requests = requests })
    elseif action == "GetAppRequestsAdmin" then
        if not isAdmin(player) then return fail(player, "Administrator access required.", profile) end
        local requests, err = readAllAppRequests()
        if not requests then return fail(player, err or "Could not load requests.", profile) end
        return responseFor(player, true, "Request queue loaded.", profile, { requests = requests })
    elseif action == "GetInventory" then
        return responseFor(player, true, "Inventory loaded.", profile, { inventory = table.clone(profile.Inventory or {}) })
    elseif action == "GetOrders" then
        return responseFor(player, true, "Order history loaded.", profile, { orders = profile.Orders or {} })
    elseif action == "GetMapData" then
        return responseFor(player, true, "Map data loaded.", profile, { markers = makeMapData(player, profile) })
    elseif action == "GetTrackableRockets" then
        return responseFor(player, true, "Eligible rockets loaded.", profile, { rockets = makeTrackableRocketList(player, profile) })
    elseif action == "GetJobs" then
        syncWallet(player, profile)
        local jobs = {}
        for _, job in ipairs(JOB_CATALOG) do table.insert(jobs, publicJob(job, profile.ActiveJobs and profile.ActiveJobs[job.Id])) end
        return responseFor(player, true, "Job contracts loaded.", profile, { jobs=jobs, activeJobs=profile.ActiveJobs or {} })
    elseif action == "GetMarketListings" then
        syncWallet(player, profile)
        local listings, err = marketReadListings(player.UserId)
        if not listings then return fail(player, "Global Exchange is temporarily unavailable: " .. tostring(err), profile) end
        return responseFor(player, true, "Global listings loaded.", profile, { listings=listings, feePercent=MARKET_FEE_PERCENT })
    elseif action == "SetDevicePower" then
        local enabled = payload.enabled == true
        if enabled and profile.BatteryPercent <= 0 then
            devicePower[player] = false
            return fail(player, "Battery depleted. Charge AltheaBook before opening the desktop.", profile)
        end
        devicePower[player] = enabled
        return responseFor(player, true, enabled and "AltheaBook is powered on." or "AltheaBook is sleeping.", profile)
    end

    local now = os.clock()
    if lastRequestAt[player] and now - lastRequestAt[player] < REQUEST_COOLDOWN then
        return fail(player, "Please wait a moment before the next request.", profile)
    end
    lastRequestAt[player] = now

    if action == "AcceptJob" then
        if not profile.InstalledApps.JobBoard then return fail(player, "Mission & Jobs is not installed.", profile) end
        local jobId = cleanString(payload.jobId, 64)
        local job = jobId and JOB_BY_ID[jobId]
        if not job then return fail(player, "Unknown contract.", profile) end
        profile.ActiveJobs = profile.ActiveJobs or {}
        if profile.ActiveJobs[jobId] then return fail(player, "You already accepted this contract.", profile) end
        profile.ActiveJobs[jobId] = { RunId=HttpService:GenerateGUID(false), AcceptedAt=os.time() }
        saveProfile(player)
        return responseFor(player, true, "Contract accepted: " .. job.Name, profile)

    elseif action == "CompleteJob" then
        if not profile.InstalledApps.JobBoard then return fail(player, "Mission & Jobs is not installed.", profile) end
        local jobId = cleanString(payload.jobId, 64)
        local job = jobId and JOB_BY_ID[jobId]
        local active = job and profile.ActiveJobs and profile.ActiveJobs[jobId]
        if not job or type(active) ~= "table" or type(active.RunId) ~= "string" then return fail(player, "Accept the contract before completing it.", profile) end
        local inventoryId = job.RequirementId
        local quantity = job.Quantity
        if (profile.Inventory[inventoryId] or 0) < quantity then
            return fail(player, string.format("Need %d more units of %s.", quantity - (profile.Inventory[inventoryId] or 0), job.RequirementId), profile)
        end
        local receiptId = "job-contract:" .. active.RunId
        local paid, balance, walletErr = changePlayerCredits(player, job.Reward, receiptId)
        if paid ~= true then return fail(player, "Could not credit contract reward: " .. tostring(walletErr), profile) end
        profile.Credits = balance
        profile.Inventory[inventoryId] -= quantity
        if profile.Inventory[inventoryId] <= 0 then profile.Inventory[inventoryId] = nil end
        profile.ActiveJobs[jobId] = nil
        addMarketReceipt(profile, "job-consumed:" .. active.RunId)
        local saved = saveProfile(player)
        return responseFor(player, true, string.format("Contract complete: +%d Credits%s", job.Reward, saved and "" or " · save will retry on the next change"), profile)

    elseif action == "CreateMarketListing" then
        if not profile.InstalledApps.GlobalExchange then return fail(player, "Global Exchange is not installed.", profile) end
        if supplyTransactionLock[player.UserId] then return fail(player, "Another transaction is processing. Try again.", profile) end
        local itemId = cleanString(payload.itemId, 64)
        local item = itemId and MARKET_ITEM_BY_ID[itemId]
        local quantity = tonumber(payload.quantity)
        local unitPrice = tonumber(payload.unitPrice)
        if not item then return fail(player, "This inventory item cannot be traded on Global Exchange.", profile) end
        if not quantity or quantity % 1 ~= 0 or quantity < 1 or quantity > 999 then return fail(player, "Quantity must be an integer from 1 to 999.", profile) end
        if not unitPrice or unitPrice % 1 ~= 0 or unitPrice < 1 or unitPrice > 1000000 then return fail(player, "Unit price must be from 1 to 1,000,000 Credits.", profile) end
        if (profile.Inventory[itemId] or 0) < quantity then return fail(player, "Not enough of this item in your inventory to list it.", profile) end
        local listingId = HttpService:GenerateGUID(false)
        local listing = {
            Id=listingId, SellerUserId=player.UserId, SellerName=player.DisplayName,
            ItemId=itemId, ItemName=item.Name, Unit=item.Unit, Quantity=quantity,
            UnitPrice=math.floor(unitPrice), CreatedAt=os.time(), ExpiresAt=os.time()+MARKET_LISTING_TTL,
            Status="Open",
        }
        supplyTransactionLock[player.UserId] = true
        profile.Inventory[itemId] -= quantity
        if profile.Inventory[itemId] <= 0 then profile.Inventory[itemId] = nil end
        if not saveProfile(player) then
            profile.Inventory[itemId] = (profile.Inventory[itemId] or 0) + quantity
            supplyTransactionLock[player.UserId] = nil
            return fail(player, "Could not save inventory escrow; listing was not created.", profile)
        end
        local updatedBook, err = updateMarketBook(function(book)
            local openCount = 0
            for _, old in ipairs(book) do
                if old.Status == "Open" and (tonumber(old.ExpiresAt) or 0) > os.time() then openCount += 1 end
            end
            if openCount >= MAX_OPEN_MARKET_LISTINGS then return book end
            table.insert(book, listing)
            -- Bound the single-key order book to prevent unbounded DataStore growth.
            local pruned = {}
            for _, old in ipairs(book) do
                local recent = (tonumber(old.CreatedAt) or os.time()) > os.time() - 30*24*60*60
                if old.Status == "Open" or old.Status == "Reserved" or recent then table.insert(pruned, old) end
            end
            while #pruned > 600 do
                local removable
                for i, old in ipairs(pruned) do
                    if old.Status ~= "Open" and old.Status ~= "Reserved" then removable = i break end
                end
                if removable then table.remove(pruned, removable) else break end
            end
            return pruned
        end)
        supplyTransactionLock[player.UserId] = nil
        if not updatedBook then
            -- Refund the escrow in the current profile. If persistence is temporarily unavailable, keep the runtime state consistent and report it.
            profile.Inventory[itemId] = (profile.Inventory[itemId] or 0) + quantity
            saveProfile(player)
            return fail(player, "Global Exchange could not save the listing: " .. tostring(err), profile)
        end
        local savedListing = findMarketListing(updatedBook, listingId)
        if not savedListing then
            profile.Inventory[itemId] = (profile.Inventory[itemId] or 0) + quantity
            saveProfile(player)
            return fail(player, "Global Exchange is full. Your item was returned.", profile)
        end
        return responseFor(player, true, "Listing created and item escrowed in Global Exchange.", profile, { listing=publicMarketListing(savedListing) })

    elseif action == "CancelMarketListing" then
        local listingId = cleanString(payload.listingId, 80)
        if not listingId then return fail(player, "Select a listing first.", profile) end
        local book, err = updateMarketBook(function(items)
            local listing = findMarketListing(items, listingId)
            if not listing or listing.SellerUserId ~= player.UserId then return items end
            if listing.Status == "Open" then listing.Status = "Returning"; listing.UpdatedAt = os.time() end
            return items
        end)
        if not book then return fail(player, "Could not update listing: " .. tostring(err), profile) end
        local listing = findMarketListing(book, listingId)
        if not listing or listing.SellerUserId ~= player.UserId then return fail(player, "Listing not found or not owned by you.", profile) end
        if listing.Status == "Cancelled" then return responseFor(player, true, "Listing was already cancelled.", profile) end
        if listing.Status ~= "Returning" then return fail(player, "Only open listings can be cancelled.", profile) end
        local receipt = "market-return:" .. listingId
        if not processedMarketReceipt(profile, receipt) then
            profile.Inventory[listing.ItemId] = (profile.Inventory[listing.ItemId] or 0) + listing.Quantity
            addMarketReceipt(profile, receipt)
        end
        if not saveProfile(player) then return fail(player, "Item return is pending persistence. Retry Cancel on this listing.", profile) end
        local finalBook, finalErr = updateMarketBook(function(items)
            local current = findMarketListing(items, listingId)
            if current and current.SellerUserId == player.UserId and current.Status == "Returning" then current.Status = "Cancelled"; current.UpdatedAt = os.time() end
            return items
        end)
        if not finalBook then return fail(player, "Item returned; listing status will be reconciled on retry: " .. tostring(finalErr), profile) end
        return responseFor(player, true, "Listing cancelled and items returned.", profile)

    elseif action == "BuyMarketListing" then
        if not profile.InstalledApps.GlobalExchange then return fail(player, "Global Exchange is not installed.", profile) end
        local listingId = cleanString(payload.listingId, 80)
        if not listingId then return fail(player, "Select a listing first.", profile) end
        local book, err = updateMarketBook(function(items)
            local listing = findMarketListing(items, listingId)
            if not listing then return items end
            if listing.Status == "Open" and (tonumber(listing.ExpiresAt) or 0) > os.time() and listing.SellerUserId ~= player.UserId then
                listing.Status = "Reserved"; listing.BuyerUserId = player.UserId; listing.ReservedAt = os.time()
            end
            return items
        end)
        if not book then return fail(player, "Global Exchange is unavailable: " .. tostring(err), profile) end
        local listing = findMarketListing(book, listingId)
        if not listing then return fail(player, "Listing not found or expired.", profile) end
        if listing.Status == "Sold" and listing.BuyerUserId == player.UserId then
            return responseFor(player, true, "This purchase was already completed.", profile, { duplicate=true })
        end
        if listing.Status ~= "Reserved" or listing.BuyerUserId ~= player.UserId then
            return fail(player, listing.SellerUserId == player.UserId and "You cannot buy your own listing." or "Listing is unavailable or being processed by another buyer.", profile)
        end
        if (tonumber(listing.ExpiresAt) or 0) <= os.time() then return fail(player, "Listing expired.", profile) end
        local total = listing.Quantity * listing.UnitPrice
        if total > 100000000 then return fail(player, "Listing total exceeds the transaction limit.", profile) end
        local deliveryReceipt = "market-delivery:" .. listingId
        local hasDelivered = processedMarketReceipt(profile, deliveryReceipt)
        if not hasDelivered then
            local inventoryKinds = 0
            for _ in pairs(profile.Inventory) do inventoryKinds += 1 end
            if not profile.Inventory[listing.ItemId] and inventoryKinds >= 100 then return fail(player, "Inventory item-type limit reached.", profile) end
        end
        local paid, newBalance, walletErr = changePlayerCredits(player, -total, "market-buy:" .. listingId)
        if paid ~= true then
            if paid == false then
                updateMarketBook(function(items)
                    local current = findMarketListing(items, listingId)
                    if current and current.Status == "Reserved" and current.BuyerUserId == player.UserId then current.Status = "Open"; current.BuyerUserId = nil; current.ReservedAt = nil end
                    return items
                end)
                return fail(player, "Not enough Credits to buy this listing.", profile)
            end
            return fail(player, "Wallet service unavailable; listing remains reserved for a safe retry.", profile)
        end
        profile.Credits = newBalance
        local sellerNet = total - math.floor(total * MARKET_FEE_PERCENT / 100)
        local credited, _, creditErr = changeWalletByUserId(listing.SellerUserId, sellerNet, "market-sale:" .. listingId, STARTING_CREDITS)
        if credited ~= true then
            return fail(player, "Payment is secured; seller credit is pending. Retry this listing to finish the transaction.", profile)
        end
        if not hasDelivered then
            profile.Inventory[listing.ItemId] = (profile.Inventory[listing.ItemId] or 0) + listing.Quantity
            addMarketReceipt(profile, deliveryReceipt)
        end
        if not saveProfile(player) then
            return fail(player, "Payment processed. Inventory delivery is pending save; retry this purchase to reconcile safely.", profile)
        end
        local finalBook, finalErr = updateMarketBook(function(items)
            local current = findMarketListing(items, listingId)
            if current and current.Status == "Reserved" and current.BuyerUserId == player.UserId then
                current.Status = "Sold"; current.SoldAt = os.time(); current.Total = total; current.Fee = total - sellerNet
            end
            return items
        end)
        if not finalBook then return fail(player, "Purchase delivered. Market status pending reconciliation: " .. tostring(finalErr), profile) end
        return responseFor(player, true, string.format("Purchased %d %s for %d Credits. Market fee: %d Credits.", listing.Quantity, listing.ItemName, total, total-sellerNet), profile, { orderId=listingId })

    if action == "CreateAppRequest" then
        if not profile.InstalledApps.AppRequests then return fail(player, "App Requests is not installed.", profile) end
        local now = os.clock()
        if appRequestCooldownAt[player.UserId] and now - appRequestCooldownAt[player.UserId] < 30 then
            return fail(player, "Please wait before submitting another request.", profile)
        end
        local name = cleanString(payload.name, 60)
        local category = cleanString(payload.category, 24)
        local description = cleanString(payload.description, 600)
        local intendedUse = cleanString(payload.intendedUse or "", 300) or ""
        local validCategories = {Science=true, Engineering=true, Navigation=true, Commerce=true, Productivity=true, Other=true}
        if not name or #name < 3 then return fail(player, "App name must contain at least 3 characters.", profile) end
        if not category or not validCategories[category] then return fail(player, "Select a valid request category.", profile) end
        if not description or #description < 8 then return fail(player, "Description must contain at least 8 characters.", profile) end
        local requestRecord = {
            Id=HttpService:GenerateGUID(false), UserId=player.UserId, Username=player.Name,
            DisplayName=player.DisplayName, Name=name, Category=category, Description=description,
            IntendedUse=intendedUse, Status="Submitted", ReviewMessage="Awaiting review.", CreatedAt=os.time(),
        }
        local ok, err = pcall(function()
            appRequestsStore:UpdateAsync("all", function(old)
                old = type(old) == "table" and old or {}
                table.insert(old, requestRecord)
                while #old > 500 do table.remove(old, 1) end
                return old
            end)
        end)
        if not ok then
            warn("AltheaOS app request save failed:", err)
            return fail(player, "Could not save request. Check DataStore access and Output.", profile)
        end
        appRequestCooldownAt[player.UserId] = now
        return responseFor(player, true, "Request submitted. ID: " .. requestRecord.Id, profile, { requestId=requestRecord.Id })

    elseif action == "UpdateAppRequestStatus" then
        if not isAdmin(player) then return fail(player, "Administrator access required.", profile) end
        local requestId = cleanString(payload.requestId, 80)
        local status = cleanString(payload.status, 24)
        local reviewMessage = cleanString(payload.reviewMessage or "", 240) or ""
        if not requestId or not status or not APP_REQUEST_STATUSES[status] then return fail(player, "Invalid request ID or status.", profile) end
        local found = false
        local ok, err = pcall(function()
            appRequestsStore:UpdateAsync("all", function(old)
                old = type(old) == "table" and old or {}
                for _, item in ipairs(old) do
                    if item.Id == requestId then
                        item.Status = status
                        item.ReviewMessage = reviewMessage
                        item.ReviewedBy = player.UserId
                        item.UpdatedAt = os.time()
                        found = true
                        break
                    end
                end
                return old
            end)
        end)
        if not ok then return fail(player, "Could not update request status.", profile) end
        if not found then return fail(player, "Request not found.", profile) end
        return responseFor(player, true, "Request status updated.", profile)

    elseif action == "CheckoutSupply" then
        if not profile.InstalledApps.AltheaSupply then return fail(player, "Althea Supply is not installed.", profile) end
        if supplyTransactionLock[player.UserId] then return fail(player, "Another order is being processed. Try again.", profile) end
        local requestId = cleanString(payload.requestId, 80)
        if not requestId or #requestId < 8 then return fail(player, "Invalid checkout request ID.", profile) end
        for _, priorOrder in ipairs(profile.Orders or {}) do
            if priorOrder.RequestId == requestId then
                return responseFor(player, true, "This checkout was already processed.", profile, { order=priorOrder, duplicate=true })
            end
        end
        if table.find(profile.ProcessedOrderIds or {}, requestId) then
            return responseFor(player, true, "This checkout was already processed; no additional Credits were charged.", profile, { duplicate=true })
        end
        if type(payload.items) ~= "table" or #payload.items < 1 or #payload.items > 12 then
            return fail(player, "Cart must contain between 1 and 12 product types.", profile)
        end
        local normalized, requestedById, total, itemCount = {}, {}, 0, 0
        for _, entry in ipairs(payload.items) do
            if type(entry) ~= "table" then return fail(player, "Invalid cart item.", profile) end
            local productId = cleanString(entry.productId, 64)
            local quantity = tonumber(entry.quantity)
            local product = productId and SUPPLY_CATALOG[productId] or nil
            if not product or not quantity or quantity % 1 ~= 0 or quantity < 1 or quantity > 99 then
                return fail(player, "Cart contains an unavailable product or invalid quantity.", profile)
            end
            if requestedById[productId] then return fail(player, "Duplicate cart rows are not allowed.", profile) end
            requestedById[productId] = quantity
            itemCount += quantity
            if itemCount > 200 then return fail(player, "Order quantity limit is 200 items.", profile) end
            if (supplyStock[productId] or 0) < quantity then return fail(player, "Not enough stock for " .. product.Name .. ".", profile) end
            total += product.Price * quantity
            table.insert(normalized, { ProductId=productId, Name=product.Name, Quantity=quantity, UnitPrice=product.Price, Unit=product.Unit })
        end
        for _, entry in ipairs(normalized) do
            local inventoryId = SUPPLY_CATALOG[entry.ProductId].InventoryId
            if not profile.Inventory[inventoryId] and (function() local n=0; for _ in pairs(profile.Inventory) do n+=1 end; return n end)() >= 100 then
                return fail(player, "Inventory has reached its maximum number of item types.", profile)
            end
        end
        supplyTransactionLock[player.UserId] = true
        local paid, latestBalance, walletErr = changePlayerCredits(player, -total, "supply-order:" .. requestId)
        if paid ~= true then
            supplyTransactionLock[player.UserId] = nil
            return fail(player, paid == false and "Not enough Credits for this order." or ("Wallet unavailable: " .. tostring(walletErr)), profile)
        end
        profile.Credits = latestBalance
        for _, entry in ipairs(normalized) do
            supplyStock[entry.ProductId] -= entry.Quantity
            local inventoryId = SUPPLY_CATALOG[entry.ProductId].InventoryId
            profile.Inventory[inventoryId] = (profile.Inventory[inventoryId] or 0) + entry.Quantity
        end
        local order = {
            OrderId=HttpService:GenerateGUID(false), RequestId=requestId,
            CreatedAt=os.time(), Status="Delivered", Total=total, Items=normalized,
            Delivery="Player Inventory",
        }
        table.insert(profile.Orders, 1, order)
        while #profile.Orders > 30 do table.remove(profile.Orders) end
        table.insert(profile.ProcessedOrderIds, requestId)
        while #profile.ProcessedOrderIds > 50 do table.remove(profile.ProcessedOrderIds, 1) end
        saveProfile(player)
        supplyTransactionLock[player.UserId] = nil
        return responseFor(player, true, string.format("Order %s delivered to Inventory · %d Credits charged.", order.OrderId, total), profile, { order=order, inventory=table.clone(profile.Inventory) })

    elseif action == "InstallAltheaTag" then
        if not profile.InstalledApps.AltheaTag then return fail(player, "AltheaTag app is not installed.", profile) end
        local rocketId = cleanString(payload.rocketId, 80)
        if not rocketId then return fail(player, "Select a rocket first.", profile) end
        local target = findOwnedRocket(player, rocketId)
        if not target then return fail(player, "Rocket not found, not owned by you, or missing RocketId/OwnerUserId attributes.", profile) end
        if findTracker(profile, rocketId) or target.Object:GetAttribute("AltheaTagTrackerId") then
            return fail(player, "This rocket already has a tracking beacon.", profile)
        end
        if (profile.Inventory.AltheaTagDevice or 0) < 1 then return fail(player, "Buy an AltheaTag Device in Althea Supply first.", profile) end
        if #profile.Trackers >= 30 then return fail(player, "Tracker limit reached.", profile) end
        local trackerId = HttpService:GenerateGUID(false)
        target.Object:SetAttribute("AltheaTagTrackerId", trackerId)
        profile.Inventory.AltheaTagDevice -= 1
        local pos = target.Position
        table.insert(profile.Trackers, {
            TrackerId=trackerId, RocketId=rocketId,
            RocketName=cleanString(target.Object:GetAttribute("RocketName") or target.Object.Name, 64) or "Rocket",
            LastPosition={X=pos.X,Y=pos.Y,Z=pos.Z}, LastSeenAt=os.time(), State="LIVE",
        })
        saveProfile(player)
        return responseFor(player, true, "AltheaTag installed on " .. rocketId .. ".", profile)

    elseif action == "RemoveAltheaTag" then
        local rocketId = cleanString(payload.rocketId, 80)
        local tracker, index = nil, nil
        if rocketId then tracker, index = findTracker(profile, rocketId) end
        if not tracker or not index then return fail(player, "No tracker found for this rocket.", profile) end
        local target = findOwnedRocket(player, rocketId)
        if target and target.Object:GetAttribute("AltheaTagTrackerId") == tracker.TrackerId then
            target.Object:SetAttribute("AltheaTagTrackerId", nil)
        end
        table.remove(profile.Trackers, index)
        profile.Inventory.AltheaTagDevice = (profile.Inventory.AltheaTagDevice or 0) + 1
        saveProfile(player)
        return responseFor(player, true, "AltheaTag removed and returned to Inventory.", profile)

    elseif action == "InstallApp" then
        local appId = payload.appId
        local item = type(appId) == "string" and APP_CATALOG[appId] or nil
        if not item or item.Status ~= "Available" then return fail(player, "This app is not available in the store.", profile) end
        if item.SystemApp then return fail(player, "This system app is already managed by AltheaOS.", profile) end
        if profile.InstalledApps[appId] then return responseFor(player, true, appId .. " is already installed.", profile) end
        if getStorageUsed(profile) + item.SizeMB > STORAGE_CAPACITY_MB then
            return fail(player, "Not enough device storage. Remove an app before installing this one.", profile)
        end
        local paid, balance, walletErr = changePlayerCredits(player, -item.Price, "app-install:" .. appId)
        if paid ~= true then return fail(player, paid == false and ("Not enough Credits to install " .. appId .. ".") or ("Wallet unavailable: " .. tostring(walletErr)), profile) end
        profile.Credits = balance
        profile.InstalledApps[appId] = true
        local saved = saveProfile(player)
        return responseFor(player, true, string.format("%s installed · %d MB storage used.%s", appId, getStorageUsed(profile), saved and "" or " · Save pending; retry GetProfile later"), profile)

    elseif action == "UninstallApp" then
        local appId = payload.appId
        local item = type(appId) == "string" and APP_CATALOG[appId] or nil
        if not item then return fail(player, "This app cannot be removed.", profile) end
        if item.Protected then return fail(player, "System apps cannot be uninstalled.", profile) end
        if not profile.InstalledApps[appId] then return fail(player, "This app is not installed.", profile) end
        profile.InstalledApps[appId] = nil
        saveProfile(player)
        return responseFor(player, true, appId .. " removed from this device.", profile)

    elseif action == "UpgradeRAM" then
        local targetLevel = tonumber(payload.targetLevel)
        if not targetLevel or targetLevel % 1 ~= 0 then return fail(player, "Invalid RAM upgrade level.", profile) end
        targetLevel = math.floor(targetLevel)
        local target = RAM_TIERS[targetLevel]
        if not target then return fail(player, "That RAM tier is not available.", profile) end
        if targetLevel <= profile.RAMLevel then return fail(player, "This RAM tier is already owned.", profile) end
        if targetLevel ~= profile.RAMLevel + 1 then return fail(player, "Install the next RAM tier before upgrading further.", profile) end
        local paid, balance, walletErr = changePlayerCredits(player, -target.Price, "ram-upgrade:" .. tostring(targetLevel))
        if paid ~= true then return fail(player, paid == false and "Not enough Credits for this RAM upgrade." or ("Wallet unavailable: " .. tostring(walletErr)), profile) end
        profile.Credits = balance
        profile.RAMLevel = targetLevel
        saveProfile(player)
        return responseFor(player, true, "AltheaBook upgraded to " .. target.Name .. " RAM.", profile)

    elseif action == "UsePowerCell" then
        local cost = 75
        if profile.BatteryPercent >= 100 then return fail(player, "Battery is already fully charged.", profile) end
        local paid, balance, walletErr = changePlayerCredits(player, -cost, "power-cell:" .. HttpService:GenerateGUID(false))
        if paid ~= true then return fail(player, paid == false and "A Power Cell costs 75 Credits." or ("Wallet unavailable: " .. tostring(walletErr)), profile) end
        profile.Credits = balance
        profile.BatteryPercent = math.min(100, profile.BatteryPercent + 25)
        saveProfile(player)
        lastSavedBattery[player] = profile.BatteryPercent
        return responseFor(player, true, "Power Cell used. Battery charged by up to 25%.", profile)

    elseif action == "UpdateSettings" then
        local key = payload.key
        local value = payload.value
        if key == "Wallpaper" then
            if value ~= "Orbit" and value ~= "Aurora" and value ~= "Midnight" and value ~= "Dawn" then
                return fail(player, "Unsupported wallpaper.", profile)
            end
            profile.Settings.Wallpaper = value
        elseif key == "DockAutoHide" or key == "ReducedMotion" or key == "ShowBatteryPercent" then
            if type(value) ~= "boolean" then return fail(player, "Invalid setting value.", profile) end
            profile.Settings[key] = value
        elseif key == "AirDropMode" then
            if value ~= "Everyone" and value ~= "Off" then return fail(player, "AirDrop mode must be Everyone or Off.", profile) end
            profile.Settings.AirDropMode = value
        elseif key == "DeviceName" then
            local name = cleanString(value, 24)
            if not name or #name < 2 then return fail(player, "Device name must contain 2–24 characters.", profile) end
            profile.Settings.DeviceName = name
        else
            return fail(player, "Unknown or protected system setting.", profile)
        end
        saveProfile(player)
        return responseFor(player, true, key .. " updated.", profile)

    elseif action == "CreateFile" then
        local name = cleanString(payload.name, 64)
        local content = cleanString(payload.content, MAX_FILE_CONTENT)
        if not name or #name < 1 then return fail(player, "Enter a file name.", profile) end
        if not content then return fail(player, "File contents are invalid.", profile) end
        if #profile.Files >= MAX_FILES then return fail(player, "File limit reached. Delete a file first.", profile) end
        local additionalMB = math.max(1, math.ceil(#content / (1024 * 1024)))
        if getStorageUsed(profile) + additionalMB > STORAGE_CAPACITY_MB then return fail(player, "Not enough device storage.", profile) end
        local file = { Id = HttpService:GenerateGUID(false), Name = name, Type = "text/plain", Content = content }
        table.insert(profile.Files, file)
        saveProfile(player)
        return responseFor(player, true, name .. " saved to My Files.", profile, { fileId = file.Id })

    elseif action == "DeleteFile" then
        local fileId = cleanString(payload.fileId, 80)
        local _, index = findFile(profile, fileId)
        if not index then return fail(player, "File not found on this device.", profile) end
        local removed = table.remove(profile.Files, index)
        saveProfile(player)
        return responseFor(player, true, removed.Name .. " deleted.", profile)

    elseif action == "SendAirDrop" then
        if not profile.InstalledApps.AirDrop then return fail(player, "AirDrop is not installed.", profile) end
        local targetUserId = tonumber(payload.targetUserId)
        local fileId = cleanString(payload.fileId, 80)
        if not targetUserId or not fileId then return fail(player, "Choose a nearby device and file.", profile) end
        local target = Players:GetPlayerByUserId(targetUserId)
        if not target or target == player then return fail(player, "The selected device is unavailable.", profile) end
        if playerDistance(player, target) > AIRDROP_RANGE then return fail(player, "Move closer to the receiving AltheaBook.", profile) end
        local targetProfile = loadProfile(target)
        if not targetProfile.InstalledApps.AirDrop then return fail(player, "The receiving device does not have AirDrop enabled.", profile) end
        if targetProfile.Settings.AirDropMode == "Off" then return fail(player, "The receiving device has AirDrop turned off.", profile) end
        local file = findFile(profile, fileId)
        if not file then return fail(player, "That file is no longer on this device.", profile) end
        pendingAirDrops[target.UserId] = pendingAirDrops[target.UserId] or {}
        local requests = pendingAirDrops[target.UserId]
        if #requests >= 6 then return fail(player, "The receiving device has too many pending transfers.", profile) end
        table.insert(requests, {
            Id = HttpService:GenerateGUID(false),
            SenderUserId = player.UserId,
            SenderName = player.DisplayName,
            CreatedAt = os.time(),
            File = { Id = file.Id, Name = file.Name, Type = file.Type, Content = file.Content },
        })
        return responseFor(player, true, "AirDrop request sent to " .. target.DisplayName .. ". They must accept the file.", profile)

    elseif action == "RespondAirDrop" then
        local requestId = cleanString(payload.requestId, 80)
        local accept = payload.accept == true
        local requests = pendingAirDrops[player.UserId] or {}
        local foundIndex, request = nil, nil
        for index, item in ipairs(requests) do
            if item.Id == requestId then foundIndex, request = index, item break end
        end
        if not request then return fail(player, "This AirDrop request expired or was already handled.", profile) end
        table.remove(requests, foundIndex)
        if not accept then return responseFor(player, true, "AirDrop declined.", profile) end
        if os.time() - (request.CreatedAt or os.time()) > 60 then return fail(player, "This AirDrop request expired.", profile) end
        local sender = Players:GetPlayerByUserId(request.SenderUserId)
        if not sender or playerDistance(player, sender) > AIRDROP_RANGE then
            return fail(player, "Sender is no longer nearby. The file was not received.", profile)
        end
        if #profile.Files >= MAX_FILES then return fail(player, "Not enough file slots on this device.", profile) end
        local content = cleanString(request.File.Content, MAX_FILE_CONTENT) or ""
        local additionalMB = math.max(1, math.ceil(#content / (1024 * 1024)))
        if getStorageUsed(profile) + additionalMB > STORAGE_CAPACITY_MB then return fail(player, "Not enough device storage.", profile) end
        local name = cleanString(request.File.Name, 64) or "Shared File.txt"
        local duplicate = false
        for _, existing in ipairs(profile.Files) do
            if existing.Name == name then duplicate = true break end
        end
        if duplicate then name = string.sub(name, 1, 54) .. " (AirDrop).txt" end
        table.insert(profile.Files, {
            Id = HttpService:GenerateGUID(false), Name = name,
            Type = cleanString(request.File.Type, 40) or "text/plain", Content = content,
        })
        saveProfile(player)
        return responseFor(player, true, "Received " .. name .. " from " .. request.SenderName .. ".", profile)
    end

    return fail(player, "Unknown AltheaBook request.", profile)
end

-- Server-owned battery simulation. Place a BasePart named AltheaCharger or
-- AltheaChargingStation (or tag it AltheaCharger) in Workspace to create a real charging zone.
task.spawn(function()
    while true do
        task.wait(BATTERY_STEP_SECONDS)
        for player, profile in pairs(profiles) do
            if player.Parent == Players and profile then
                local oldBattery = profile.BatteryPercent or 100
                local connected = nearCharger(player)
                if connected then
                    local rate = devicePower[player] and BATTERY_CHARGE_ON_PER_MINUTE or BATTERY_CHARGE_OFF_PER_MINUTE
                    profile.BatteryPercent = math.min(100, oldBattery + rate * BATTERY_STEP_SECONDS / 60)
                elseif devicePower[player] then
                    profile.BatteryPercent = math.max(0, oldBattery - BATTERY_DRAIN_PER_MINUTE * BATTERY_STEP_SECONDS / 60)
                end
                profile.BatteryPercent = math.floor(profile.BatteryPercent * 10 + 0.5) / 10
                if profile.BatteryPercent <= 0 then
                    profile.BatteryPercent = 0
                    devicePower[player] = false
                end
                local saveAt = lastBatterySaveAt[player] or 0
                local lastSaved = lastSavedBattery[player] or oldBattery
                if math.abs(profile.BatteryPercent - lastSaved) >= 3 and os.clock() - saveAt >= 90 then
                    if saveProfile(player) then
                        lastSavedBattery[player] = profile.BatteryPercent
                        lastBatterySaveAt[player] = os.clock()
                    end
                end
            end
        end
    end
end)

Players.PlayerAdded:Connect(function(player)
    loadProfile(player)
end)
for _, player in ipairs(Players:GetPlayers()) do task.spawn(loadProfile, player) end
Players.PlayerRemoving:Connect(function(player)
    saveProfile(player)
    profiles[player] = nil
    persistenceState[player] = nil
    lastRequestAt[player] = nil
    devicePower[player] = nil
    appRequestCooldownAt[player.UserId] = nil
    supplyTransactionLock[player.UserId] = nil
    pendingAirDrops[player.UserId] = nil
    lastSavedBattery[player] = nil
    lastBatterySaveAt[player] = nil
end)
game:BindToClose(function()
    for _, player in ipairs(Players:GetPlayers()) do saveProfile(player) end
end)
