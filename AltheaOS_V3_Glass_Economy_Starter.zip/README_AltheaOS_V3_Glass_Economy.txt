ALTHEABOOK / ALTHEAOS V3 — GLASS + ECONOMY STARTER

FILES
- AltheaBook_Full_WindowManager_V3_Glass.lua: full replacement for AltheaOSWindowManager ModuleScript.
- AltheaBook_Full_Server_V3_Economy.lua: full replacement for AltheaBookServer Script; adds a ServerStorage-only reward bridge and reward receipt ledger to the existing V2 server.
- AltheaEconomy_Integration_Examples.txt: sample server-side calls from trusted rocket/mining/water/power systems.
- AltheaOS_V3_Economy_GlobalMarket_Design.txt: data sync notes, economy plan, and safe global exchange architecture.

INSTALL
1. Stop Play Test and back up your place.
2. Replace the existing AltheaOSWindowManager ModuleScript with the contents of AltheaBook_Full_WindowManager_V3_Glass.lua. Keep it in the same folder as AltheaBookClient, because the client requires script.Parent:WaitForChild("AltheaOSWindowManager").
3. Replace the existing AltheaBookServer Script with AltheaBook_Full_Server_V3_Economy.lua. There must be only one active AltheaBookServer Script.
4. Keep the existing AltheaBookClient V2 and AltheaAppRegistry V2 for this patch. This patch does not create the Job Board UI or the production Global Exchange UI yet.
5. In trusted server-side gameplay scripts, call ServerStorage.AltheaEconomyBridge:Invoke(player, "AwardReward", {rewardId=..., receiptId=...}) only after a real objective is validated on the server. See examples.
6. Stop and Play again; inspect View > Output.

REWARD IDS
RocketLaunchOrbit, RocketPayloadDelivered, ExplorationMilestone, MiningContractSmall, MiningContractRareOre, WaterTreatmentBatch, WaterProductionBatch, PowerProductionBatch.

NOT YET IMPLEMENTED
- Player-visible Job Board UI and contract acceptance/progress persistence.
- A production-ready global exchange. Existing V2 Althea Supply stock is per live server; the design notes explain the required cross-server persistence and transaction journal.
- Server-side profile session locks and full wallet/inventory transaction refactor. Do not enable cross-server player trading yet.

ROBLOX STUDIO TESTS
- Test in a separate published test experience.
- Enable Studio Access to API Services only on the test experience for DataStore tests.
- Test duplicate reward receipts and check that they do not award twice.
- Confirm glass styling works on wide and narrow viewports.
- This code has not been executed inside Roblox Studio in this environment.
