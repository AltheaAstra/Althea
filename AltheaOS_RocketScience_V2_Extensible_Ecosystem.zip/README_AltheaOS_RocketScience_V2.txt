# AltheaBook / AltheaOS — Rocket Science V2 (Extensible Ecosystem)

This is a best-effort development version based on the three Lua source files provided in the conversation. It adds a shared App Registry, player App Requests, Althea Supply ordering into per-player inventory, a 2D X/Z world map, and AltheaTag tracking for owned, tagged rockets. It also updates existing UI colors toward simulated blue Glassmorphism.

## Roblox Studio installation

1. Stop Play Test.
2. Use `Model > Advanced > Insert from File` to import `AltheaAppRegistry_V2.rbxmx`, then move `AltheaAppRegistry` into `ReplicatedStorage`.
3. Import `AltheaOS_StarterPlayer_V2.rbxmx`, then move the `AltheaBookOS` Folder into `StarterPlayer > StarterPlayerScripts`.
4. Import `AltheaBookServer_V2.rbxmx`, then move `AltheaBookServer` into `ServerScriptService`.
5. Keep one existing `AltheaBook` Tool in `StarterPack`. The Tool's LocalScript should signal `PlayerScripts.AltheaBookControl` with `open`/`close`/`toggle` as in the existing version. Do not keep two copies of the OS or server.
6. Publish the experience and enable Studio API access for persistence tests. Avoid testing against live production data.
7. Stop and Play again; open AltheaBook, then use the Dock to open App Requests, Althea Supply, AltheaMap, and AltheaTag.

## New features

- Shared `AltheaAppRegistry` is the public metadata source for client catalog and server app validation.
- `App Requests`: submit feature requests; limited to one submission per 30 seconds. Requests use DataStore `AltheaAppRequests_v1`, key `all`, capped to the latest 500.
- `Althea Supply`: product catalog, cart, server-validated checkout, Credits deduction, inventory delivery, and recent order history.
- `AltheaMap`: 2D projection of public map markers and the player's own tracked rockets using world X/Z coordinates.
- `AltheaTag`: buy a tracker in Supply, then install it on a rocket that is owned by the player and tagged `AltheaRocket` (or `AltheaTrackable`).
- V2 blue glass treatment uses transparency, rounded corners, strokes, and gradients. Roblox cannot blur a GUI behind another GUI, so this is simulated glass rather than true GUI backdrop blur.

## Map marker setup

Tag a `BasePart` or `Model` with `AltheaMapMarker` using CollectionService. Optional Attributes:
- `MapId` (string)
- `MapLabel` (string)
- `MapCategory` (string; examples: Base, Launch Site, Resource, Charger)
- `MapDescription` (string)
- `PublicMapMarker` (boolean; set false to exclude it)

The map currently auto-projects all returned markers into a relative X/Z view. It is not a planetary map projection and does not assume that all worlds share one coordinate frame.

## Rocket tracking setup

For a rocket `Model` or `BasePart`:
- Add CollectionService tag `AltheaRocket` (or `AltheaTrackable`).
- Set Attribute `RocketId` to a unique string.
- Set Attribute `OwnerUserId` to the owning player's numeric UserId. `OwnerTeam` matching a player's team is an alternative, but `OwnerUserId` is recommended.
- Optional Attributes: `RocketName`, `FuelPercent`, `FlightStage`, `MissionStatus` (telemetry expansion later).

Open Althea Supply and buy an `AltheaTag Device`; then open AltheaTag and click INSTALL on the owned rocket. The tag is stored as `AltheaTagTrackerId` on the server-owned target. Map shows a live marker while the rocket exists; if it disappears, a last-known marker remains based on the last refresh.

## Known V2 limitations — be explicit

- Supply stock is tracked in the current server process. It resets on server restart and is not globally shared across different Roblox servers yet. Replace it with a global stock service before launching a cross-server economy.
- Checkout delivers products directly into player inventory and records status `Delivered`. Warehouse routing, shipping duration, refunds, and physical inventory integration are extension points, not implemented in V2.
- App Request status updates have an admin-only server action. To grant administrators, add trusted numeric UserIds to `ADMIN_USER_IDS` in the server script. The experience owner is auto-admin when the experience is user-owned.
- AltheaTag only integrates with rocket objects explicitly tagged and attributed as documented. Existing rocket systems must set ownership and RocketId attributes. It does not automatically infer ownership or rocket fuel/stage values.
- The map uses world X/Z relative projection, not a polished planet surface renderer.
- This code has not been run inside Roblox Studio in this environment. Test in a private published test experience and inspect View > Output before shipping.
