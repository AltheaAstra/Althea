-- AltheaOS Shared App Registry v2
-- Place this ModuleScript in ReplicatedStorage as AltheaAppRegistry.
-- Public metadata only. Server validates all purchases and permissions independently.
local Registry = {}
Registry.Version = 2

Registry.Apps = {
    { Id="AppStore", WindowName="App Store", Name="App Store", Icon="▦", Category="System", Version="1.0.0", Price=0, SizeMB=150, RamMB=180, Protected=true, SystemApp=true, Status="Available", Description="Discover, install, and manage AltheaOS applications." },
    { Id="PeriodicTable", WindowName="Periodic Table", Name="Periodic Table", Icon="⚛", Category="Science", Version="1.0.0", Price=0, SizeMB=220, RamMB=460, Protected=true, SystemApp=true, Status="Available", Description="Explore all 118 elements and their properties." },
    { Id="SpaceHub", WindowName="Space Hub", Name="Space Hub", Icon="🚀", Category="Navigation", Version="1.0.0", Price=0, SizeMB=180, RamMB=320, Protected=false, SystemApp=false, Status="Available", Description="Mission overview, discoveries, and exploration status." },
    { Id="ResearchLab", WindowName="Research Lab", Name="Research Lab", Icon="⚗", Category="Science", Version="1.0.0", Price=250, SizeMB=450, RamMB=900, Protected=false, SystemApp=false, Status="Available", Description="Workspace for experiments and science records." },
    { Id="ResourceDatabase", WindowName="Resource Database", Name="Resource Database", Icon="▤", Category="Science", Version="1.0.0", Price=150, SizeMB=360, RamMB=520, Protected=false, SystemApp=false, Status="Available", Description="Track elements, minerals, compounds, and stored resources." },
    { Id="Blueprints", WindowName="Blueprints", Name="Blueprints", Icon="▧", Category="Engineering", Version="1.0.0", Price=200, SizeMB=320, RamMB=620, Protected=false, SystemApp=false, Status="Available", Description="Save and manage rocket and spacecraft designs." },
    { Id="MyFiles", WindowName="My Files", Name="My Files", Icon="📁", Category="Productivity", Version="1.0.0", Price=0, SizeMB=100, RamMB=240, Protected=true, SystemApp=true, Status="Available", Description="Your personal mission notes and saved files." },
    { Id="Settings", WindowName="Settings", Name="Settings", Icon="⚙", Category="System", Version="1.0.0", Price=0, SizeMB=80, RamMB=160, Protected=true, SystemApp=true, Status="Available", Description="Personalize wallpaper, Dock behavior, accessibility, and device name." },
    { Id="Battery", WindowName="Battery", Name="Battery", Icon="▰", Category="System", Version="1.0.0", Price=0, SizeMB=60, RamMB=140, Protected=true, SystemApp=true, Status="Available", Description="Monitor device battery and charging." },
    { Id="AirDrop", WindowName="AirDrop", Name="AirDrop", Icon="↗", Category="Communication", Version="1.0.0", Price=0, SizeMB=110, RamMB=180, Protected=true, SystemApp=true, Status="Available", Description="Share files securely with nearby AltheaBook devices." },
    { Id="SpectrumLab", WindowName="Spectrum Lab", Name="Spectrum Lab", Icon="🌈", Category="Science", Version="1.0.0", Price=350, SizeMB=480, RamMB=1150, Protected=false, SystemApp=false, Status="Available", Description="Analyze light spectra, wavelength, and intensity." },
    { Id="MaterialWorkbench", WindowName="Material Workbench", Name="Material Workbench", Icon="🧪", Category="Engineering", Version="1.0.0", Price=200, SizeMB=400, RamMB=720, Protected=false, SystemApp=false, Status="Available", Description="Explore materials, compositions, alloys, and recipes." },
    { Id="AppRequests", WindowName="App Requests", Name="App Requests", Icon="✉", Category="Productivity", Version="1.0.0", Price=0, SizeMB=90, RamMB=220, Protected=true, SystemApp=true, Status="Available", Description="Suggest applications and features for future AltheaOS updates." },
    { Id="AltheaSupply", WindowName="Althea Supply", Name="Althea Supply", Icon="🛒", Category="Commerce", Version="1.0.0", Price=0, SizeMB=240, RamMB=360, Protected=true, SystemApp=true, Status="Available", Description="Order in-game materials, engineering parts, and tracking devices." },
    { Id="AltheaMap", WindowName="AltheaMap", Name="AltheaMap", Icon="🗺", Category="Navigation", Version="1.0.0", Price=0, SizeMB=260, RamMB=440, Protected=true, SystemApp=true, Status="Available", Description="Explore map markers, bases, resources, and tracked rockets." },
    { Id="AltheaTag", WindowName="AltheaTag", Name="AltheaTag", Icon="📡", Category="Navigation", Version="1.0.0", Price=0, SizeMB=150, RamMB=260, Protected=true, SystemApp=true, Status="Available", Description="Install and manage rocket tracking beacons." },
}

local byId, byWindow = {}, {}
for _, app in ipairs(Registry.Apps) do
    assert(type(app.Id) == "string" and not byId[app.Id], "Duplicate AltheaOS AppId: " .. tostring(app.Id))
    byId[app.Id] = app
    byWindow[app.WindowName] = app
end

function Registry.GetById(id)
    return byId[id]
end

function Registry.GetByWindowName(name)
    return byWindow[name]
end

function Registry.GetStoreCatalog()
    local result = {}
    for _, app in ipairs(Registry.Apps) do
        if app.Id ~= "AppStore" and app.Status ~= "Hidden" then
            table.insert(result, table.clone(app))
        end
    end
    return result
end

return Registry
