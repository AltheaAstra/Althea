-- AltheaBook Full System Server
-- Install in ServerScriptService. The server owns persistent Credits, apps, RAM,
-- battery state, system preferences, device files, and AirDrop transfers.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DataStoreService = game:GetService("DataStoreService")
local HttpService = game:GetService("HttpService")
local CollectionService = game:GetService("CollectionService")

local DATASTORE_NAME = "AltheaBookProfile_v1"
local STORAGE_CAPACITY_MB = 32768
local STARTING_CREDITS = 1200
local REQUEST_COOLDOWN = 0.18
local MAX_FILES = 35
local MAX_FILE_CONTENT = 6000
local AIRDROP_RANGE = 80
local CHARGER_RANGE = 15
local BATTERY_STEP_SECONDS = 10
local BATTERY_DRAIN_PER_MINUTE = 1.5
local BATTERY_CHARGE_ON_PER_MINUTE = 0.8
local BATTERY_CHARGE_OFF_PER_MINUTE = 4.0

local APP_CATALOG = {
    PeriodicTable = { Price = 0, SizeMB = 220, Protected = true },
    SpaceHub = { Price = 0, SizeMB = 180, Protected = false },
    ResearchLab = { Price = 250, SizeMB = 450, Protected = false },
    ResourceDatabase = { Price = 150, SizeMB = 360, Protected = false },
    Blueprints = { Price = 200, SizeMB = 320, Protected = false },
    MyFiles = { Price = 0, SizeMB = 100, Protected = false },
    Settings = { Price = 0, SizeMB = 80, Protected = true },
    Battery = { Price = 0, SizeMB = 60, Protected = true },
    AirDrop = { Price = 0, SizeMB = 110, Protected = true },
    SpectrumLab = { Price = 350, SizeMB = 480, Protected = false },
    MaterialWorkbench = { Price = 200, SizeMB = 400, Protected = false },
}

local RAM_TIERS = {
    [1] = { CapacityMB = 4096, Price = 0, Name = "4 GB" },
    [2] = { CapacityMB = 8192, Price = 350, Name = "8 GB" },
    [3] = { CapacityMB = 16384, Price = 800, Name = "16 GB" },
    [4] = { CapacityMB = 32768, Price = 1800, Name = "32 GB" },
}

local DEFAULT_SETTINGS = {
    Wallpaper = "Orbit",
    DockAutoHide = true,
    ReducedMotion = false,
    ShowBatteryPercent = true,
    AirDropMode = "Everyone",
    DeviceName = "AltheaBook",
}

local store = DataStoreService:GetDataStore(DATASTORE_NAME)
local profiles, lastRequestAt, devicePower = {}, {}, {}
local pendingAirDrops = {}
local savingAvailable = true
local lastSavedBattery, lastBatterySaveAt = {}, {}

local remotes = ReplicatedStorage:FindFirstChild("AltheaBookRemotes")
if not remotes then
    remotes = Instance.new("Folder")
    remotes.Name = "AltheaBookRemotes"
    remotes.Parent = ReplicatedStorage
end
local requestRemote = remotes:FindFirstChild("Request")
if not requestRemote then
    requestRemote = Instance.new("RemoteFunction")
    requestRemote.Name = "Request"
    requestRemote.Parent = remotes
end

local function defaultFiles()
    return {
        {
            Id = "welcome_note",
            Name = "Welcome to AltheaBook.txt",
            Type = "text/plain",
            Content = "Welcome to AltheaBook.\n\nUse App Store to install apps. Use Settings to personalize your desktop.\nUse AirDrop to share files with nearby explorers.",
        },
        {
            Id = "rocket_science_notes",
            Name = "Rocket Science Notes.txt",
            Type = "text/plain",
            Content = "Rocket Science notebook\n\nElements -> Materials -> Resources -> Refining -> Reactions -> Rocket manufacturing.\n\nExample: water electrolysis produces hydrogen and oxygen in a 2:1 molecular ratio.",
        },
    }
end

local function defaultProfile()
    local settings = table.clone(DEFAULT_SETTINGS)
    return {
        Version = 2,
        Credits = STARTING_CREDITS,
        InstalledApps = {
            AppStore = true,
            PeriodicTable = true,
            Settings = true,
            Battery = true,
            AirDrop = true,
            MyFiles = true,
        },
        RAMLevel = 1,
        BatteryPercent = 100,
        Settings = settings,
        Files = defaultFiles(),
    }
end

local function cloneDict(source)
    local result = {}
    if type(source) == "table" then
        for key, value in pairs(source) do
            if type(key) == "string" and value == true then result[key] = true end
        end
    end
    return result
end

local function cleanString(value, maxLength)
    if type(value) ~= "string" then return nil end
    value = value:gsub("\r\n", "\n"):gsub("\r", "\n")
    value = value:gsub("[%z\1-\8\11\12\14-\31]", "")
    if #value > maxLength then value = string.sub(value, 1, maxLength) end
    return value
end

local function normalizeSettings(raw)
    local result = table.clone(DEFAULT_SETTINGS)
    if type(raw) ~= "table" then return result end
    if raw.Wallpaper == "Orbit" or raw.Wallpaper == "Aurora" or raw.Wallpaper == "Midnight" or raw.Wallpaper == "Dawn" then
        result.Wallpaper = raw.Wallpaper
    end
    if type(raw.DockAutoHide) == "boolean" then result.DockAutoHide = raw.DockAutoHide end
    if type(raw.ReducedMotion) == "boolean" then result.ReducedMotion = raw.ReducedMotion end
    if type(raw.ShowBatteryPercent) == "boolean" then result.ShowBatteryPercent = raw.ShowBatteryPercent end
    if raw.AirDropMode == "Everyone" or raw.AirDropMode == "Off" then result.AirDropMode = raw.AirDropMode end
    local deviceName = cleanString(raw.DeviceName, 24)
    if deviceName and #deviceName > 0 then result.DeviceName = deviceName end
    return result
end

local function normalizeFiles(rawFiles, defaultsIfMissing)
    if type(rawFiles) ~= "table" then
        return defaultsIfMissing and defaultFiles() or {}
    end
    local files = {}
    for _, rawFile in ipairs(rawFiles) do
        if #files >= MAX_FILES then break end
        if type(rawFile) == "table" then
            local id = cleanString(rawFile.Id, 80)
            local name = cleanString(rawFile.Name, 64)
            local content = cleanString(rawFile.Content, MAX_FILE_CONTENT)
            local fileType = cleanString(rawFile.Type or "text/plain", 40) or "text/plain"
            if id and name and content and #name > 0 then
                table.insert(files, { Id = id, Name = name, Type = fileType, Content = content })
            end
        end
    end
    return files
end

local function normalizeProfile(raw)
    local profile = defaultProfile()
    if type(raw) == "table" then
        if type(raw.Credits) == "number" and raw.Credits >= 0 then profile.Credits = math.floor(raw.Credits) end
        if type(raw.RAMLevel) == "number" then profile.RAMLevel = math.clamp(math.floor(raw.RAMLevel), 1, #RAM_TIERS) end
        if type(raw.BatteryPercent) == "number" then profile.BatteryPercent = math.clamp(raw.BatteryPercent, 0, 100) end
        profile.Settings = normalizeSettings(raw.Settings)
        profile.Files = normalizeFiles(raw.Files, raw.Files == nil)
        profile.InstalledApps = cloneDict(raw.InstalledApps)
        profile.InstalledApps.AppStore = true
        profile.InstalledApps.PeriodicTable = true
        profile.InstalledApps.Settings = true
        profile.InstalledApps.Battery = true
        profile.InstalledApps.AirDrop = true
        profile.InstalledApps.MyFiles = true
        for appId in pairs(profile.InstalledApps) do
            if appId ~= "AppStore" and not APP_CATALOG[appId] then profile.InstalledApps[appId] = nil end
        end
    end
    return profile
end

local function getFileStorageMB(profile)
    local usedMB = 0
    for _, file in ipairs(profile.Files or {}) do
        -- File packages consume at least 1 MB in the virtual file system.
        usedMB += math.max(1, math.ceil(#(file.Content or "") / (1024 * 1024)))
    end
    return usedMB
end

local function getStorageUsed(profile)
    local used = 150 -- App Store system package
    for appId, installed in pairs(profile.InstalledApps) do
        if installed and appId ~= "AppStore" then
            local item = APP_CATALOG[appId]
            if item then used += item.SizeMB end
        end
    end
    used += getFileStorageMB(profile)
    return used
end

local function rootPart(player)
    local character = player.Character
    return character and character:FindFirstChild("HumanoidRootPart") or nil
end

local function isChargerPart(part)
    return part:IsA("BasePart") and (
        part.Name == "AltheaCharger"
        or part.Name == "AltheaChargingStation"
        or CollectionService:HasTag(part, "AltheaCharger")
    )
end

-- Cache charger parts instead of scanning the whole Workspace on every status request.
local chargerParts = {}
for _, item in ipairs(workspace:GetDescendants()) do
    if isChargerPart(item) then chargerParts[item] = true end
end
workspace.DescendantAdded:Connect(function(item)
    if item:IsA("BasePart") and isChargerPart(item) then chargerParts[item] = true end
end)
workspace.DescendantRemoving:Connect(function(item)
    chargerParts[item] = nil
end)
CollectionService:GetInstanceAddedSignal("AltheaCharger"):Connect(function(item)
    if item:IsA("BasePart") then chargerParts[item] = true end
end)
CollectionService:GetInstanceRemovedSignal("AltheaCharger"):Connect(function(item)
    if item:IsA("BasePart") and item.Name ~= "AltheaCharger" and item.Name ~= "AltheaChargingStation" then
        chargerParts[item] = nil
    end
end)

local function nearCharger(player)
    local root = rootPart(player)
    if not root then return false end
    for item in pairs(chargerParts) do
        if item.Parent and item:IsDescendantOf(workspace) and (root.Position - item.Position).Magnitude <= CHARGER_RANGE then
            return true
        end
    end
    return false
end

local function findFile(profile, fileId)
    for index, file in ipairs(profile.Files) do
        if file.Id == fileId then return file, index end
    end
    return nil, nil
end

local function playerDistance(a, b)
    local rootA, rootB = rootPart(a), rootPart(b)
    if not rootA or not rootB then return math.huge end
    return (rootA.Position - rootB.Position).Magnitude
end

local function publicProfile(player, profile)
    local ram = RAM_TIERS[profile.RAMLevel] or RAM_TIERS[1]
    local isCharging = nearCharger(player) and profile.BatteryPercent < 100
    return {
        Version = profile.Version or 2,
        Credits = profile.Credits,
        InstalledApps = cloneDict(profile.InstalledApps),
        RAMLevel = profile.RAMLevel,
        RamCapacityMB = ram.CapacityMB,
        RamName = ram.Name,
        StorageCapacityMB = STORAGE_CAPACITY_MB,
        StorageUsedMB = getStorageUsed(profile),
        BatteryPercent = math.floor(profile.BatteryPercent * 10 + 0.5) / 10,
        BatteryCharging = isCharging,
        Settings = table.clone(profile.Settings),
        FileCount = #profile.Files,
        DeviceName = profile.Settings.DeviceName,
    }
end

local function loadProfile(player)
    if profiles[player] then return profiles[player] end
    local loaded
    local ok, result = pcall(function()
        return store:GetAsync("u_" .. tostring(player.UserId))
    end)
    if ok then
        loaded = result
    else
        savingAvailable = false
        warn("AltheaBook: DataStore load failed; using session profile. Enable API Services for persistent saves.", result)
    end
    local profile = normalizeProfile(loaded)
    profiles[player] = profile
    lastSavedBattery[player] = profile.BatteryPercent
    lastBatterySaveAt[player] = os.clock()
    return profile
end

local function saveProfile(player)
    local profile = profiles[player]
    if not profile or not savingAvailable then return false end
    local ok, err = pcall(function()
        store:SetAsync("u_" .. tostring(player.UserId), profile)
    end)
    if not ok then
        savingAvailable = false
        warn("AltheaBook: DataStore save failed. Changes remain for this server session only:", err)
    end
    return ok
end

local function responseFor(player, ok, message, profile, extra)
    local response = {
        ok = ok,
        message = message,
        profile = publicProfile(player, profile),
        persistent = savingAvailable,
    }
    if type(extra) == "table" then
        for key, value in pairs(extra) do response[key] = value end
    end
    return response
end

local function fail(player, message, profile, extra)
    return responseFor(player, false, message, profile, extra)
end

local function getPeers(player)
    local result = {}
    for _, target in ipairs(Players:GetPlayers()) do
        if target ~= player then
            local distance = playerDistance(player, target)
            if distance <= AIRDROP_RANGE then
                table.insert(result, {
                    UserId = target.UserId,
                    Name = target.DisplayName,
                    Username = target.Name,
                    Distance = math.floor(distance + 0.5),
                    DeviceName = profiles[target] and profiles[target].Settings.DeviceName or "AltheaBook",
                })
            end
        end
    end
    table.sort(result, function(a, b) return a.Distance < b.Distance end)
    return result
end

local function pendingFor(player)
    local list = pendingAirDrops[player.UserId] or {}
    local visible = {}
    local now = os.time()
    for index = #list, 1, -1 do
        if now - (list[index].CreatedAt or now) > 60 then table.remove(list, index) end
    end
    for _, request in ipairs(list) do
        table.insert(visible, {
            Id = request.Id,
            SenderUserId = request.SenderUserId,
            SenderName = request.SenderName,
            FileName = request.File.Name,
            FileType = request.File.Type,
        })
    end
    return visible
end

requestRemote.OnServerInvoke = function(player, payload)
    if type(payload) ~= "table" or type(payload.action) ~= "string" then
        return { ok = false, message = "Invalid request." }
    end
    local profile = loadProfile(player)
    local action = payload.action

    -- Read-only / low-cost state calls do not consume the mutation cooldown.
    if action == "GetProfile" then
        return responseFor(player, true, "AltheaBook profile loaded.", profile)
    elseif action == "GetFiles" then
        local copied = {}
        for _, file in ipairs(profile.Files) do
            table.insert(copied, { Id = file.Id, Name = file.Name, Type = file.Type, Content = file.Content })
        end
        return responseFor(player, true, "Files loaded.", profile, { files = copied })
    elseif action == "GetPendingAirDrops" then
        return responseFor(player, true, "Incoming AirDrop requests loaded.", profile, { requests = pendingFor(player) })
    elseif action == "DiscoverPeers" then
        return responseFor(player, true, "Nearby AltheaBook devices found.", profile, { peers = getPeers(player) })
    elseif action == "SetDevicePower" then
        local enabled = payload.enabled == true
        if enabled and profile.BatteryPercent <= 0 then
            devicePower[player] = false
            return fail(player, "Battery depleted. Charge AltheaBook before opening the desktop.", profile)
        end
        devicePower[player] = enabled
        return responseFor(player, true, enabled and "AltheaBook is powered on." or "AltheaBook is sleeping.", profile)
    end

    local now = os.clock()
    if lastRequestAt[player] and now - lastRequestAt[player] < REQUEST_COOLDOWN then
        return fail(player, "Please wait a moment before the next request.", profile)
    end
    lastRequestAt[player] = now

    if action == "InstallApp" then
        local appId = payload.appId
        local item = type(appId) == "string" and APP_CATALOG[appId] or nil
        if not item then return fail(player, "This app is not available in the store.", profile) end
        if profile.InstalledApps[appId] then return responseFor(player, true, appId .. " is already installed.", profile) end
        if profile.Credits < item.Price then return fail(player, "Not enough Credits to install " .. appId .. ".", profile) end
        if getStorageUsed(profile) + item.SizeMB > STORAGE_CAPACITY_MB then
            return fail(player, "Not enough device storage. Remove an app before installing this one.", profile)
        end
        profile.Credits -= item.Price
        profile.InstalledApps[appId] = true
        saveProfile(player)
        return responseFor(player, true, string.format("%s installed · %d MB storage used.", appId, getStorageUsed(profile)), profile)

    elseif action == "UninstallApp" then
        local appId = payload.appId
        local item = type(appId) == "string" and APP_CATALOG[appId] or nil
        if not item then return fail(player, "This app cannot be removed.", profile) end
        if item.Protected then return fail(player, "System apps cannot be uninstalled.", profile) end
        if not profile.InstalledApps[appId] then return fail(player, "This app is not installed.", profile) end
        profile.InstalledApps[appId] = nil
        saveProfile(player)
        return responseFor(player, true, appId .. " removed from this device.", profile)

    elseif action == "UpgradeRAM" then
        local targetLevel = tonumber(payload.targetLevel)
        if not targetLevel or targetLevel % 1 ~= 0 then return fail(player, "Invalid RAM upgrade level.", profile) end
        targetLevel = math.floor(targetLevel)
        local target = RAM_TIERS[targetLevel]
        if not target then return fail(player, "That RAM tier is not available.", profile) end
        if targetLevel <= profile.RAMLevel then return fail(player, "This RAM tier is already owned.", profile) end
        if targetLevel ~= profile.RAMLevel + 1 then return fail(player, "Install the next RAM tier before upgrading further.", profile) end
        if profile.Credits < target.Price then return fail(player, "Not enough Credits for this RAM upgrade.", profile) end
        profile.Credits -= target.Price
        profile.RAMLevel = targetLevel
        saveProfile(player)
        return responseFor(player, true, "AltheaBook upgraded to " .. target.Name .. " RAM.", profile)

    elseif action == "UsePowerCell" then
        local cost = 75
        if profile.BatteryPercent >= 100 then return fail(player, "Battery is already fully charged.", profile) end
        if profile.Credits < cost then return fail(player, "A Power Cell costs 75 Credits.", profile) end
        profile.Credits -= cost
        profile.BatteryPercent = math.min(100, profile.BatteryPercent + 25)
        saveProfile(player)
        lastSavedBattery[player] = profile.BatteryPercent
        return responseFor(player, true, "Power Cell used. Battery charged by up to 25%.", profile)

    elseif action == "UpdateSettings" then
        local key = payload.key
        local value = payload.value
        if key == "Wallpaper" then
            if value ~= "Orbit" and value ~= "Aurora" and value ~= "Midnight" and value ~= "Dawn" then
                return fail(player, "Unsupported wallpaper.", profile)
            end
            profile.Settings.Wallpaper = value
        elseif key == "DockAutoHide" or key == "ReducedMotion" or key == "ShowBatteryPercent" then
            if type(value) ~= "boolean" then return fail(player, "Invalid setting value.", profile) end
            profile.Settings[key] = value
        elseif key == "AirDropMode" then
            if value ~= "Everyone" and value ~= "Off" then return fail(player, "AirDrop mode must be Everyone or Off.", profile) end
            profile.Settings.AirDropMode = value
        elseif key == "DeviceName" then
            local name = cleanString(value, 24)
            if not name or #name < 2 then return fail(player, "Device name must contain 2–24 characters.", profile) end
            profile.Settings.DeviceName = name
        else
            return fail(player, "Unknown or protected system setting.", profile)
        end
        saveProfile(player)
        return responseFor(player, true, key .. " updated.", profile)

    elseif action == "CreateFile" then
        local name = cleanString(payload.name, 64)
        local content = cleanString(payload.content, MAX_FILE_CONTENT)
        if not name or #name < 1 then return fail(player, "Enter a file name.", profile) end
        if not content then return fail(player, "File contents are invalid.", profile) end
        if #profile.Files >= MAX_FILES then return fail(player, "File limit reached. Delete a file first.", profile) end
        local additionalMB = math.max(1, math.ceil(#content / (1024 * 1024)))
        if getStorageUsed(profile) + additionalMB > STORAGE_CAPACITY_MB then return fail(player, "Not enough device storage.", profile) end
        local file = { Id = HttpService:GenerateGUID(false), Name = name, Type = "text/plain", Content = content }
        table.insert(profile.Files, file)
        saveProfile(player)
        return responseFor(player, true, name .. " saved to My Files.", profile, { fileId = file.Id })

    elseif action == "DeleteFile" then
        local fileId = cleanString(payload.fileId, 80)
        local _, index = findFile(profile, fileId)
        if not index then return fail(player, "File not found on this device.", profile) end
        local removed = table.remove(profile.Files, index)
        saveProfile(player)
        return responseFor(player, true, removed.Name .. " deleted.", profile)

    elseif action == "SendAirDrop" then
        if not profile.InstalledApps.AirDrop then return fail(player, "AirDrop is not installed.", profile) end
        local targetUserId = tonumber(payload.targetUserId)
        local fileId = cleanString(payload.fileId, 80)
        if not targetUserId or not fileId then return fail(player, "Choose a nearby device and file.", profile) end
        local target = Players:GetPlayerByUserId(targetUserId)
        if not target or target == player then return fail(player, "The selected device is unavailable.", profile) end
        if playerDistance(player, target) > AIRDROP_RANGE then return fail(player, "Move closer to the receiving AltheaBook.", profile) end
        local targetProfile = loadProfile(target)
        if not targetProfile.InstalledApps.AirDrop then return fail(player, "The receiving device does not have AirDrop enabled.", profile) end
        if targetProfile.Settings.AirDropMode == "Off" then return fail(player, "The receiving device has AirDrop turned off.", profile) end
        local file = findFile(profile, fileId)
        if not file then return fail(player, "That file is no longer on this device.", profile) end
        pendingAirDrops[target.UserId] = pendingAirDrops[target.UserId] or {}
        local requests = pendingAirDrops[target.UserId]
        if #requests >= 6 then return fail(player, "The receiving device has too many pending transfers.", profile) end
        table.insert(requests, {
            Id = HttpService:GenerateGUID(false),
            SenderUserId = player.UserId,
            SenderName = player.DisplayName,
            CreatedAt = os.time(),
            File = { Id = file.Id, Name = file.Name, Type = file.Type, Content = file.Content },
        })
        return responseFor(player, true, "AirDrop request sent to " .. target.DisplayName .. ". They must accept the file.", profile)

    elseif action == "RespondAirDrop" then
        local requestId = cleanString(payload.requestId, 80)
        local accept = payload.accept == true
        local requests = pendingAirDrops[player.UserId] or {}
        local foundIndex, request = nil, nil
        for index, item in ipairs(requests) do
            if item.Id == requestId then foundIndex, request = index, item break end
        end
        if not request then return fail(player, "This AirDrop request expired or was already handled.", profile) end
        table.remove(requests, foundIndex)
        if not accept then return responseFor(player, true, "AirDrop declined.", profile) end
        if os.time() - (request.CreatedAt or os.time()) > 60 then return fail(player, "This AirDrop request expired.", profile) end
        local sender = Players:GetPlayerByUserId(request.SenderUserId)
        if not sender or playerDistance(player, sender) > AIRDROP_RANGE then
            return fail(player, "Sender is no longer nearby. The file was not received.", profile)
        end
        if #profile.Files >= MAX_FILES then return fail(player, "Not enough file slots on this device.", profile) end
        local content = cleanString(request.File.Content, MAX_FILE_CONTENT) or ""
        local additionalMB = math.max(1, math.ceil(#content / (1024 * 1024)))
        if getStorageUsed(profile) + additionalMB > STORAGE_CAPACITY_MB then return fail(player, "Not enough device storage.", profile) end
        local name = cleanString(request.File.Name, 64) or "Shared File.txt"
        local duplicate = false
        for _, existing in ipairs(profile.Files) do
            if existing.Name == name then duplicate = true break end
        end
        if duplicate then name = string.sub(name, 1, 54) .. " (AirDrop).txt" end
        table.insert(profile.Files, {
            Id = HttpService:GenerateGUID(false), Name = name,
            Type = cleanString(request.File.Type, 40) or "text/plain", Content = content,
        })
        saveProfile(player)
        return responseFor(player, true, "Received " .. name .. " from " .. request.SenderName .. ".", profile)
    end

    return fail(player, "Unknown AltheaBook request.", profile)
end

-- Server-owned battery simulation. Place a BasePart named AltheaCharger or
-- AltheaChargingStation (or tag it AltheaCharger) in Workspace to create a real charging zone.
task.spawn(function()
    while true do
        task.wait(BATTERY_STEP_SECONDS)
        for player, profile in pairs(profiles) do
            if player.Parent == Players and profile then
                local oldBattery = profile.BatteryPercent or 100
                local connected = nearCharger(player)
                if connected then
                    local rate = devicePower[player] and BATTERY_CHARGE_ON_PER_MINUTE or BATTERY_CHARGE_OFF_PER_MINUTE
                    profile.BatteryPercent = math.min(100, oldBattery + rate * BATTERY_STEP_SECONDS / 60)
                elseif devicePower[player] then
                    profile.BatteryPercent = math.max(0, oldBattery - BATTERY_DRAIN_PER_MINUTE * BATTERY_STEP_SECONDS / 60)
                end
                profile.BatteryPercent = math.floor(profile.BatteryPercent * 10 + 0.5) / 10
                if profile.BatteryPercent <= 0 then
                    profile.BatteryPercent = 0
                    devicePower[player] = false
                end
                local saveAt = lastBatterySaveAt[player] or 0
                local lastSaved = lastSavedBattery[player] or oldBattery
                if math.abs(profile.BatteryPercent - lastSaved) >= 3 and os.clock() - saveAt >= 90 then
                    if saveProfile(player) then
                        lastSavedBattery[player] = profile.BatteryPercent
                        lastBatterySaveAt[player] = os.clock()
                    end
                end
            end
        end
    end
end)

Players.PlayerAdded:Connect(function(player)
    loadProfile(player)
end)
for _, player in ipairs(Players:GetPlayers()) do task.spawn(loadProfile, player) end
Players.PlayerRemoving:Connect(function(player)
    saveProfile(player)
    profiles[player] = nil
    lastRequestAt[player] = nil
    devicePower[player] = nil
    pendingAirDrops[player.UserId] = nil
    lastSavedBattery[player] = nil
    lastBatterySaveAt[player] = nil
end)
game:BindToClose(function()
    for _, player in ipairs(Players:GetPlayers()) do saveProfile(player) end
end)
