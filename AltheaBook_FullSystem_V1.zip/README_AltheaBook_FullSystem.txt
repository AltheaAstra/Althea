ALTHEABOOK FULL SYSTEM V1 — OS, BATTERY, SETTINGS, MY FILES, AIRDROP, APP STORE, RAM

WHAT IS INCLUDED
- AltheaBook desktop with a macOS-inspired top menu bar, live clock, clickable battery status, traffic-light window controls and auto-hide Dock.
- Apps open only when the player chooses them; registered apps share one window manager.
- App Store with server-authoritative installs/uninstalls and RAM upgrades (4/8/16/32 GB simulation).
- Settings: Orbit/Aurora/Midnight/Dawn wallpaper, Dock auto-hide, Reduced Motion, battery percentage, AirDrop receiving on/off, and device name editor (press Enter to save).
- Battery: drains while desktop is on, charges near a Workspace charger part, and can use a 25% Power Cell for 75 Credits.
- My Files: create, list, and delete small text notes saved to the player's DataStore profile.
- AirDrop: discovers players within 80 studs; sender selects a file; receiver must accept within 60 seconds and still be nearby.
- All player data saved through DataStore on the server when API services are enabled.

IMPORT INTO ROBLOX STUDIO
1. Stop the running test.
2. Import AltheaBook_FullSystem.rbxmx using Workspace > Insert from File.
3. Move the imported AltheaBookOS folder to StarterPlayer > StarterPlayerScripts.
4. Import AltheaBook_FullServer.rbxmx and move AltheaBookServer into ServerScriptService.
5. Keep exactly ONE AltheaBook Tool in StarterPack. If you already have the Tool from the previous package, keep that and do not add another copy.
6. Disable/delete all older AltheaBook OS LocalScripts, old Window Managers, and old Server scripts. Only one client OS and one server authority must run.
7. Publish the experience and enable Game Settings > Security > Enable Studio Access to API Services for persistent data while testing in Studio.
8. Stop and Play again. Equip the AltheaBook Tool to open the desktop. The GUI starts hidden until the Tool is used.

BATTERY / CHARGING
- Add a Part to Workspace and name it exactly AltheaCharger or AltheaChargingStation.
- Make it anchored and visible or embed it inside a charging station model. Players charge when their HumanoidRootPart is within 15 studs.
- You can also tag a BasePart with CollectionService tag "AltheaCharger".
- Battery drains at 1.5 percentage points per minute while OS is on away from a charger.
- At a charger, charging is 0.8%/minute while powered on and 4%/minute while sleeping.
- Battery starts at 100%. Battery depletion forces the OS to sleep at the next client sync.
- Power Cell charges up to +25% for 75 in-game Credits.

AIRDROP
- Both sender and receiver must be in the same Roblox server, have AirDrop installed, and be within 80 studs.
- Receiver opens AirDrop and accepts or declines the transfer. Requests expire in 60 seconds. Settings > AirDrop Receiving can be set to Off to reject incoming transfers.
- Text file content is capped at 6,000 characters; the profile holds up to 35 files.
- AirDrop is a game feature, not an actual Apple AirDrop implementation.

NOTES / LIMITATIONS
- AltheaOS uses original AltheaBook branding and a macOS-inspired interaction pattern, not Apple's proprietary assets or actual macOS.
- RAM/SSD/battery are gameplay simulations; they do not change real PC memory or hardware.
- The GUI and server scripts were generated and statically inspected but not executed in Roblox Studio here. Test with View > Output before shipping.
- To change the default Credits, edit STARTING_CREDITS in AltheaBook_Full_Server.lua. This version keeps the existing AltheaBookProfile_v1 DataStore name so earlier Credits/RAM/app profiles can be normalized into the extended profile format.
