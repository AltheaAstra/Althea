ALTHEA OS WINDOW MANAGER — ROBLOX INSTALLATION

FILES
1) AltheaOSWindowManager.lua
   Paste the full file into a ModuleScript named exactly:
   ReplicatedStorage > AltheaOSWindowManager

2) RocketSciencePeriodicTable_AltheaOS.lua
   Use this as the replacement LocalScript in:
   StarterPlayer > StarterPlayerScripts
   Disable/delete the older RocketSciencePeriodicTable LocalScript so it doesn't create a duplicate GUI.

FEATURES
- Shared app tabs across the top; horizontal scrolling when there are many tabs.
- App launcher (+) that can open registered windows even when another modal window is open.
- Only one registered app window is visible at a time, avoiding app-window overlap.
- Modal dim shield plus a BlurEffect on the local player's 3D world for important windows.
- Drag window by its header, minimize, maximize/restore, resize from bottom-right, close with X, or close active window with Escape.
- Closing an app removes its tab; the app can be opened again from its launcher button.

REGISTER A FUTURE APP
In the app's LocalScript, require the same ModuleScript and use the same PlayerGui:

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local manager = require(ReplicatedStorage:WaitForChild("AltheaOSWindowManager"))
    .new(Players.LocalPlayer:WaitForChild("PlayerGui"))

manager:RegisterWindow("Research Lab", researchWindow, {
    Header = researchWindow:WaitForChild("Header"),
    CloseButton = researchWindow.Header:WaitForChild("CloseButton"),
    Modal = true,
    BlurSize = 16,
})

researchOpenButton.Activated:Connect(function()
    manager:OpenWindow("Research Lab")
end)

For a regular non-modal window set Modal = false. Every app should register its main Frame through this manager to participate in shared tabs and avoid overlapping other registered apps.

BLUR NOTE
Roblox's native BlurEffect blurs the 3D game world, not 2D GuiObjects. The modal shield dims/blocks other ScreenGui layers underneath. To manage all app interfaces consistently, register future apps with this manager and keep their ScreenGui DisplayOrder below AltheaOS_Shell (DisplayOrder 1000).

TESTING
This code was created as source files but has not been executed inside Roblox Studio in this environment. Test using Play mode and check View > Output for any project-specific conflicts.
