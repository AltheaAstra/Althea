-- AltheaBook Tool Client
-- Put this LocalScript inside the AltheaBook Tool in StarterPack.
-- Tool activation opens the desktop only; clicking the GUI will not keep toggling it.

local Players = game:GetService("Players")
local player = Players.LocalPlayer
local tool = script.Parent
local playerScripts = player:WaitForChild("PlayerScripts")
local control = playerScripts:WaitForChild("AltheaBookControl")

local isEquipped = false
local hasOpened = false

tool.Equipped:Connect(function()
    isEquipped = true
end)

tool.Activated:Connect(function()
    if not isEquipped then
        return
    end
    -- Only open if closed. GUI button clicks must never accidentally close the OS.
    control:Fire("open")
    hasOpened = true
end)

tool.Unequipped:Connect(function()
    isEquipped = false
    if hasOpened then
        control:Fire("close")
        hasOpened = false
    end
end)
