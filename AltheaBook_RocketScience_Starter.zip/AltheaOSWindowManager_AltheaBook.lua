-- AltheaBook / AltheaOS Window Manager
-- Place as ReplicatedStorage > ModuleScript named AltheaOSWindowManager.
-- The OS stays completely hidden until the player equips and activates AltheaBook.

local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")
local UserInputService = game:GetService("UserInputService")
local GuiService = game:GetService("GuiService")
local TweenService = game:GetService("TweenService")

local WindowManager = {}
WindowManager.__index = WindowManager

local managerCache = setmetatable({}, { __mode = "k" })

local COLORS = {
    bar = Color3.fromRGB(14, 20, 30),
    barStroke = Color3.fromRGB(60, 78, 98),
    tab = Color3.fromRGB(25, 35, 49),
    tabActive = Color3.fromRGB(38, 57, 75),
    text = Color3.fromRGB(238, 243, 249),
    muted = Color3.fromRGB(154, 170, 188),
    accent = Color3.fromRGB(222, 190, 126),
    danger = Color3.fromRGB(210, 91, 91),
    button = Color3.fromRGB(31, 43, 59),
}

local function make(className, parent, props)
    local object = Instance.new(className)
    for key, value in pairs(props or {}) do
        object[key] = value
    end
    object.Parent = parent
    return object
end

local function addCorner(parent, radius)
    return make("UICorner", parent, { CornerRadius = UDim.new(0, radius or 8) })
end

local function addStroke(parent, color, thickness, transparency)
    return make("UIStroke", parent, {
        Color = color or COLORS.barStroke,
        Thickness = thickness or 1,
        Transparency = transparency or 0,
    })
end

local function setZTree(guiObject, zIndex, depth)
    depth = depth or 0
    guiObject.ZIndex = zIndex + depth
    for _, child in ipairs(guiObject:GetChildren()) do
        if child:IsA("GuiObject") then
            setZTree(child, zIndex, depth + 1)
        end
    end
end

local function getViewportSize()
    local camera = workspace.CurrentCamera
    if camera then
        return camera.ViewportSize
    end
    return Vector2.new(1280, 720)
end

local function getTopLeftInset()
    local ok, inset = pcall(function()
        local topLeft = GuiService:GetGuiInset()
        return topLeft
    end)
    if ok and typeof(inset) == "Vector2" then
        return inset
    end
    return Vector2.new(0, 0)
end

local function isPointerBegin(input)
    return input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch
end

function WindowManager.new(playerGui)
    playerGui = playerGui or Players.LocalPlayer:WaitForChild("PlayerGui")

    if managerCache[playerGui] then
        return managerCache[playerGui]
    end

    -- Remove stale shell/effect from earlier script versions so duplicated UI or blur cannot remain stuck.
    local staleShell = playerGui:FindFirstChild("AltheaOS_Shell")
    if staleShell then
        staleShell:Destroy()
    end
    local currentCamera = workspace.CurrentCamera
    if currentCamera then
        local staleBlur = currentCamera:FindFirstChild("AltheaOS_LocalBlur")
        if staleBlur and staleBlur:IsA("BlurEffect") then
            staleBlur:Destroy()
        end
    end
    local staleLightingBlur = Lighting:FindFirstChild("AltheaOS_LocalBlur")
    if staleLightingBlur and staleLightingBlur:IsA("BlurEffect") then
        staleLightingBlur:Destroy()
    end

    local self = setmetatable({}, WindowManager)
    self.playerGui = playerGui
    self.windows = {}
    self.openOrder = {}
    self.registeredOrder = {}
    self.activeName = nil
    self.minimized = {}
    self.dockVisible = false
    self.dockPinned = false
    self.desktopOpen = false
    self._dockHideToken = 0
    self._dockTween = nil
    self.maximized = {}
    self.interaction = nil

    local screenGui = make("ScreenGui", playerGui, {
        Name = "AltheaOS_Shell",
        ResetOnSpawn = false,
        -- Keep controls in Roblox's safe UI area and never attempt to hide CoreGui.
        IgnoreGuiInset = false,
        DisplayOrder = 1000,
        ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
        Enabled = false, -- IMPORTANT: no OS GUI appears until the laptop is activated.
    })
    self.screenGui = screenGui

    -- Cinematic, procedural space wallpaper. No uploaded image asset is required.
    self.wallpaper = make("Frame", screenGui, {
        Name = "AltheaOS_Wallpaper",
        Size = UDim2.fromScale(1, 1),
        Position = UDim2.fromScale(0, 0),
        BackgroundColor3 = Color3.fromRGB(11, 19, 38),
        BorderSizePixel = 0,
        ZIndex = 1,
        Active = false,
    })
    make("UIGradient", self.wallpaper, {
        Rotation = 28,
        Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(18, 37, 67)),
            ColorSequenceKeypoint.new(0.48, Color3.fromRGB(22, 31, 56)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(8, 13, 25)),
        }),
    })
    local planet = make("Frame", self.wallpaper, {
        Name = "BluePlanetGlow",
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(0.79, 0, 0.34, 0),
        Size = UDim2.fromOffset(330, 330),
        BackgroundColor3 = Color3.fromRGB(42, 96, 158),
        BackgroundTransparency = 0.32,
        BorderSizePixel = 0,
        ZIndex = 1,
    })
    addCorner(planet, 200)
    make("UIGradient", planet, {
        Rotation = 35,
        Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(99, 158, 216)),
            ColorSequenceKeypoint.new(0.55, Color3.fromRGB(45, 90, 151)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(25, 35, 79)),
        }),
    })
    local horizon = make("Frame", self.wallpaper, {
        Name = "DistantHorizon",
        Position = UDim2.new(0, 0, 0.77, 0),
        Size = UDim2.new(1, 0, 0.23, 0),
        BackgroundColor3 = Color3.fromRGB(8, 14, 28),
        BackgroundTransparency = 0.14,
        BorderSizePixel = 0,
        ZIndex = 1,
    })
    make("UIGradient", horizon, {
        Rotation = 90,
        Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(27, 44, 70)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(6, 10, 20)),
        }),
    })
    local stars = {
        {0.06,0.14,2},{0.12,0.33,1},{0.18,0.11,2},{0.24,0.24,1},{0.30,0.08,1},
        {0.37,0.18,2},{0.43,0.09,1},{0.51,0.27,1},{0.58,0.12,2},{0.64,0.22,1},
        {0.71,0.08,1},{0.84,0.12,1},{0.91,0.27,2},{0.96,0.09,1},{0.08,0.51,1},
        {0.17,0.62,1},{0.29,0.47,1},{0.40,0.54,1},{0.55,0.48,1},{0.69,0.57,1},
        {0.88,0.48,1},{0.94,0.63,1},{0.04,0.73,1},{0.31,0.72,1},{0.62,0.70,1},
    }
    for i, star in ipairs(stars) do
        local dot = make("Frame", self.wallpaper, {
            Name = "Star" .. tostring(i),
            Position = UDim2.new(star[1], 0, star[2], 0),
            Size = UDim2.fromOffset(star[3], star[3]),
            BackgroundColor3 = Color3.fromRGB(207, 224, 255),
            BackgroundTransparency = 0.28,
            BorderSizePixel = 0,
            ZIndex = 1,
        })
        addCorner(dot, 4)
    end
    make("TextLabel", self.wallpaper, {
        Name = "WallpaperTitle",
        Position = UDim2.new(0, 30, 0.64, 0),
        Size = UDim2.new(0, 360, 0, 56),
        BackgroundTransparency = 1,
        Text = "ROCKET SCIENCE",
        TextColor3 = Color3.fromRGB(205, 218, 238),
        TextTransparency = 0.38,
        TextSize = 27,
        Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
        ZIndex = 1,
    })
    make("TextLabel", self.wallpaper, {
        Name = "WallpaperSubtitle",
        Position = UDim2.new(0, 32, 0.64, 35),
        Size = UDim2.new(0, 380, 0, 24),
        BackgroundTransparency = 1,
        Text = "ALTHEA SPACE  /  EXPLORATION SYSTEMS",
        TextColor3 = Color3.fromRGB(159, 180, 210),
        TextTransparency = 0.30,
        TextSize = 10,
        Font = Enum.Font.GothamMedium,
        TextXAlignment = Enum.TextXAlignment.Left,
        ZIndex = 1,
    })

    -- macOS-inspired menu bar stays at the top of the game's safe area.
    self.menuBar = make("Frame", screenGui, {
        Name = "AltheaOS_MenuBar",
        Position = UDim2.fromOffset(0, 0),
        Size = UDim2.new(1, 0, 0, 32),
        BackgroundColor3 = Color3.fromRGB(10, 15, 25),
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        ZIndex = 350,
    })
    make("TextLabel", self.menuBar, {
        Name = "AltheaMark",
        Position = UDim2.fromOffset(12, 0),
        Size = UDim2.fromOffset(24, 32),
        BackgroundTransparency = 1,
        Text = "A",
        TextColor3 = Color3.fromRGB(236, 242, 251),
        TextSize = 20,
        Font = Enum.Font.GothamBold,
        ZIndex = 351,
    })
    make("TextLabel", self.menuBar, {
        Name = "SystemName",
        Position = UDim2.fromOffset(42, 0),
        Size = UDim2.fromOffset(124, 32),
        BackgroundTransparency = 1,
        Text = "AltheaBook",
        TextColor3 = Color3.fromRGB(243, 246, 251),
        TextSize = 13,
        Font = Enum.Font.GothamBold,
        TextXAlignment = Enum.TextXAlignment.Left,
        ZIndex = 351,
    })
    local menuNames = {"File", "Edit", "View", "Window", "Help"}
    for i, label in ipairs(menuNames) do
        make("TextLabel", self.menuBar, {
            Name = "Menu_" .. label,
            Position = UDim2.fromOffset(170 + (i - 1) * 57, 0),
            Size = UDim2.fromOffset(55, 32),
            BackgroundTransparency = 1,
            Text = label,
            TextColor3 = Color3.fromRGB(212, 221, 236),
            TextSize = 12,
            Font = Enum.Font.Gotham,
            ZIndex = 351,
        })
    end
    make("TextLabel", self.menuBar, {
        Name = "SystemStatus",
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.new(1, -48, 0, 0),
        Size = UDim2.fromOffset(195, 32),
        BackgroundTransparency = 1,
        Text = "Wi-Fi     ▰ 100%     14:32",
        TextColor3 = Color3.fromRGB(227, 234, 246),
        TextSize = 11,
        Font = Enum.Font.Gotham,
        TextXAlignment = Enum.TextXAlignment.Right,
        ZIndex = 351,
    })
    self.powerButton = make("TextButton", self.menuBar, {
        Name = "CloseDesktopButton",
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -12, 0.5, 0),
        Size = UDim2.fromOffset(25, 24),
        BackgroundColor3 = Color3.fromRGB(75, 39, 48),
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        Text = "⏻",
        TextColor3 = Color3.fromRGB(255, 202, 202),
        TextSize = 15,
        Font = Enum.Font.GothamBold,
        AutoButtonColor = true,
        ZIndex = 352,
    })
    addCorner(self.powerButton, 7)
    self.powerButton.Activated:Connect(function()
        self:CloseDesktop()
    end)

    self.shade = make("TextButton", screenGui, {
        Name = "ModalShield",
        Size = UDim2.fromScale(1, 1),
        Position = UDim2.fromScale(0, 0),
        BackgroundColor3 = Color3.fromRGB(3, 7, 12),
        BackgroundTransparency = 0.42,
        BorderSizePixel = 0,
        Text = "",
        AutoButtonColor = false,
        Active = true,
        Modal = true,
        Visible = false,
        ZIndex = 2,
    })

    -- macOS-inspired Dock: hidden by default and shown only on hover / bottom-edge activation.
    -- All registered apps stay in the Dock; their windows remain closed until an icon is clicked.
    self.dock = make("Frame", screenGui, {
        Name = "AltheaOS_Dock",
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, 92),
        Size = UDim2.fromOffset(110, 70),
        BackgroundColor3 = Color3.fromRGB(28, 32, 43),
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        Visible = false,
        ZIndex = 400,
    })
    addCorner(self.dock, 19)
    addStroke(self.dock, Color3.fromRGB(118, 132, 154), 1, 0.55)

    self.dockScroll = make("ScrollingFrame", self.dock, {
        Name = "DockApps",
        Position = UDim2.fromOffset(8, 6),
        Size = UDim2.new(1, -16, 1, -12),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        CanvasSize = UDim2.new(0, 0, 0, 0),
        AutomaticCanvasSize = Enum.AutomaticSize.X,
        ScrollingDirection = Enum.ScrollingDirection.X,
        ScrollBarThickness = 0,
        ScrollBarImageTransparency = 1,
        ClipsDescendants = true,
        ZIndex = 401,
    })
    self.dockLayout = make("UIListLayout", self.dockScroll, {
        FillDirection = Enum.FillDirection.Horizontal,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0, 7),
        VerticalAlignment = Enum.VerticalAlignment.Center,
    })

    -- Tiny permanent handle for touch users and as a discoverable desktop hover target.
    self.dockHandle = make("TextButton", screenGui, {
        Name = "AltheaOS_DockHandle",
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, -1),
        Size = UDim2.fromOffset(120, 24),
        BackgroundColor3 = Color3.fromRGB(212, 219, 230),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        Text = "",
        AutoButtonColor = false,
        Visible = false, -- shown only while the desktop is open
        ZIndex = 390,
    })
    -- Larger transparent hit target with a small visible grabber, more forgiving on touch.
    make("Frame", self.dockHandle, {
        Name = "Grip",
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, -2),
        Size = UDim2.fromOffset(68, 4),
        BackgroundColor3 = Color3.fromRGB(212, 219, 230),
        BackgroundTransparency = 0.18,
        BorderSizePixel = 0,
        ZIndex = 391,
    })
    addCorner(self.dockHandle.Grip, 4)
    self.dockHandle.Activated:Connect(function()
        self:ShowDock()
        if not self.dockPinned then
            self:_scheduleDockHide(5, true)
        end
    end)

    -- Parent the post-effect to CurrentCamera so this remains a per-player UI effect.
    local blurParent = workspace.CurrentCamera or Lighting
    self.blur = blurParent:FindFirstChild("AltheaOS_LocalBlur")
    if not self.blur or not self.blur:IsA("BlurEffect") then
        self.blur = Instance.new("BlurEffect")
        self.blur.Name = "AltheaOS_LocalBlur"
    end
    self.blur.Size = 0
    self.blur.Parent = blurParent

    workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
        local currentCamera = workspace.CurrentCamera
        if currentCamera and self.blur then
            self.blur.Parent = currentCamera
        end
    end)

    UserInputService.InputChanged:Connect(function(input)
        self:_handleInputChanged(input)
        self:_handleDockPointer(input)
    end)
    UserInputService.InputEnded:Connect(function(input)
        self:_handleInputEnded(input)
    end)
    UserInputService.InputBegan:Connect(function(input, gameProcessed)
        if gameProcessed then
            return
        end
        if not self.desktopOpen then
            return
        end
        if input.KeyCode == Enum.KeyCode.F6 then
            -- F6 toggles Dock pinning. Pinned = always visible; unpinned = macOS-style auto-hide.
            self.dockPinned = not self.dockPinned
            if self.dockPinned then
                self:ShowDock()
            else
                self:HideDock()
            end
            return
        end
        if input.KeyCode == Enum.KeyCode.Escape and self.activeName then
            local record = self.windows[self.activeName]
            if record and record.options.EscapeCloses ~= false then
                self:CloseWindow(self.activeName)
            end
        end
    end)

    managerCache[playerGui] = self
    return self
end

function WindowManager:ShowDock()
    if not self.dock or not self.desktopOpen then
        return
    end
    self._dockHideToken += 1
    if self.dockVisible then
        return
    end
    self.dockVisible = true
    self.dock.Visible = true
    if self._dockTween then
        self._dockTween:Cancel()
    end
    self._dockTween = TweenService:Create(
        self.dock,
        TweenInfo.new(0.20, Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
        { Position = UDim2.new(0.5, 0, 1, -10) }
    )
    self._dockTween:Play()
end

function WindowManager:HideDock()
    if not self.dock or not self.dockVisible or self.dockPinned then
        return
    end
    self._dockHideToken += 1
    self.dockVisible = false
    if self._dockTween then
        self._dockTween:Cancel()
    end
    local tween = TweenService:Create(
        self.dock,
        TweenInfo.new(0.18, Enum.EasingStyle.Quint, Enum.EasingDirection.In),
        { Position = UDim2.new(0.5, 0, 1, 92) }
    )
    self._dockTween = tween
    tween.Completed:Connect(function()
        if not self.dockVisible and not self.dockPinned and self.dock then
            self.dock.Visible = false
        end
    end)
    tween:Play()
end

function WindowManager:_pointerIsNearDock()
    local pointer = UserInputService:GetMouseLocation()
    local viewport = getViewportSize()
    if pointer.Y >= viewport.Y - 14 then
        return true
    end
    if self.dock and self.dock.Visible then
        local p = self.dock.AbsolutePosition
        local z = self.dock.AbsoluteSize
        if pointer.X >= p.X and pointer.X <= p.X + z.X
            and pointer.Y >= p.Y and pointer.Y <= p.Y + z.Y then
            return true
        end
    end
    return false
end

function WindowManager:_scheduleDockHide(delaySeconds, force)
    if self.dockPinned or not self.dockVisible then
        return
    end
    self._dockHideToken += 1
    local token = self._dockHideToken
    task.delay(delaySeconds or 0.85, function()
        if token ~= self._dockHideToken or self.dockPinned or not self.dockVisible then
            return
        end
        if force or not self:_pointerIsNearDock() then
            self:HideDock()
        end
    end)
end

function WindowManager:_handleDockPointer(input)
    if not self.desktopOpen then
        return
    end
    if input.UserInputType ~= Enum.UserInputType.MouseMovement then
        return
    end
    if self.dockPinned then
        return
    end
    if self:_pointerIsNearDock() then
        self:ShowDock()
    elseif self.dockVisible then
        self:_scheduleDockHide(0.85, false)
    end
end

function WindowManager:_makeControlButton(header, name, text, xOffset, color)
    local button = make("TextButton", header, {
        Name = name,
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.new(0, xOffset, 0.5, 0),
        Size = UDim2.fromOffset(14, 14),
        BackgroundColor3 = color or COLORS.button,
        BorderSizePixel = 0,
        Text = "",
        TextColor3 = COLORS.text,
        TextSize = 1,
        Font = Enum.Font.GothamMedium,
        AutoButtonColor = true,
    })
    addCorner(button, 10)
    addStroke(button, color or COLORS.barStroke, 1, 0.45)
    button.ZIndex = header.ZIndex + 1
    return button
end

function WindowManager:_makeTab(record)
    local defaultIcons = {
        ["Periodic Table"] = "⚛",
        ["Research Lab"] = "⚗",
        ["Resource Database"] = "▤",
        ["Blueprints"] = "▧",
        ["Settings"] = "⚙",
    }
    local iconText = record.options.DockIcon or defaultIcons[record.name] or string.upper(string.sub(record.name, 1, 1))
    local tab = make("TextButton", self.dockScroll, {
        Name = "DockApp_" .. record.name:gsub("[^%w_]", ""),
        Size = UDim2.fromOffset(48, 48),
        BackgroundColor3 = COLORS.button,
        BackgroundTransparency = 0.38,
        BorderSizePixel = 0,
        Text = iconText,
        TextColor3 = COLORS.text,
        TextSize = #iconText > 2 and 20 or 24,
        Font = Enum.Font.GothamMedium,
        AutoButtonColor = true,
        LayoutOrder = record.launchOrder or 1,
        ZIndex = 402,
    })
    addCorner(tab, 14)
    local stroke = addStroke(tab, COLORS.barStroke, 1, 0.48)

    local runningDot = make("Frame", tab, {
        Name = "RunningIndicator",
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, -2),
        Size = UDim2.fromOffset(5, 5),
        BackgroundColor3 = COLORS.accent,
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        Visible = false,
        ZIndex = 404,
    })
    addCorner(runningDot, 3)

    record.tabButton = tab
    record.tabStroke = stroke
    record.runningDot = runningDot
    tab.Activated:Connect(function()
        if table.find(self.openOrder, record.name) then
            self:ActivateWindow(record.name)
        else
            self:OpenWindow(record.name)
        end
        self:ShowDock()
        if not self.dockPinned then
            self:_scheduleDockHide(1.6, false)
        end
    end)
    tab.MouseEnter:Connect(function()
        self:ShowDock()
    end)
    tab.MouseLeave:Connect(function()
        if not self.dockPinned then
            self:_scheduleDockHide(0.85, false)
        end
    end)
    self:_updateDockSize()
end

function WindowManager:_ensureTab(record)
    if record.tabButton and record.tabButton.Parent then
        return
    end
    self:_makeTab(record)
end

function WindowManager:RegisterWindow(name, frame, options)
    assert(type(name) == "string" and name ~= "", "RegisterWindow needs a name")
    assert(frame and frame:IsA("GuiObject"), "RegisterWindow needs a GuiObject window frame")
    options = options or {}

    if self.windows[name] then
        self:CloseWindow(name)
        local old = self.windows[name]
        if old then
            if old.frame then
                old.frame.Visible = false
                if old.frame ~= frame then
                    old.frame:Destroy()
                end
            end
            if old.tabButton then
                old.tabButton:Destroy()
            end
        end
        local oldOrder = table.find(self.registeredOrder, name)
        if oldOrder then
            table.remove(self.registeredOrder, oldOrder)
        end
        self.windows[name] = nil
    end

    local header = options.Header or frame:FindFirstChild("Header")
    local closeButton = options.CloseButton or (header and header:FindFirstChild("CloseButton"))

    local record = {
        name = name,
        frame = frame,
        header = header,
        closeButton = closeButton,
        options = options,
        tabButton = nil,
        tabStroke = nil,
        originalSize = frame.Size,
        originalPosition = frame.Position,
        originalAnchorPoint = frame.AnchorPoint,
    }
    self.windows[name] = record
    record.launchOrder = #self.registeredOrder + 1
    table.insert(self.registeredOrder, name)
    self:_ensureTab(record)
    self:_reorderTabs()

    -- Put app windows into one shared ScreenGui. Registration never opens a window.
    frame.Parent = self.screenGui
    frame.Visible = false
    frame.Active = true
    frame.AnchorPoint = Vector2.new(0.5, 0.5)
    frame.Position = options.DefaultPosition or UDim2.new(0.5, 0, 0.49, 0)
    frame.Size = options.DefaultSize or UDim2.new(0.84, 0, 0.78, 0)
    setZTree(frame, 10)

    if header and header:IsA("GuiObject") then
        header.Active = true
        -- macOS-style traffic lights on the left; title/subtitle begin after them.
        for _, child in ipairs(header:GetChildren()) do
            if child:IsA("TextLabel") then
                child.Position = UDim2.new(0, 82, child.Position.Y.Scale, child.Position.Y.Offset)
                child.Size = UDim2.new(1, -100, child.Size.Y.Scale, child.Size.Y.Offset)
            end
        end

        local minimizeButton = self:_makeControlButton(header, "OS_MinimizeButton", "", 36, Color3.fromRGB(255, 189, 46))
        local maximizeButton = self:_makeControlButton(header, "OS_MaximizeButton", "", 56, Color3.fromRGB(40, 200, 64))
        record.minimizeButton = minimizeButton
        record.maximizeButton = maximizeButton
        minimizeButton.Activated:Connect(function()
            self:MinimizeWindow(name)
        end)
        maximizeButton.Activated:Connect(function()
            self:ToggleMaximize(name)
        end)

        if not closeButton then
            closeButton = self:_makeControlButton(header, "OS_CloseButton", "", 16, Color3.fromRGB(255, 95, 86))
            record.closeButton = closeButton
        else
            closeButton.AnchorPoint = Vector2.new(0, 0.5)
            closeButton.Position = UDim2.new(0, 16, 0.5, 0)
            closeButton.Size = UDim2.fromOffset(14, 14)
            closeButton.BackgroundColor3 = Color3.fromRGB(255, 95, 86)
            closeButton.BackgroundTransparency = 0
            closeButton.Text = ""
            closeButton.TextSize = 1
            closeButton.AutoButtonColor = true
            closeButton.ZIndex = header.ZIndex + 1
            local corner = closeButton:FindFirstChildOfClass("UICorner")
            if corner then
                corner.CornerRadius = UDim.new(1, 0)
            else
                addCorner(closeButton, 10)
            end
            local stroke = closeButton:FindFirstChildOfClass("UIStroke")
            if stroke then
                stroke.Color = Color3.fromRGB(255, 95, 86)
                stroke.Transparency = 0.45
            end
        end
        closeButton.Activated:Connect(function()
            self:CloseWindow(name)
        end)

        header.InputBegan:Connect(function(input)
            if not isPointerBegin(input) or self.maximized[name] then
                return
            end
            self.interaction = {
                kind = "drag",
                record = record,
                inputType = input.UserInputType,
                inputObject = input,
                pointerStart = Vector2.new(input.Position.X, input.Position.Y),
                absolutePositionStart = frame.AbsolutePosition,
            }
        end)
    end

    local resizeHandle = make("TextButton", frame, {
        Name = "OS_ResizeHandle",
        AnchorPoint = Vector2.new(1, 1),
        Position = UDim2.new(1, -5, 1, -5),
        Size = UDim2.fromOffset(24, 24),
        BackgroundColor3 = COLORS.button,
        BackgroundTransparency = 0.12,
        BorderSizePixel = 0,
        Text = "◢",
        TextColor3 = COLORS.accent,
        TextSize = 13,
        Font = Enum.Font.GothamBold,
        AutoButtonColor = true,
    })
    addCorner(resizeHandle, 6)
    addStroke(resizeHandle, COLORS.barStroke, 1, 0.25)
    resizeHandle.ZIndex = 100
    record.resizeHandle = resizeHandle
    resizeHandle.InputBegan:Connect(function(input)
        if not isPointerBegin(input) or self.maximized[name] then
            return
        end
        self.interaction = {
            kind = "resize",
            record = record,
            inputType = input.UserInputType,
            inputObject = input,
            pointerStart = Vector2.new(input.Position.X, input.Position.Y),
            sizeStart = frame.AbsoluteSize,
            absolutePositionStart = frame.AbsolutePosition,
        }
    end)

    return record
end

function WindowManager:_updateDockSize()
    if not self.dock then
        return
    end
    local count = #self.registeredOrder
    local width = math.clamp(count * 55 + 28, 104, 660)
    self.dock.Size = UDim2.fromOffset(width, 70)
end

function WindowManager:_reorderTabs()
    for index, name in ipairs(self.registeredOrder) do
        local record = self.windows[name]
        if record and record.tabButton then
            record.tabButton.LayoutOrder = index
        end
    end
    self:_updateDockSize()
end

function WindowManager:_refresh()
    local activeRecord = self.activeName and self.windows[self.activeName] or nil
    local hasActiveWindow = activeRecord ~= nil and not self.minimized[self.activeName]

    for name, record in pairs(self.windows) do
        local isOpen = table.find(self.openOrder, name) ~= nil
        local isActive = hasActiveWindow and name == self.activeName and isOpen
        record.frame.Visible = isActive
        if record.tabButton then
            record.tabButton.BackgroundColor3 = isActive and COLORS.tabActive or COLORS.button
            record.tabButton.BackgroundTransparency = isActive and 0.04 or 0.34
            record.tabButton.TextColor3 = isActive and COLORS.text or COLORS.muted
            if record.tabStroke then
                record.tabStroke.Color = isActive and COLORS.accent or COLORS.barStroke
                record.tabStroke.Transparency = isActive and 0.05 or 0.50
            end
            if record.runningDot then
                record.runningDot.Visible = isOpen
            end
        end
    end

    local modal = hasActiveWindow and activeRecord.options.Modal == true
    self.shade.Visible = modal
    if self.blur then
        self.blur.Size = modal and (tonumber(activeRecord.options.BlurSize) or 16) or 0
    end
end

function WindowManager:OpenWindow(name)
    local record = self.windows[name]
    if not record then
        warn("AltheaOS: window is not registered: " .. tostring(name))
        return false
    end

    if not table.find(self.openOrder, name) then
        table.insert(self.openOrder, name)
        self:_ensureTab(record)
        self:_reorderTabs()
    end

    self.minimized[name] = false
    self.activeName = name
    self:_refresh()

    task.defer(function()
        if record.tabButton and self.dockScroll then
            local tabX = record.tabButton.AbsolutePosition.X - self.dockScroll.AbsolutePosition.X
            local tabRight = tabX + record.tabButton.AbsoluteSize.X
            local scrollX = self.dockScroll.CanvasPosition.X
            local viewportWidth = self.dockScroll.AbsoluteSize.X
            if tabRight > scrollX + viewportWidth then
                self.dockScroll.CanvasPosition = Vector2.new(math.max(0, tabRight - viewportWidth + 8), 0)
            elseif tabX < scrollX then
                self.dockScroll.CanvasPosition = Vector2.new(math.max(0, tabX), 0)
            end
        end
    end)
    return true
end

function WindowManager:ActivateWindow(name)
    if not table.find(self.openOrder, name) then
        return self:OpenWindow(name)
    end
    self.minimized[name] = false
    self.activeName = name
    self:_refresh()
    return true
end

function WindowManager:CloseWindow(name)
    local record = self.windows[name]
    if not record then
        return false
    end

    local index = table.find(self.openOrder, name)
    if index then
        table.remove(self.openOrder, index)
    end
    self.minimized[name] = nil
    if self.maximized[name] then
        local bounds = record.restoreBounds
        if bounds then
            record.frame.AnchorPoint = bounds.anchorPoint
            record.frame.Position = bounds.position
            record.frame.Size = bounds.size
        end
        self.maximized[name] = false
        record.restoreBounds = nil
    end
    -- Keep the app icon pinned in the Dock even when its window is closed.
    record.frame.Visible = false

    if self.activeName == name then
        self.activeName = nil
        for i = #self.openOrder, 1, -1 do
            local candidate = self.openOrder[i]
            if not self.minimized[candidate] then
                self.activeName = candidate
                break
            end
        end
    end
    self:_reorderTabs()
    self:_refresh()
    return true
end

function WindowManager:MinimizeWindow(name)
    if not table.find(self.openOrder, name) then
        return false
    end
    self.minimized[name] = true
    if self.activeName == name then
        self.activeName = nil
        for i = #self.openOrder, 1, -1 do
            local candidate = self.openOrder[i]
            if candidate ~= name and not self.minimized[candidate] then
                self.activeName = candidate
                break
            end
        end
    end
    self:_refresh()
    return true
end

function WindowManager:ToggleMaximize(name)
    local record = self.windows[name]
    if not record or not table.find(self.openOrder, name) then
        return false
    end

    local frame = record.frame
    if self.maximized[name] then
        local bounds = record.restoreBounds
        if bounds then
            frame.AnchorPoint = bounds.anchorPoint
            frame.Position = bounds.position
            frame.Size = bounds.size
        else
            frame.AnchorPoint = record.originalAnchorPoint
            frame.Position = record.originalPosition
            frame.Size = record.originalSize
        end
        self.maximized[name] = false
    else
        record.restoreBounds = {
            anchorPoint = frame.AnchorPoint,
            position = frame.Position,
            size = frame.Size,
        }
        frame.AnchorPoint = Vector2.new(0.5, 0.5)
        frame.Position = UDim2.new(0.5, 0, 0.49, 0)
        frame.Size = UDim2.new(1, -32, 1, -84)
        self.maximized[name] = true
    end
    return true
end

function WindowManager:_handleInputChanged(input)
    local state = self.interaction
    if not state then
        return
    end

    local isMove = state.inputType == Enum.UserInputType.MouseButton1
        and input.UserInputType == Enum.UserInputType.MouseMovement
    local isTouchMove = state.inputType == Enum.UserInputType.Touch
        and input.UserInputType == Enum.UserInputType.Touch
        and input == state.inputObject
    if not isMove and not isTouchMove then
        return
    end

    local currentPointer = Vector2.new(input.Position.X, input.Position.Y)
    local delta = currentPointer - state.pointerStart
    local frame = state.record.frame
    local viewport = getViewportSize()
    local topLeftInset = getTopLeftInset()

    if state.kind == "drag" then
        if self.maximized[state.record.name] then
            return
        end
        -- Normalize to top-left positioning so dragging still works after resizing.
        local leftX = state.absolutePositionStart.X + delta.X - topLeftInset.X
        local topY = state.absolutePositionStart.Y + delta.Y - topLeftInset.Y
        leftX = math.clamp(leftX, 0, math.max(0, viewport.X - frame.AbsoluteSize.X))
        local bottomReserved = 20
        local maxTop = math.max(8, viewport.Y - topLeftInset.Y - frame.AbsoluteSize.Y - bottomReserved)
        topY = math.clamp(topY, 8, maxTop)
        frame.AnchorPoint = Vector2.new(0, 0)
        frame.Position = UDim2.fromOffset(leftX, topY)
    elseif state.kind == "resize" then
        if self.maximized[state.record.name] then
            return
        end
        local minWidth = math.min(540, math.max(280, viewport.X - 24))
        local minHeight = math.min(300, math.max(220, viewport.Y - 96))
        local maxHeight = math.max(minHeight, viewport.Y - 96)
        local newWidth = math.clamp(state.sizeStart.X + delta.X, minWidth, math.max(minWidth, viewport.X - 24))
        local newHeight = math.clamp(state.sizeStart.Y + delta.Y, minHeight, maxHeight)
        frame.AnchorPoint = Vector2.new(0, 0)
        frame.Position = UDim2.fromOffset(
            math.max(0, state.absolutePositionStart.X - topLeftInset.X),
            math.max(8, state.absolutePositionStart.Y - topLeftInset.Y)
        )
        frame.Size = UDim2.fromOffset(newWidth, newHeight)
    end
end

function WindowManager:_handleInputEnded(input)
    local state = self.interaction
    if not state then
        return
    end
    if (state.inputType == Enum.UserInputType.MouseButton1 and input.UserInputType == Enum.UserInputType.MouseButton1)
        or (state.inputType == Enum.UserInputType.Touch and input.UserInputType == Enum.UserInputType.Touch) then
        self.interaction = nil
    end
end

function WindowManager:OpenDesktop()
    if self.desktopOpen then
        return false
    end
    self.desktopOpen = true
    self.screenGui.Enabled = true
    if self.dockHandle then
        self.dockHandle.Visible = true
    end
    self:ShowDock()
    if not self.dockPinned then
        self:_scheduleDockHide(3.5, true)
    end
    return true
end

function WindowManager:CloseDesktop()
    if not self.desktopOpen then
        return false
    end
    -- Close all app windows so no modal blur is left behind when the laptop is put away.
    local names = {}
    for _, name in ipairs(self.openOrder) do
        table.insert(names, name)
    end
    for _, name in ipairs(names) do
        self:CloseWindow(name)
    end
    self.desktopOpen = false
    self.dockPinned = false
    self.dockVisible = false
    self._dockHideToken += 1
    if self._dockTween then
        self._dockTween:Cancel()
        self._dockTween = nil
    end
    if self.dock then
        self.dock.Visible = false
        self.dock.Position = UDim2.new(0.5, 0, 1, 92)
    end
    if self.dockHandle then
        self.dockHandle.Visible = false
    end
    if self.shade then
        self.shade.Visible = false
    end
    if self.blur then
        self.blur.Size = 0
    end
    self.screenGui.Enabled = false
    return true
end

function WindowManager:ToggleDesktop()
    if self.desktopOpen then
        return self:CloseDesktop()
    end
    return self:OpenDesktop()
end

function WindowManager:SetDesktopVisible(visible)
    if visible then
        return self:OpenDesktop()
    end
    return self:CloseDesktop()
end

return WindowManager
