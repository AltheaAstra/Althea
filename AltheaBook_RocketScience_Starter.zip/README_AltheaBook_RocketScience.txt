ALTHEABOOK — ROCKET SCIENCE PERSONAL DESKTOP

WHAT THIS PACKAGE DOES
- StarterPack supplies one AltheaBook Tool to each player at game start and restores it on respawn.
- The desktop starts fully hidden. It opens only when the player equips AltheaBook and clicks/activates it.
- macOS-inspired menu bar, dark space wallpaper, centered auto-hide Dock, 118-element Periodic Table, and app shells for Space Hub, Research Lab, Resource Database, Blueprints, My Files, and Settings.
- Dock icons open apps. Red closes an app, yellow minimizes, green maximizes/restores. F6 pins/unpins the Dock. The top-right power button closes the desktop. Unequipping the laptop also closes it.
- No Simulation bar. Roblox's built-in CoreGui/topbar is deliberately left untouched.

INSTALL — TWO MODEL FILES, TWO LOCATIONS
A) OS scripts:
   1. In Roblox Studio, right-click Workspace > Insert from File and select AltheaBook_OSScripts.rbxmx.
   2. Move the imported Folder named AltheaBookOS into StarterPlayer > StarterPlayerScripts.
   The Folder contains ModuleScript AltheaOSWindowManager and LocalScript RocketSciencePeriodicTable. The local control event lives under PlayerScripts so it survives character respawns.

B) Laptop Tool:
   1. Insert AltheaBook_Tool.rbxmx into Workspace.
   2. Move the Tool named AltheaBook into StarterPack.
   StarterPack automatically supplies one copy to each player and restores it on respawn.

CLEAN UP BEFORE TESTING
- Disable/delete the old standalone RocketSciencePeriodicTable or previous AltheaOS LocalScripts so only the new AltheaBookOS folder boots the UI.
- Old ModuleScripts in ReplicatedStorage may be removed if nothing else uses them. The new version loads the manager from the AltheaBookOS folder.
- Do not add another script that gives players AltheaBook; StarterPack already does this and another giver would cause duplicates.
- Press Stop, then Play to start a clean test.

HOW TO USE
1. Equip AltheaBook from the hotbar and click/use it to open the desktop.
2. Move the mouse to the bottom edge or tap the small bottom handle to reveal the Dock.
3. Click the atom icon to open Periodic Table. Other app icons are placeholders ready for future features.
4. Click the power icon in the top-right of the menu bar or unequip the Tool to hide the whole OS.
5. F6 pins/unpins the Dock. Esc closes the active app window.

NOTES
- The app windows start closed; no GUI pops up randomly.
- The procedural dark space wallpaper is built from Roblox GUI objects, so it needs no image asset upload. The attached PNG is a visual concept reference; it is not automatically imported as a Roblox image texture.
- BlurEffect affects the 3D world, not Roblox CoreGui or every other ScreenGui. A dim shield focuses modal app windows. The system does not attempt to destroy Roblox's topbar.
- Periodic Table is functional. Space Hub, Research Lab, Resource Database, Blueprints, My Files, and Settings are app shells/placeholders until their systems are implemented.
- The bundle has been generated and XML-parsed in the file environment but not executed in Roblox Studio. Test in Play and check View > Output for any runtime error.
