-- AltheaBook Tool Client — fixed for AltheaBook OS
-- Put this LocalScript inside the AltheaBook Tool in StarterPack.
-- Selecting hotbar slot 1 opens the desktop. The 3D Handle is hidden locally so it cannot cover the desktop.
-- The tool and OS must communicate through PlayerScripts.AltheaBookControl (BindableEvent).

local Players = game:GetService("Players")
local player = Players.LocalPlayer
local tool = script.Parent
local playerScripts = player:WaitForChild("PlayerScripts")
local control = playerScripts:WaitForChild("AltheaBookControl")

if not control:IsA("BindableEvent") then
    warn("AltheaBookControl must be a BindableEvent under PlayerScripts")
    return
end

local equipped = false
local originalPartTransparency = {}
local originalGuiEnabled = {}

local function setDeviceVisualHidden(hidden)
    for _, object in ipairs(tool:GetDescendants()) do
        if object:IsA("BasePart") then
            if originalPartTransparency[object] == nil then
                originalPartTransparency[object] = object.LocalTransparencyModifier
            end
            object.LocalTransparencyModifier = hidden and 1 or originalPartTransparency[object]
        elseif object:IsA("SurfaceGui") or object:IsA("BillboardGui") then
            if originalGuiEnabled[object] == nil then
                originalGuiEnabled[object] = object.Enabled
            end
            object.Enabled = not hidden and originalGuiEnabled[object]
        end
    end
end

tool.Equipped:Connect(function()
    equipped = true
    -- Hide the model before showing the desktop; it should act as a computer launcher, not a held prop.
    setDeviceVisualHidden(true)
    control:Fire("open")
end)

tool.Activated:Connect(function()
    if equipped then
        -- Safe to call repeatedly: OpenDesktop does nothing if already open.
        control:Fire("open")
    end
end)

tool.Unequipped:Connect(function()
    equipped = false
    control:Fire("close")
    setDeviceVisualHidden(false)
end)
