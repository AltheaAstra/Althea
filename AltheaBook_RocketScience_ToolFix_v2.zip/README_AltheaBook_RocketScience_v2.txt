ALTHEABOOK — ROCKET SCIENCE PERSONAL DESKTOP (TOOL FIX V2)

WHAT THIS FIX CHANGES
- Selecting AltheaBook in hotbar slot 1 opens the OS immediately.
- The 3D Tool handle and its SurfaceGui logo are hidden locally while equipped so they do not visually cover the OS.
- The Tool and desktop share the same BindableEvent at PlayerScripts > AltheaBookControl. This fixes the old PlayerGui-vs-PlayerScripts mismatch.
- The AltheaOS ScreenGui uses IgnoreGuiInset = true and DisplayOrder = 10000 for a full-screen canvas.
- The default Roblox Backpack hotbar is hidden only while the OS is open, so it does not clash with the macOS-style Dock. Its previous enabled state is restored when the OS closes.
- Unequipping/putting away AltheaBook closes the desktop and restores the Tool's local visual state.
- No Simulation bar.

INSTALL
1. Press Stop in Studio before changing the files.
2. Import AltheaBook_OSScripts.rbxmx via Workspace > Insert from File. Move the imported AltheaBookOS folder to StarterPlayer > StarterPlayerScripts.
3. Import AltheaBook_Tool.rbxmx via Workspace > Insert from File. Move the AltheaBook Tool to StarterPack.
4. Disable/delete older AltheaBook OS / Periodic Table LocalScripts to prevent duplicate shells/events. Keep only the AltheaBookOS folder and one AltheaBook Tool in StarterPack.
5. Press Stop, then Play. Select slot 1; the desktop should open and the held 3D model should remain invisible.

IMPORTANT
- IgnoreGuiInset = true lets the custom ScreenGui use the full-screen canvas; it does not delete Roblox CoreGui.
- Roblox's topbar is a separate CoreGui surface controlled by Roblox. This package does not disable the topbar or chat/player controls. It only hides the Backpack hotbar while the OS is open.
- The app windows are client-side GUI. Game resources, simulation, trading, and data persistence are not implemented in this package yet.
- If the OS still does not open, verify there is exactly one RocketSciencePeriodicTable LocalScript running and check View > Output for errors.
